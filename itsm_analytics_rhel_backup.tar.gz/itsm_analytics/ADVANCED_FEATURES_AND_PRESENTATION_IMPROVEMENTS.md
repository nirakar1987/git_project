# Advanced Features & Presentation/PDF Improvement Plan

This document adds **further advanced feature ideas** beyond the main analysis doc, and gives a **concrete plan to improve exported presentations and PDF reports** so they include **charts, graphs, and full/rich data**.

---

## Part 1: Additional Advanced Features (Beyond DEEP_ANALYSIS)

### 1.1 Analytics & Intelligence

| Feature | Description | Benefit |
|---------|-------------|--------|
| **Forecasting** | Simple trend forecast (e.g. next 3 months volume/SLA) using moving average or lightweight ML; show as dotted line on workload chart. | Proactive capacity planning. |
| **Anomaly detection** | Flag months/categories where volume or breach rate is 2× standard deviation from mean; "Needs review" badge. | Quick focus on outliers. |
| **Benchmarking** | Compare current dataset vs internal benchmark (e.g. "Q1 2024 baseline") or industry norms; show "Above/Below benchmark". | Context for leadership. |
| **Correlation insights** | "When priority P1 goes up, breach rate goes up by X%"; surface 1–2 key correlations in AI summary. | Narrative for reports. |
| **Record-type split in all charts** | When data has Incident/SR/Change, show split in workload, SLA, and priority charts (stacked or side-by-side). | Single upload, full picture. |

### 1.2 Reporting & Export

| Feature | Description | Benefit |
|---------|-------------|--------|
| **Appendix / full data export** | Option: "Include full ticket list as appendix" in PDF/Word (paginated table or linked Excel). | One document has everything. |
| **Comparison report** | "Period A vs Period B" as a single PDF/PPTX: side-by-side KPIs, delta table, and both workload charts. | Single deliverable for reviews. |
| **Executive one-pager** | One-page PDF: logo, period, 4 KPIs, 1 key chart, 3 bullet takeaways, AI recommendation. | C-level summary. |
| **Email report** | "Email this report" → send PDF/Word to list; optional recurring (weekly/monthly). | Distribution without manual download. |
| **Watermark / confidentiality** | Optional "Confidential" or "Draft" watermark on PDF/slides. | Compliance and versioning. |

### 1.3 UX & Workflow

| Feature | Description | Benefit |
|---------|-------------|--------|
| **Undo / history** | Undo last filter or "Restore previous view"; optional history of last N views. | Safer exploration. |
| **Favorites / pins** | Pin specific sessions or charts to top of sidebar; "My Q1 report" always visible. | Faster access. |
| **Copy chart as image** | Right-click or button: "Copy chart as PNG" for pasting into email/Word. | Quick sharing. |
| **Full-screen chart** | Click chart → expand to full screen with export PNG/SVG. | Better for presentations. |
| **Tooltips with drill-down** | Hover on bar → tooltip with count + "View tickets" link opening month detail filtered. | From chart to data in one click. |

### 1.4 Enterprise & Scale

| Feature | Description | Benefit |
|---------|-------------|--------|
| **Tenant / workspace** | Multiple workspaces (e.g. by department); each has own uploads and sessions. | Multi-team SaaS. |
| **Data retention policy** | Auto-delete sessions/reports older than N days; configurable per tenant. | Compliance and cost. |
| **High-contrast / a11y** | WCAG-friendly theme; optional high-contrast mode for exports. | Accessibility. |
| **Localization** | UI and report labels in multiple languages (e.g. EN/DE/FR); date/number formats. | Global rollout. |

---

## Part 2: Improving Presentation & PDF – Charts, Graphs & Full Data

**Current state:**  
Monthly report (PDF/Word/HTML) and slides (HTML/PPTX) use **tables and text only**. No charts or graphs are embedded. Data is summarized (e.g. top 12 categories, top 50 breaches).

**Goal:**  
Exports should include **visual charts**, **consistent styling**, and options for **more complete data** (e.g. full breach list, full workload table, or appendix).

---

### 2.1 Add Charts and Graphs to Exports

**Approach:** Generate chart images on the backend (e.g. with **matplotlib**) from existing `chart_data`, then embed those images in PDF, Word, PPTX, and HTML.

| Chart | Data source (`chart_data`) | Where to add |
|-------|----------------------------|--------------|
| **Workload trend (stacked bar)** | `workload`, `categories` | Report §2 or dedicated "Workload trend" section; Slide 2 in deck. |
| **SLA distribution (pie/donut)** | `sla` (Met / Breached / Warning) | Report §2; Slide 3. |
| **Priority distribution (pie/bar)** | `priority` | Report or slides. |
| **Top services (horizontal bar)** | `services` | Alongside or instead of top-services table; Slide 4. |
| **SLA by category (bar)** | `sla_by_category` | Optional; good for PDF. |

**Implementation outline:**

1. **New module: `backend/chart_images.py`**
   - Functions such as `render_workload_bar(chart_data) -> bytes`, `render_sla_pie(chart_data) -> bytes`, `render_priority_pie(chart_data) -> bytes`, `render_services_bar(chart_data) -> bytes`.
   - Use matplotlib with a consistent style (e.g. `seaborn-v0_8-whitegrid`), font size 10–12, figure size e.g. 8×4 for report, 10×5 for slides.
   - Return PNG bytes (e.g. via `BytesIO`).

2. **Report builders (reporting.py)**
   - **PDF (reportlab):** For each chart, call `chart_images.render_*`, then `Image(BytesIO(png_bytes), width=..., height=...)` and append to story. Place after the relevant table (e.g. workload chart after "Key metrics", SLA pie after "SLA by category").
   - **Word (python-docx):** `doc.add_picture(BytesIO(png_bytes), width=Inches(5.5))` after each section heading.
   - **PPTX (python-pptx):** `slide.shapes.add_picture(BytesIO(png_bytes), left, top, width=Inches(6))` on content slides; one slide per chart or one slide with 2 small charts.
   - **HTML report/slides:** Embed as `<img src="data:image/png;base64,..." alt="Workload trend" />` or write PNG to a temp file and reference it.

3. **Dependencies**
   - Add `matplotlib` (and optionally `seaborn`) to `backend/requirements.txt`.

4. **Optional: SVG**
   - For HTML exports, matplotlib can write SVG; embed `<img src="data:image/svg+xml;base64,...">` for sharp scaling.

---

### 2.2 Include “All” or “Full” Data Options

| Option | What it does | Where |
|--------|--------------|--------|
| **Full breach list** | No 50-row cap: include every breached ticket in report/slides (with pagination in PDF, "See appendix" in PPTX). | Report §4; optional appendix in PDF/Word. |
| **Full SLA by category** | All categories, not just top 12. | Report §2 table; optional "Full table" appendix. |
| **Full workload table** | Full service × month table (or top 30 + "Other") in report. | Report appendix or extra section. |
| **Appendix as second file** | "Download report (PDF)" + "Download data appendix (Excel)" so the PDF stays short and the Excel has all rows. | Export flow: two files. |

**Implementation:**

- Add optional query params to report endpoints, e.g. `full_breach_list=1`, `max_categories=0` (0 = all).
- In `reporting.py`, when `full_breach_list` is True, pass full `breach_list` (no `[:50]`); in PDF use pagination (e.g. repeat table header every page) or split into multiple pages.
- For "appendix as Excel", add an endpoint or same response that returns Excel with sheets: "Breach list", "SLA by category", "Workload table", "Top services".

---

### 2.3 Better Structure and Styling for Presentations

| Improvement | Description |
|-------------|-------------|
| **Title slide** | Logo (if configured), title "ITSM Analytics – Monthly Report", subtitle with period and data source, date generated. |
| **Agenda slide** | Optional second slide: "1. Key metrics 2. Workload trend 3. SLA 4. Top services 5. Breaches 6. AI summary". |
| **One chart per slide** | In PPTX/HTML slides: one main chart per slide with a short title (e.g. "Workload by month", "SLA status"). Reduces clutter. |
| **Consistent colors** | Use same color palette as frontend (e.g. sky blue #38bdf8 for primary) in matplotlib and in HTML/CSS for tables. |
| **Table styling** | Header row background, grid, and readable font size in PDF/Word/slides; avoid tiny text. |
| **Page numbers / slide numbers** | PDF: footer "Page X of Y"; PPTX: slide numbers. |
| **Cover page for PDF** | First page: title, period, generated date, optional logo; then "Key metrics" and charts. |

---

### 2.4 Suggested Report/Slide Layout (With Charts)

**Monthly report (PDF/Word) – suggested order:**

1. **Cover** – Title, period, data source, generated date.  
2. **Key metrics** – Total tickets, SLA %, Avg resolve (existing).  
3. **Workload trend** – **NEW: embedded stacked bar chart** (from `workload`).  
4. **SLA by category** – Existing table + **NEW: SLA pie chart** (from `sla`).  
5. **Top services** – Existing table + **NEW: horizontal bar chart** (from `services`).  
6. **SLA breach list** – Existing table; option to include full list or "Top 50" + "Full list in appendix".  
7. **AI summary** – Existing summary + recommendation.  
8. **Appendix (optional)** – Full breach list, full SLA by category, workload table.

**Presentation (PPTX/HTML) – suggested slides:**

1. Title (logo, period, date).  
2. Key metrics (numbers only).  
3. **Workload trend** – one slide with stacked bar chart.  
4. **SLA distribution** – one slide with pie/donut chart.  
5. SLA by category – table (top 8).  
6. **Top services** – one slide with bar chart (and optionally small table).  
7. Breach summary – table (top 15) + breach count.  
8. AI summary + recommendation.  
9. Thank you / Q&A (optional).

---

### 2.5 Implementation Priority for Presentation/PDF

| Priority | Task | Effort |
|----------|------|--------|
| P0 | Add matplotlib chart image generation (workload bar, SLA pie, services bar). | 1–2 days |
| P0 | Embed chart images in PDF and PPTX (and HTML report/slides). | 1 day |
| P1 | Full breach list option (param + pagination in PDF). | 0.5 day |
| P1 | Consistent styling (colors, table header, cover page for PDF). | 0.5 day |
| P2 | Appendix (full tables or second Excel file). | 1 day |
| P2 | Agenda slide; one chart per slide in PPTX. | 0.5 day |

---

## Part 3: One-Page Summary

**More advanced features:** Forecasting, anomaly detection, benchmarking, comparison report, executive one-pager, copy chart as image, full-screen chart, tenant/workspace, data retention, localization, and others listed in Part 1.

**Presentation/PDF improvements:**  
(1) **Charts in every export** – workload bar, SLA pie, priority/service bars via matplotlib; embed in PDF, Word, PPTX, HTML.  
(2) **Full data options** – full breach list, full SLA table, optional appendix or separate Excel.  
(3) **Structure and style** – cover page, one chart per slide, consistent colors, page/slide numbers.

Implementing P0 (chart generation + embedding) will make the exported reports and presentations **visually rich and enterprise-ready** while reusing the same `chart_data` already available in the backend.

---

## Implementation status (Part 2, lines 50–174)

| Section | Suggestion | Status | Notes |
|--------|-------------|--------|--------|
| **2.1 Charts** | Workload trend (stacked bar) | Done | `chart_images.render_workload_bar`; PDF, Word, HTML, slides. Fallback: total-per-month when no categories. |
| | SLA distribution (pie) | Done | `render_sla_pie`; embedded in all exports. |
| | Priority distribution (pie) | Done | `render_priority_pie` in base64; also **Priority by month** bar and **Workload by group** bar added. |
| | Top services (horizontal bar) | Done | `render_services_bar`; all exports. |
| | SLA by category (bar) | Not done | Doc said “optional”; only table used today. Can add `render_sla_by_category_bar` if needed. |
| | chart_images.py + matplotlib | Done | Module exists; PNG bytes; palette #38bdf8. |
| | Embed in PDF/Word/PPTX/HTML | Done | All report/slide builders use chart images. |
| | matplotlib in requirements | Done | In `requirements.txt`. |
| | Optional SVG for HTML | Not done | Could add SVG export path. |
| **2.2 Full data** | Full breach list | Done | `full_breach_list=1` or `max_breach=0` on `/report/monthly`; PDF repeatRows=1 for long tables. |
| | Full SLA by category | Not done | Still top 12 only; no param for “all categories”. |
| | Full workload table in report | Not done | No appendix section with full service×month table. |
| | Appendix as second file (Excel) | Not done | No endpoint for “data appendix” Excel. |
| **2.3 Structure/style** | Title slide | Done | Title, period, data source, date. |
| | Agenda slide | Not done | No “Agenda” slide listing sections. |
| | One chart per slide | Done | One chart per slide in PPTX/HTML. |
| | Consistent colors | Done | #38bdf8, PALETTE in chart_images. |
| | Table styling | Done | Header background, grid; breach table column widths + Paragraph wrapping in PDF. |
| | Page numbers / slide numbers | Not done | No “Page X of Y” in PDF; no slide numbers in PPTX. |
| | Cover page for PDF | Done | First page: title, period, generated date. |
| **2.4 Layout** | Report order (Cover → KPIs → charts → tables → AI) | Done | Plus 1b Priority by month, 1c Workload by group. |
| | Slide order (Title → KPIs → charts → tables → AI) | Done | Same. |
| | Appendix (optional) in report | Done | `include_appendix=1`: Appendix A (full SLA by category), Appendix B (workload table) in PDF/Word/HTML. |
| **2.5 Priority** | P0 chart generation + embedding | Done | |
| | P1 Full breach list | Done | |
| | P1 Consistent styling / cover | Done | |
| | P2 Appendix (full tables / Excel) | Done | Appendix in report + `GET /report/appendix` for Excel. |
| | P2 Agenda slide | Done | Agenda slide in HTML and PPTX. |

**Summary:** All items from Part 2 (lines 50–174) are now implemented. Still optional: **SVG for HTML** (PNG used).
