# ITSM Analytics – Advanced Features, Optimization & Office Use

This document outlines **advanced features**, **optimizations**, and **extra features** for office presentations and data management.

---

## 1. Advanced Features

| Feature | Description | Benefit |
|--------|-------------|--------|
| **Real-time SLA & resolve time** | Compute actual SLA met % and average resolution time from data (instead of placeholders). | Trustworthy KPIs for management. |
| **Export to Excel/CSV** | Download processed data or chart summaries as Excel/CSV for reports and sharing. | Data management and audit trail. |
| **Date range filter** | Filter tickets by created/resolved date before charts and AI. | Month/quarter comparisons. |
| **Custom column mapping** | Let user map “Source column → ticket_id/priority/…” when auto-detect fails. | Works with any ITSM export format. |
| **Trend comparison** | Compare this period vs previous period (e.g. volume, SLA, priority mix). | “Before vs after” for presentations. |
| **AI drill-down** | Click a category/priority → get AI insight for that segment only. | Deeper operational insights. |
| **SLA breach list** | Table of breached tickets (ID, category, priority, age) with optional export. | Actionable follow-up list. |
| **Scheduled / batch reports** | Backend job to process multiple files and generate PDF/Excel summary. | Recurring management reports. |
| **Multi-file comparison** | Upload 2+ files (e.g. Jan vs Feb) and show side-by-side KPIs and trends. | Period-over-period in one view. |
| **Role-based views** | Simple “Manager” vs “Analyst” views (e.g. hide raw data, show only KPIs). | Safe for different audiences. |

---

## 2. Optimizations

| Area | Current | Optimization | Impact |
|------|--------|--------------|--------|
| **Large files** | Full CSV/Excel loaded in memory. | Stream CSV in chunks; sample for charts if >N rows; full data only for export. | Handles 100k+ rows without OOM. |
| **AI latency** | Single blocking call to Gemini. | Show charts first, then stream or load AI insights asynchronously. | Dashboard feels faster. |
| **API base URL** | Hardcoded `localhost:8005`. | Use `import.meta.env.VITE_API_URL` and `.env` (e.g. `VITE_API_URL=http://localhost:8005`). | Works in dev/staging/prod. |
| **Security** | API key in backend env. | Keep Gemini key in `.env` only; never expose in frontend. Add optional API key or auth for `/upload`. | Safe for office deployment. |
| **Caching** | None. | Cache chart_data by file hash or session; reuse for same file. | Fewer duplicate processing. |
| **Frontend bundle** | Single App.jsx. | Lazy-load chart components (e.g. `React.lazy` for Recharts) and heavy views. | Faster first load. |
| **Backend** | Synchronous process_file. | Use background task (e.g. FastAPI BackgroundTasks) for AI; return chart_data immediately. | Quick chart display. |
| **Real metrics** | “2.4h” and “98.2%” hardcoded. | Compute from data: avg resolve time, SLA met %. | Accurate KPIs. |

---

## 3. Extra Features for Office Presentation & Data Management

| Feature | Purpose |
|--------|---------|
| **Presentation mode** | Fullscreen, hide sidebar, larger fonts; optional “slide” view (one chart per screen). |
| **Export dashboard** | Export current view as PDF or PNG (e.g. via browser print or html2canvas). |
| **Export data** | Export filtered/processed data to Excel/CSV (all columns or summary). |
| **Saved views / bookmarks** | Save filter presets (e.g. “Q1 Critical only”) for quick recall. |
| **Slide deck generator** | Auto-generate a simple “deck” (e.g. HTML slides) with KPIs + one chart per slide. |
| **Comment/notes** | Add text notes to a dashboard run (e.g. “Presented to leadership on 31-Jan”). |
| **Template report** | One-click “Monthly ITSM Report” with standard sections (volume, SLA, top issues, AI summary). |
| **Print-friendly CSS** | Print button or print stylesheet so dashboard prints cleanly for handouts. |
| **Data inspector** | Expand to full table with search, sort, column show/hide, and export visible rows. |
| **Comparison mode** | Upload baseline file; compare current file vs baseline (deltas for volume, SLA, etc.). |

---

## 4. Quick Wins Implemented in This Repo

The following are implemented so you can use them in your office:

1. **Export to Excel/CSV** – Download processed data from the dashboard.
2. **Presentation mode** – Fullscreen toggle, hide sidebar, focus on charts and KPIs.
3. **Real SLA % and avg resolve time** – Computed from data in the backend and shown in KPIs.
4. **Configurable API URL** – Use `.env` for frontend API base (e.g. for different environments).

---

## 5. Advanced Features to Add Next (Prioritized)

### High impact, moderate effort

| Feature | What it does | Why add it |
|--------|----------------|------------|
| **Date range filter** | Filter tickets by “from / to” (created or resolved) before charts and tables. | Compare specific months/quarters; exclude old data. |
| **SLA breach list** | Table of breached tickets: ID, category, priority, age, summary. Export to CSV. | Actionable list for follow-up; management loves it. |
| **Trend comparison** | “This period vs previous period”: volume delta, SLA delta, priority mix change. | “Before vs after” for presentations and reviews. |
| **Multi-file comparison** | Upload 2 files (e.g. Jan vs Feb); show side-by-side KPIs and workload deltas. | Period-over-period in one view without manual Excel. |
| **Custom column mapping** | UI to map “this CSV column → ticket_id / created_at / …” when auto-detect fails. | Works with any ITSM/Excel export format. |

### High impact, higher effort

| Feature | What it does | Why add it |
|--------|----------------|------------|
| **AI drill-down** | Click a category or priority → AI summary for that segment only. | Deeper insights per team or service. |
| **Scheduled / batch reports** | Backend job: process files on a schedule, generate PDF/Excel summary. | Recurring monthly/quarterly reports. |
| **Role-based views** | “Manager” (KPIs + charts only) vs “Analyst” (full data, export, filters). | Safe for different audiences in the office. |
| **Saved views / bookmarks** | Save filter presets (e.g. “Q1”, “Critical only”, “SERVER only”) and recall them. | Faster repeat analysis. |

### UX & reporting

| Feature | What it does | Why add it |
|--------|----------------|------------|
| **Print / PDF** | Print-friendly CSS + “Export as PDF” (browser print or library). | Handouts and formal reports. |
| **Slide deck generator** | One-click “Generate slides”: one KPI or chart per slide (HTML or PPT). | Ready-made deck for leadership. |
| **Template report** | “Monthly ITSM Report” button: standard sections (volume, SLA, top issues, AI summary) as one document. | Consistent monthly deliverables. |
| **Comment / notes** | Add a note to current run (e.g. “Presented to leadership 31-Jan”). Stored in session or backend. | Context for future reference. |

### Performance & scale

| Feature | What it does | Why add it |
|--------|----------------|------------|
| **Stream / chunk large files** | Process CSV in chunks; sample for charts if >50k rows; full data for export. | Handles 100k+ rows without OOM. |
| **Show charts first, AI later** | Return chart_data immediately; run AI in background and stream or poll for insights. | Dashboard feels instant. |
| **Cache by file hash** | If same file uploaded again, return cached chart_data (optional TTL). | Fewer duplicate runs. |

---

## 6. Suggested Order for Your Office Rollout

1. **Week 1:** Use current app + **Export**, **Presentation mode**, and **verification** for a trial run.
2. **Week 2:** Add **date range filter** and **SLA breach list**; validate with real ITSM export.
3. **Week 3:** Add **print-friendly** view and **trend comparison** (this period vs previous).
4. **Later:** **Multi-file comparison**, **template report**, and **saved views** for monthly reviews.

---

## 7. Environment Variables

- **Backend** (`.env` in `backend/`):  
  `GEMINI_API_KEY=your_key`
- **Frontend** (`.env` in `frontend/`):  
  `VITE_API_URL=http://localhost:8005`  
  (Change for production, e.g. `https://your-server/itsm-api`)
