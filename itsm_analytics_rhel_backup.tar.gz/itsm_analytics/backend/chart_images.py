"""
Generate chart images (PNG bytes) from chart_data for embedding in PDF, Word, PPTX, and HTML reports.
Uses matplotlib with Agg backend for headless rendering.
"""
from io import BytesIO
import base64

# Headless backend (no display)
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# App palette
PRIMARY = "#38bdf8"
PALETTE = [
    "#38bdf8", "#0ea5e9", "#0284c7", "#0369a1",  # sky blues
    "#64748b", "#94a3b8", "#cbd5e1", "#e2e8f0", "#f1f5f9",
]
SLA_COLORS = {"Met": "#22c55e", "Breached": "#ef4444", "Warning": "#f59e0b", "N/A": "#94a3b8"}


def _fig_to_png_bytes(fig, dpi=120):
    buf = BytesIO()
    fig.savefig(buf, format="png", dpi=dpi, bbox_inches="tight", facecolor="white")
    buf.seek(0)
    return buf.read()


def render_workload_bar(chart_data: dict, width_inches: float = 7, height_inches: float = 4) -> bytes:
    """Stacked bar chart: workload by month. Uses chart_data['workload'] and chart_data['categories'].
    If categories empty but workload has rows, draws simple month-wise total bar."""
    workload = chart_data.get("workload") or []
    categories = chart_data.get("categories") or []
    if not workload:
        return _empty_chart_bytes("No workload data", width_inches, height_inches)

    fig, ax = plt.subplots(figsize=(width_inches, height_inches))
    names = [r.get("name", "") for r in workload]
    x = range(len(names))
    width = 0.7

    if categories:
        left = [0.0] * len(names)
        for i, cat in enumerate(categories[:9]):
            color = PALETTE[i % len(PALETTE)]
            vals = [r.get(cat, 0) or 0 for r in workload]
            ax.bar(x, vals, width, left=left, label=cat[:20], color=color)
            left = [a + b for a, b in zip(left, vals)]
        ax.legend(loc="upper right", fontsize=7)
    else:
        totals = [r.get("total", 0) or 0 for r in workload]
        ax.bar(x, totals, width, color=PRIMARY, label="Tickets")
    ax.set_xticks(x)
    ax.set_xticklabels(names, rotation=45, ha="right", fontsize=8)
    ax.set_ylabel("Tickets")
    ax.set_title("Monthly Workload Trend")
    ax.set_facecolor("white")
    fig.patch.set_facecolor("white")
    out = _fig_to_png_bytes(fig)
    plt.close(fig)
    return out


def render_sla_pie(chart_data: dict, width_inches: float = 5, height_inches: float = 4) -> bytes:
    """Pie chart: SLA status (Met / Breached / Warning). Uses chart_data['sla']."""
    sla = chart_data.get("sla") or []
    if not sla:
        return _empty_chart_bytes("No SLA data", width_inches, height_inches)

    fig, ax = plt.subplots(figsize=(width_inches, height_inches))
    labels = [item.get("name", "N/A") for item in sla]
    sizes = [item.get("value", 0) or 0 for item in sla]
    colors = [SLA_COLORS.get(str(l).split()[0], PALETTE[i % len(PALETTE)]) for i, l in enumerate(labels)]
    ax.pie(sizes, labels=labels, autopct="%1.1f%%", colors=colors, startangle=90)
    ax.set_title("SLA Status")
    ax.set_facecolor("white")
    fig.patch.set_facecolor("white")
    out = _fig_to_png_bytes(fig)
    plt.close(fig)
    return out


def render_priority_pie(chart_data: dict, width_inches: float = 5, height_inches: float = 4) -> bytes:
    """Pie chart: priority distribution. Uses chart_data['priority']."""
    priority = chart_data.get("priority") or []
    if not priority:
        return _empty_chart_bytes("No priority data", width_inches, height_inches)

    fig, ax = plt.subplots(figsize=(width_inches, height_inches))
    labels = [item.get("name", "N/A") for item in priority]
    sizes = [item.get("value", 0) or 0 for item in priority]
    ax.pie(sizes, labels=labels, autopct="%1.1f%%", colors=PALETTE[: len(labels)], startangle=90)
    ax.set_title("Priority Distribution")
    ax.set_facecolor("white")
    fig.patch.set_facecolor("white")
    out = _fig_to_png_bytes(fig)
    plt.close(fig)
    return out


def render_services_bar(chart_data: dict, width_inches: float = 6, height_inches: float = 4) -> bytes:
    """Horizontal bar chart: top services by volume. Uses chart_data['services']."""
    services = chart_data.get("services") or []
    if not services:
        return _empty_chart_bytes("No services data", width_inches, height_inches)

    fig, ax = plt.subplots(figsize=(width_inches, height_inches))
    names = []
    vals = []
    for item in services[:10]:
        name = item.get("name", item) if isinstance(item, dict) else item
        val = item.get("value", 0) if isinstance(item, dict) else 0
        names.append(str(name)[:30])
        vals.append(val)
    y_pos = range(len(names))
    ax.barh(y_pos, vals, color=PRIMARY, height=0.7)
    ax.set_yticks(y_pos)
    ax.set_yticklabels(names, fontsize=8)
    ax.set_xlabel("Count")
    ax.set_title("Top Services (Volume)")
    ax.set_facecolor("white")
    fig.patch.set_facecolor("white")
    out = _fig_to_png_bytes(fig)
    plt.close(fig)
    return out


def render_priority_by_month_bar(chart_data: dict, width_inches: float = 7, height_inches: float = 4) -> bytes:
    """Stacked bar chart: priority distribution by month. Uses chart_data['priority_by_month']."""
    pbm = chart_data.get("priority_by_month") or []
    if not pbm:
        return _empty_chart_bytes("No priority-by-month data", width_inches, height_inches)
    priority_keys = [k for k in pbm[0].keys() if k != "name"]
    if not priority_keys:
        return _empty_chart_bytes("No priority-by-month data", width_inches, height_inches)

    fig, ax = plt.subplots(figsize=(width_inches, height_inches))
    names = [r.get("name", "") for r in pbm]
    x = range(len(names))
    width = 0.7
    left = [0.0] * len(names)
    for i, key in enumerate(priority_keys[:8]):
        color = PALETTE[i % len(PALETTE)]
        vals = [r.get(key, 0) or 0 for r in pbm]
        ax.bar(x, vals, width, left=left, label=str(key)[:15], color=color)
        left = [a + b for a, b in zip(left, vals)]
    ax.set_xticks(x)
    ax.set_xticklabels(names, rotation=45, ha="right", fontsize=8)
    ax.set_ylabel("Tickets")
    ax.set_title("Priority by Month")
    ax.legend(loc="upper right", fontsize=7)
    ax.set_facecolor("white")
    fig.patch.set_facecolor("white")
    out = _fig_to_png_bytes(fig)
    plt.close(fig)
    return out


def render_workload_by_group_bar(chart_data: dict, width_inches: float = 7, height_inches: float = 4) -> bytes:
    """Stacked bar chart: workload by 5 groups (Infrastructure, Applications, etc.) by month."""
    wbg = chart_data.get("workload_by_group") or {}
    months = wbg.get("months") or []
    rows = wbg.get("rows") or []
    if not months or not rows:
        return _empty_chart_bytes("No workload-by-group data", width_inches, height_inches)

    fig, ax = plt.subplots(figsize=(width_inches, height_inches))
    x = range(len(months))
    width = 0.7
    left = [0.0] * len(months)
    for i, row in enumerate(rows[:6]):
        color = PALETTE[i % len(PALETTE)]
        vals = [row.get(m, 0) or 0 for m in months]
        ax.bar(x, vals, width, left=left, label=(row.get("name") or "?")[:18], color=color)
        left = [a + b for a, b in zip(left, vals)]
    ax.set_xticks(x)
    ax.set_xticklabels(months, rotation=45, ha="right", fontsize=8)
    ax.set_ylabel("Tickets")
    ax.set_title("Workload by Group (Month-wise)")
    ax.legend(loc="upper right", fontsize=7)
    ax.set_facecolor("white")
    fig.patch.set_facecolor("white")
    out = _fig_to_png_bytes(fig)
    plt.close(fig)
    return out


def render_sla_by_category_bar(chart_data: dict, width_inches: float = 7, height_inches: float = 4) -> bytes:
    """Horizontal bar chart: SLA % by category. Uses chart_data['sla_by_category']."""
    sbc = chart_data.get("sla_by_category") or []
    if not sbc:
        return _empty_chart_bytes("No SLA by category data", width_inches, height_inches)
    # Show top 12 for readability; category name and sla_pct
    sbc = sbc[:12]
    names = [str(r.get("category", ""))[:28] for r in sbc]
    vals = [r.get("sla_pct", 0) or 0 for r in sbc]
    fig, ax = plt.subplots(figsize=(width_inches, height_inches))
    y_pos = range(len(names))
    colors = [PRIMARY if v >= 90 else "#f59e0b" if v >= 70 else "#ef4444" for v in vals]
    ax.barh(y_pos, vals, color=colors, height=0.7)
    ax.set_yticks(y_pos)
    ax.set_yticklabels(names, fontsize=8)
    ax.set_xlabel("SLA %")
    ax.set_title("SLA by Category")
    ax.set_xlim(0, 105)
    ax.set_facecolor("white")
    fig.patch.set_facecolor("white")
    out = _fig_to_png_bytes(fig)
    plt.close(fig)
    return out


def _empty_chart_bytes(message: str, width_inches: float, height_inches: float) -> bytes:
    fig, ax = plt.subplots(figsize=(width_inches, height_inches))
    ax.text(0.5, 0.5, message, ha="center", va="center", fontsize=12)
    ax.set_facecolor("white")
    fig.patch.set_facecolor("white")
    out = _fig_to_png_bytes(fig)
    plt.close(fig)
    return out


def get_chart_images_base64(chart_data: dict, report_style: bool = True) -> dict:
    """Return dict of chart name -> base64 PNG string for HTML embedding.
    report_style: slightly larger for report; False for slides."""
    w, h = (6, 3.5) if report_style else (7, 4)
    out = {}
    try:
        workload_png = render_workload_bar(chart_data, w + 1, h)
        out["workload"] = base64.b64encode(workload_png).decode("utf-8")
    except Exception:
        out["workload"] = None
    try:
        pbm_png = render_priority_by_month_bar(chart_data, w + 1, h)
        out["priority_by_month"] = base64.b64encode(pbm_png).decode("utf-8")
    except Exception:
        out["priority_by_month"] = None
    try:
        wbg_png = render_workload_by_group_bar(chart_data, w + 1, h)
        out["workload_by_group"] = base64.b64encode(wbg_png).decode("utf-8")
    except Exception:
        out["workload_by_group"] = None
    try:
        sla_png = render_sla_pie(chart_data, 5, 4)
        out["sla"] = base64.b64encode(sla_png).decode("utf-8")
    except Exception:
        out["sla"] = None
    try:
        sbc_png = render_sla_by_category_bar(chart_data, w, h)
        out["sla_by_category"] = base64.b64encode(sbc_png).decode("utf-8")
    except Exception:
        out["sla_by_category"] = None
    try:
        services_png = render_services_bar(chart_data, w, h)
        out["services"] = base64.b64encode(services_png).decode("utf-8")
    except Exception:
        out["services"] = None
    try:
        priority_png = render_priority_pie(chart_data, 5, 4)
        out["priority"] = base64.b64encode(priority_png).decode("utf-8")
    except Exception:
        out["priority"] = None
    return out
