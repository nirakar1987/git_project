"""PostgreSQL session storage for ITSM Analytics."""
import os
import json
from contextlib import contextmanager
from datetime import datetime

from sqlalchemy import create_engine, Column, String, DateTime, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import declarative_base, sessionmaker, Session

Base = declarative_base()
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://itsm:itsm_secret@localhost:5432/itsm_analytics")


class AnalyticsSession(Base):
    __tablename__ = "analytics_sessions"

    session_id = Column(String(36), primary_key=True)
    filename = Column(String(512), nullable=False)
    chart_data = Column(JSONB, nullable=True)  # full chart_data dict
    ai_insights = Column(JSONB, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "session_id": self.session_id,
            "filename": self.filename,
            "chart_data": self.chart_data,
            "ai_insights": self.ai_insights,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def init_db():
    """Create tables if they don't exist."""
    Base.metadata.create_all(bind=engine)


@contextmanager
def get_db_session():
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def save_session(session_id: str, filename: str, chart_data: dict, ai_insights: dict = None):
    """Persist session to PostgreSQL."""
    with get_db_session() as db:
        row = db.query(AnalyticsSession).filter(AnalyticsSession.session_id == session_id).first()
        if row:
            row.filename = filename
            row.chart_data = chart_data
            row.ai_insights = ai_insights
        else:
            db.add(AnalyticsSession(
                session_id=session_id,
                filename=filename,
                chart_data=chart_data,
                ai_insights=ai_insights,
            ))


def get_session_from_db(session_id: str):
    """Load session metadata from PostgreSQL. Returns dict with filename, chart_data, ai_insights or None."""
    db = SessionLocal()
    try:
        row = db.query(AnalyticsSession).filter(AnalyticsSession.session_id == session_id).first()
        if not row:
            return None
        return {
            "filename": row.filename,
            "chart_data": row.chart_data,
            "ai_insights": row.ai_insights,
        }
    finally:
        db.close()


def update_session_ai_insights(session_id: str, ai_insights: dict):
    """Update only ai_insights for a session."""
    with get_db_session() as db:
        row = db.query(AnalyticsSession).filter(AnalyticsSession.session_id == session_id).first()
        if row:
            row.ai_insights = ai_insights


def list_sessions(limit: int = 50):
    """List saved sessions (session_id, filename, created_at) ordered by created_at desc."""
    db = SessionLocal()
    try:
        rows = (
            db.query(AnalyticsSession.session_id, AnalyticsSession.filename, AnalyticsSession.created_at)
            .order_by(AnalyticsSession.created_at.desc())
            .limit(limit)
            .all()
        )
        return [
            {"session_id": r.session_id, "filename": r.filename, "created_at": r.created_at.isoformat() if r.created_at else None}
            for r in rows
        ]
    finally:
        db.close()
