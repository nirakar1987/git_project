"""
Template Monthly Report (PDF/Word) and Slide Deck (HTML/PPTX) generation.
Uses chart_data, ai_insights, and breach_list from processor.get_chart_data().
Embeds chart images (workload, SLA, services) via chart_images module.
"""
from io import BytesIO
from datetime import datetime

from chart_images import (
    render_workload_bar,
    render_sla_pie,
    render_services_bar,
    render_priority_by_month_bar,
    render_workload_by_group_bar,
    render_sla_by_category_bar,
    get_chart_images_base64,
)


def _safe(val, default=""):
    return default if val is None else str(val)


def _escape_paragraph(s: str) -> str:
    """Escape text for reportlab Paragraph (XML-safe)."""
    if not s:
        return ""
    s = str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return s


def _breach_limit(breach_list: list, full_breach_list: bool, max_breach: int):
    """Apply breach list cap: full_breach_list=True or max_breach=0 means no cap."""
    if full_breach_list or max_breach == 0:
        return breach_list
    return breach_list[: max_breach if max_breach > 0 else 50]


def _sla_category_limit(sla_list: list, max_categories: int):
    """For main table: max_categories=0 means all; >0 means top N."""
    if not sla_list:
        return sla_list
    if max_categories == 0:
        return sla_list
    return sla_list[: max_categories]


def build_monthly_report_html(
    chart_data: dict,
    ai_insights: dict,
    filename: str = "Report",
    full_breach_list: bool = False,
    max_breach: int = 50,
    max_categories: int = 12,
    include_appendix: bool = False,
) -> str:
    """Full HTML report: volume, SLA, top services, breach list, AI summary; includes chart images."""
    total = chart_data.get("total_tickets") or 0
    sla_pct = chart_data.get("sla_met_pct") or 0
    avg_resolve = chart_data.get("avg_resolve_hours")
    data_period = chart_data.get("data_period") or "N/A"
    images = get_chart_images_base64(chart_data, report_style=True)

    html = f"""<!DOCTYPE html><html><head><meta charset="utf-8"/><title>Monthly ITSM Report - {_safe(filename)}</title>
<style>
body {{ font-family: system-ui, 'Segoe UI', sans-serif; margin: 32px; background: #fff; color: #1e293b; max-width: 900px; }}
h1 {{ color: #0f172a; border-bottom: 2px solid #38bdf8; padding-bottom: 8px; }}
h2 {{ color: #334155; margin-top: 28px; }}
table {{ border-collapse: collapse; width: 100%; margin-top: 8px; table-layout: fixed; }}
th, td {{ border: 1px solid #cbd5e1; padding: 10px 12px; text-align: left; word-wrap: break-word; overflow-wrap: break-word; }}
th {{ background: #f1f5f9; font-weight: 600; }}
.meta {{ color: #64748b; font-size: 14px; margin-bottom: 24px; }}
.kpi {{ display: flex; gap: 24px; flex-wrap: wrap; margin: 16px 0; }}
.kpi span {{ background: #f0f9ff; padding: 12px 20px; border-radius: 8px; font-weight: 600; }}
.chart {{ margin: 16px 0; max-width: 100%; }}
</style></head><body>
<h1>Monthly ITSM Report</h1>
<p class="meta">Data source: {_safe(filename)} | Period: {data_period} | Generated: {datetime.now().strftime('%d-%b-%Y %H:%M')}</p>

<h2>1. Key metrics</h2>
<div class="kpi">
<span>Total tickets: {total}</span>
<span>SLA met: {sla_pct}%</span>
<span>Avg resolve: {_safe(avg_resolve, 'N/A')}h</span>
</div>"""
    if images.get("workload"):
        html += f'<p class="chart"><img src="data:image/png;base64,{images["workload"]}" alt="Monthly Workload Trend" class="chart" style="max-width:100%;height:auto;" /></p>'
    if images.get("priority_by_month"):
        html += '<h2>1b. Priority by month</h2>'
        html += f'<p class="chart"><img src="data:image/png;base64,{images["priority_by_month"]}" alt="Priority by Month" class="chart" style="max-width:100%;height:auto;" /></p>'
    if images.get("workload_by_group"):
        html += '<h2>1c. Workload by group (month-wise)</h2>'
        html += f'<p class="chart"><img src="data:image/png;base64,{images["workload_by_group"]}" alt="Workload by Group" class="chart" style="max-width:100%;height:auto;" /></p>'

    html += "<h2>2. SLA by category</h2>"
    if images.get("sla"):
        html += f'<p class="chart"><img src="data:image/png;base64,{images["sla"]}" alt="SLA Status" class="chart" style="max-width:100%;height:auto;" /></p>'
    if images.get("sla_by_category"):
        html += f'<p class="chart"><img src="data:image/png;base64,{images["sla_by_category"]}" alt="SLA by Category" class="chart" style="max-width:100%;height:auto;" /></p>'
    sla_cat = _sla_category_limit(chart_data.get("sla_by_category") or [], max_categories)
    html += "<table><tr><th>Category</th><th>Breached</th><th>Met</th><th>Total</th><th>SLA %</th></tr>"
    for row in sla_cat:
        html += f"<tr><td>{_safe(row.get('category'))}</td><td>{row.get('breached', 0)}</td><td>{row.get('met', 0)}</td><td>{row.get('total', 0)}</td><td>{row.get('sla_pct', 0)}%</td></tr>"
    html += "</table>"

    html += "<h2>3. Top services (volume)</h2>"
    if images.get("services"):
        html += f'<p class="chart"><img src="data:image/png;base64,{images["services"]}" alt="Top Services" class="chart" style="max-width:100%;height:auto;" /></p>'
    html += "<table><tr><th>Service</th><th>Count</th></tr>"
    for item in (chart_data.get("services") or [])[:10]:
        name = item.get("name", item) if isinstance(item, dict) else item
        val = item.get("value", item) if isinstance(item, dict) else 0
        html += f"<tr><td>{_safe(name)}</td><td>{val}</td></tr>"
    html += "</table>"

    breach_list = _breach_limit(chart_data.get("breach_list") or [], full_breach_list, max_breach)
    cap_label = "all" if (full_breach_list or max_breach == 0) else f"top {len(breach_list)}"
    html += f"<h2>4. SLA breach list ({cap_label})</h2><p>{len(chart_data.get('breach_list') or [])} breached ticket(s).</p>"
    html += '<table class="breach-table"><colgroup><col style="width:11%"/><col style="width:22%"/><col style="width:10%"/><col style="width:42%"/><col style="width:8%"/></colgroup>'
    html += "<tr><th>Ticket ID</th><th>Category</th><th>Priority</th><th>Summary</th><th>Resolution (days)</th></tr>"
    for row in breach_list:
        summ = _safe(row.get("summary"))[:200]
        html += f"<tr><td>{_safe(row.get('ticket_id'))}</td><td>{_safe(row.get('category'))}</td><td>{_safe(row.get('priority'))}</td><td>{summ}</td><td>{_safe(row.get('resolution_days'))}</td></tr>"
    html += "</table>"

    html += "<h2>5. AI summary</h2>"
    html += f"<p>{_safe(ai_insights.get('summary', 'N/A'))}</p>"
    html += f"<p><strong>Recommendation:</strong> {_safe(ai_insights.get('recommendation', 'N/A'))}</p>"
    if include_appendix:
        html += "<h2>Appendix A – Full SLA by category</h2><table><tr><th>Category</th><th>Breached</th><th>Met</th><th>Total</th><th>SLA %</th></tr>"
        for row in (chart_data.get("sla_by_category") or []):
            html += f"<tr><td>{_safe(row.get('category'))}</td><td>{row.get('breached', 0)}</td><td>{row.get('met', 0)}</td><td>{row.get('total', 0)}</td><td>{row.get('sla_pct', 0)}%</td></tr>"
        html += "</table>"
        wtab = chart_data.get("workload_table") or {}
        months = wtab.get("months") or []
        rows = wtab.get("rows") or []
        if months and rows:
            html += "<h2>Appendix B – Workload table (service × month)</h2><table><tr><th>Service</th>"
            for m in months:
                html += f"<th>{_safe(m)}</th>"
            html += "<th>Total</th></tr>"
            for r in rows[:50]:
                html += f"<tr><td>{_safe(r.get('name'))}</td>"
                for m in months:
                    html += f"<td>{r.get(m, 0)}</td>"
                html += f"<td>{r.get('total', 0)}</td></tr>"
            gt = wtab.get("grand_total_row")
            if gt:
                html += "<tr><td><strong>Grand Total</strong></td>"
                for m in months:
                    html += f"<td>{gt.get(m, 0)}</td>"
                html += f"<td>{gt.get('total', 0)}</td></tr>"
            html += "</table>"
    html += "</body></html>"
    return html


def build_monthly_report_pdf(
    chart_data: dict,
    ai_insights: dict,
    filename: str = "Report",
    full_breach_list: bool = False,
    max_breach: int = 50,
    max_categories: int = 12,
    include_appendix: bool = False,
) -> bytes:
    """Generate PDF using reportlab; includes cover, chart images, optional full breach list, appendix, page numbers."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image

    def _footer(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 9)
        canvas.drawRightString(A4[0] - 2*cm, 1*cm, f"Page {canvas.getPageNumber()}")
        canvas.restoreState()

    buf = BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=A4, rightMargin=2*cm, leftMargin=2*cm, topMargin=1.5*cm, bottomMargin=1.5*cm,
        onFirstPage=_footer, onLaterPage=_footer,
    )
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(name="ReportTitle", parent=styles["Heading1"], fontSize=18, spaceAfter=12)
    h2_style = styles["Heading2"]

    story = []
    # Cover
    story.append(Paragraph("Monthly ITSM Report", title_style))
    story.append(Paragraph(f"Data source: {_safe(filename)}", styles["Normal"]))
    story.append(Paragraph(f"Period: {chart_data.get('data_period') or 'N/A'}", styles["Normal"]))
    story.append(Paragraph(f"Generated: {datetime.now().strftime('%d-%b-%Y %H:%M')}", styles["Normal"]))
    story.append(Spacer(1, 24))

    total = chart_data.get("total_tickets") or 0
    sla_pct = chart_data.get("sla_met_pct") or 0
    avg_resolve = chart_data.get("avg_resolve_hours")
    story.append(Paragraph("1. Key metrics", h2_style))
    story.append(Paragraph(f"Total tickets: {total} | SLA met: {sla_pct}% | Avg resolve: {_safe(avg_resolve, 'N/A')}h", styles["Normal"]))
    story.append(Spacer(1, 12))

    # Workload chart (month-wise)
    try:
        workload_png = render_workload_bar(chart_data, 6, 3.5)
        story.append(Image(BytesIO(workload_png), width=14*cm, height=7*cm))
        story.append(Spacer(1, 12))
    except Exception:
        pass
    # Priority by month (month-wise bar)
    try:
        pbm_png = render_priority_by_month_bar(chart_data, 6, 3.5)
        story.append(Paragraph("1b. Priority by month", h2_style))
        story.append(Image(BytesIO(pbm_png), width=14*cm, height=7*cm))
        story.append(Spacer(1, 12))
    except Exception:
        pass
    # Workload by group (month-wise bar)
    try:
        wbg_png = render_workload_by_group_bar(chart_data, 6, 3.5)
        story.append(Paragraph("1c. Workload by group (month-wise)", h2_style))
        story.append(Image(BytesIO(wbg_png), width=14*cm, height=7*cm))
        story.append(Spacer(1, 12))
    except Exception:
        pass

    story.append(Paragraph("2. SLA by category", h2_style))
    try:
        sla_png = render_sla_pie(chart_data, 5, 4)
        story.append(Image(BytesIO(sla_png), width=10*cm, height=8*cm))
        story.append(Spacer(1, 8))
    except Exception:
        pass
    try:
        sbc_png = render_sla_by_category_bar(chart_data, 6, 3.5)
        story.append(Image(BytesIO(sbc_png), width=14*cm, height=7*cm))
        story.append(Spacer(1, 8))
    except Exception:
        pass
    sla_cat = _sla_category_limit(chart_data.get("sla_by_category") or [], max_categories)
    sla_rows = [["Category", "Breached", "Met", "Total", "SLA %"]]
    for row in sla_cat:
        sla_rows.append([_safe(row.get("category")), str(row.get("breached", 0)), str(row.get("met", 0)), str(row.get("total", 0)), f"{row.get('sla_pct', 0)}%"])
    t = Table(sla_rows)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f1f5f9")), ("GRID", (0, 0), (-1, -1), 0.5, colors.grey)]))
    story.append(t)
    story.append(Spacer(1, 12))

    story.append(Paragraph("3. Top services", h2_style))
    try:
        svc_png = render_services_bar(chart_data, 6, 3.5)
        story.append(Image(BytesIO(svc_png), width=14*cm, height=7*cm))
        story.append(Spacer(1, 8))
    except Exception:
        pass
    svc_rows = [["Service", "Count"]]
    for item in (chart_data.get("services") or [])[:10]:
        name = item.get("name", item) if isinstance(item, dict) else item
        val = item.get("value", 0) if isinstance(item, dict) else 0
        svc_rows.append([_safe(name), str(val)])
    t2 = Table(svc_rows)
    t2.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f1f5f9")), ("GRID", (0, 0), (-1, -1), 0.5, colors.grey)]))
    story.append(t2)
    story.append(Spacer(1, 12))

    breach_list = chart_data.get("breach_list") or []
    breach_display = _breach_limit(breach_list, full_breach_list, max_breach)
    cap_label = "all" if (full_breach_list or max_breach == 0) else f"top {len(breach_display)}"
    story.append(Paragraph(f"4. SLA breach list ({cap_label}, total {len(breach_list)})", h2_style))
    # Use Paragraph in cells so text wraps; wider columns to avoid overlap (points: ~70, 160, 55, 195 = 480)
    cell_style = ParagraphStyle(name="TableCell", parent=styles["Normal"], fontSize=8, leading=9)
    col_widths = [70, 160, 55, 195]  # Ticket ID, Category, Priority, Summary
    breach_table_data = [
        [
            Paragraph(_escape_paragraph("Ticket ID"), cell_style),
            Paragraph(_escape_paragraph("Category"), cell_style),
            Paragraph(_escape_paragraph("Priority"), cell_style),
            Paragraph(_escape_paragraph("Summary"), cell_style),
        ]
    ]
    for row in breach_display:
        tid = _escape_paragraph(_safe(row.get("ticket_id")))
        cat = _escape_paragraph(_safe(row.get("category")))
        pri = _escape_paragraph(_safe(row.get("priority")))
        summ = _escape_paragraph(_safe(row.get("summary"))[:200])  # allow longer summary, Paragraph wraps
        breach_table_data.append([
            Paragraph(tid, cell_style),
            Paragraph(cat, cell_style),
            Paragraph(pri, cell_style),
            Paragraph(summ, cell_style),
        ])
    if len(breach_table_data) > 1:
        t3 = Table(breach_table_data, colWidths=col_widths, repeatRows=1)
        t3.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#fef2f2")),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ]))
        story.append(t3)
    else:
        story.append(Paragraph("No breached tickets.", styles["Normal"]))
    story.append(Spacer(1, 12))

    story.append(Paragraph("5. AI summary", h2_style))
    story.append(Paragraph(_safe(ai_insights.get("summary", "N/A")), styles["Normal"]))
    story.append(Paragraph(f"<b>Recommendation:</b> {_safe(ai_insights.get('recommendation', 'N/A'))}", styles["Normal"]))

    if include_appendix:
        story.append(PageBreak())
        story.append(Paragraph("Appendix A – Full SLA by category", h2_style))
        sla_full = chart_data.get("sla_by_category") or []
        app_sla_rows = [["Category", "Breached", "Met", "Total", "SLA %"]]
        for row in sla_full:
            app_sla_rows.append([_safe(row.get("category")), str(row.get("breached", 0)), str(row.get("met", 0)), str(row.get("total", 0)), f"{row.get('sla_pct', 0)}%"])
        t_app = Table(app_sla_rows, repeatRows=1)
        t_app.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f1f5f9")), ("GRID", (0, 0), (-1, -1), 0.5, colors.grey)]))
        story.append(t_app)
        story.append(Spacer(1, 16))
        wtab = chart_data.get("workload_table") or {}
        months = wtab.get("months") or []
        rows = wtab.get("rows") or []
        if months and rows:
            story.append(Paragraph("Appendix B – Workload table (service × month)", h2_style))
            wt_rows = [["Service"] + [_safe(m) for m in months] + ["Total"]]
            for r in rows[:50]:
                wt_rows.append([_safe(r.get("name"))] + [str(r.get(m, 0)) for m in months] + [str(r.get("total", 0))])
            gt = wtab.get("grand_total_row")
            if gt:
                wt_rows.append([_safe(gt.get("name"))] + [str(gt.get(m, 0)) for m in months] + [str(gt.get("total", 0))])
            t_wt = Table(wt_rows, repeatRows=1)
            t_wt.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f1f5f9")), ("GRID", (0, 0), (-1, -1), 0.5, colors.grey), ("FONTSIZE", (0, 0), (-1, -1), 7)]))
            story.append(t_wt)

    doc.build(story)
    buf.seek(0)
    return buf.read()


def build_monthly_report_docx(
    chart_data: dict,
    ai_insights: dict,
    filename: str = "Report",
    full_breach_list: bool = False,
    max_breach: int = 50,
    max_categories: int = 12,
    include_appendix: bool = False,
) -> bytes:
    """Generate Word document using python-docx; includes chart images, optional full breach list, appendix."""
    from docx import Document
    from docx.shared import Inches, Pt

    doc = Document()
    doc.add_heading("Monthly ITSM Report", 0)
    doc.add_paragraph(f"Data source: {filename}")
    doc.add_paragraph(f"Period: {chart_data.get('data_period') or 'N/A'} | Generated: {datetime.now().strftime('%d-%b-%Y %H:%M')}")

    total = chart_data.get("total_tickets") or 0
    sla_pct = chart_data.get("sla_met_pct") or 0
    avg_resolve = chart_data.get("avg_resolve_hours")
    doc.add_heading("1. Key metrics", level=1)
    doc.add_paragraph(f"Total tickets: {total} | SLA met: {sla_pct}% | Avg resolve: {avg_resolve or 'N/A'}h")
    try:
        workload_png = render_workload_bar(chart_data, 6, 3.5)
        doc.add_picture(BytesIO(workload_png), width=Inches(5.5))
    except Exception:
        pass
    try:
        pbm_png = render_priority_by_month_bar(chart_data, 6, 3.5)
        doc.add_heading("1b. Priority by month", level=1)
        doc.add_picture(BytesIO(pbm_png), width=Inches(5.5))
    except Exception:
        pass
    try:
        wbg_png = render_workload_by_group_bar(chart_data, 6, 3.5)
        doc.add_heading("1c. Workload by group (month-wise)", level=1)
        doc.add_picture(BytesIO(wbg_png), width=Inches(5.5))
    except Exception:
        pass

    doc.add_heading("2. SLA by category", level=1)
    try:
        sla_png = render_sla_pie(chart_data, 5, 4)
        doc.add_picture(BytesIO(sla_png), width=Inches(4))
    except Exception:
        pass
    try:
        sbc_png = render_sla_by_category_bar(chart_data, 6, 3.5)
        doc.add_picture(BytesIO(sbc_png), width=Inches(5.5))
    except Exception:
        pass
    sla_cat = _sla_category_limit(chart_data.get("sla_by_category") or [], max_categories)
    sla_rows = [["Category", "Breached", "Met", "Total", "SLA %"]]
    for row in sla_cat:
        sla_rows.append([_safe(row.get("category")), str(row.get("breached", 0)), str(row.get("met", 0)), str(row.get("total", 0)), f"{row.get('sla_pct', 0)}%"])
    t = doc.add_table(rows=len(sla_rows), cols=5)
    for i, row in enumerate(sla_rows):
        for j, cell in enumerate(row):
            t.rows[i].cells[j].text = cell
    doc.add_paragraph()

    doc.add_heading("3. Top services", level=1)
    try:
        svc_png = render_services_bar(chart_data, 6, 3.5)
        doc.add_picture(BytesIO(svc_png), width=Inches(5.5))
    except Exception:
        pass
    svc_rows = [["Service", "Count"]]
    for item in (chart_data.get("services") or [])[:10]:
        name = item.get("name", item) if isinstance(item, dict) else item
        val = item.get("value", 0) if isinstance(item, dict) else 0
        svc_rows.append([_safe(name), str(val)])
    t2 = doc.add_table(rows=len(svc_rows), cols=2)
    for i, row in enumerate(svc_rows):
        for j, cell in enumerate(row):
            t2.rows[i].cells[j].text = cell
    doc.add_paragraph()

    breach_list = chart_data.get("breach_list") or []
    breach_display = _breach_limit(breach_list, full_breach_list, max_breach)
    cap_label = "all" if (full_breach_list or max_breach == 0) else f"top {len(breach_display)}"
    doc.add_heading(f"4. SLA breach list ({cap_label}, total {len(breach_list)})", level=1)
    breach_rows = [["Ticket ID", "Category", "Priority", "Summary"]]
    for row in breach_display:
        breach_rows.append([
            _safe(row.get("ticket_id")),
            _safe(row.get("category")),
            _safe(row.get("priority")),
            _safe(row.get("summary"))[:250],  # allow longer summary; Word wraps in cell
        ])
    t3 = doc.add_table(rows=len(breach_rows), cols=4)
    # Set column widths so Category and Summary have room (Ticket ID, Category, Priority, Summary)
    t3.columns[0].width = Inches(1.1)
    t3.columns[1].width = Inches(2.4)
    t3.columns[2].width = Inches(0.8)
    t3.columns[3].width = Inches(3.2)
    for i, row in enumerate(breach_rows):
        for j, cell in enumerate(row):
            t3.rows[i].cells[j].text = cell
    doc.add_paragraph()

    doc.add_heading("5. AI summary", level=1)
    doc.add_paragraph(_safe(ai_insights.get("summary", "N/A")))
    doc.add_paragraph(f"Recommendation: {_safe(ai_insights.get('recommendation', 'N/A'))}")

    if include_appendix:
        from docx.enum.text import WD_BREAK
        p_break = doc.add_paragraph()
        p_break.add_run().add_break(WD_BREAK.PAGE)
        doc.add_heading("Appendix A – Full SLA by category", level=1)
        sla_full = chart_data.get("sla_by_category") or []
        app_rows = [["Category", "Breached", "Met", "Total", "SLA %"]]
        for row in sla_full:
            app_rows.append([_safe(row.get("category")), str(row.get("breached", 0)), str(row.get("met", 0)), str(row.get("total", 0)), f"{row.get('sla_pct', 0)}%"])
        t_app = doc.add_table(rows=len(app_rows), cols=5)
        for i, row in enumerate(app_rows):
            for j, cell in enumerate(row):
                t_app.rows[i].cells[j].text = cell
        doc.add_paragraph()
        wtab = chart_data.get("workload_table") or {}
        months = wtab.get("months") or []
        rows = wtab.get("rows") or []
        if months and rows:
            doc.add_heading("Appendix B – Workload table (service × month)", level=1)
            wt_rows = [["Service"] + list(months) + ["Total"]]
            for r in rows[:50]:
                wt_rows.append([_safe(r.get("name"))] + [str(r.get(m, 0)) for m in months] + [str(r.get("total", 0))])
            gt = wtab.get("grand_total_row")
            if gt:
                wt_rows.append([_safe(gt.get("name"))] + [str(gt.get(m, 0)) for m in months] + [str(gt.get("total", 0))])
            t_wt = doc.add_table(rows=len(wt_rows), cols=len(wt_rows[0]))
            for i, row in enumerate(wt_rows):
                for j, cell in enumerate(row):
                    t_wt.rows[i].cells[j].text = str(cell)
            doc.add_paragraph()

    buf = BytesIO()
    doc.save(buf)
    buf.seek(0)
    return buf.read()


def build_slides_html(chart_data: dict, ai_insights: dict, filename: str = "Report") -> str:
    """One slide per section: title, KPIs, workload chart, SLA chart, SLA table, services chart, breach summary, AI summary."""
    total = chart_data.get("total_tickets") or 0
    sla_pct = chart_data.get("sla_met_pct") or 0
    avg_resolve = chart_data.get("avg_resolve_hours")
    data_period = chart_data.get("data_period") or "N/A"
    breach_list = chart_data.get("breach_list") or []
    breach_count = len(breach_list)
    images = get_chart_images_base64(chart_data, report_style=False)

    html = f"""<!DOCTYPE html><html><head><meta charset="utf-8"/><title>ITSM Presentation - {_safe(filename)}</title>
<style>
* {{ box-sizing: border-box; }}
body {{ margin: 0; font-family: system-ui, 'Segoe UI', sans-serif; background: #0f172a; color: #e2e8f0; }}
.slide {{ min-height: 100vh; padding: 48px 64px; display: flex; flex-direction: column; justify-content: center; }}
.slide h1 {{ font-size: 2.2rem; margin: 0 0 16px 0; color: #38bdf8; }}
.slide h2 {{ font-size: 1.5rem; margin: 24px 0 12px 0; color: #94a3b8; }}
.slide table {{ border-collapse: collapse; width: 100%; max-width: 800px; margin-top: 12px; }}
.slide th, .slide td {{ border: 1px solid #334155; padding: 10px 14px; text-align: left; }}
.slide th {{ background: #1e293b; color: #94a3b8; }}
.slide .kpi {{ display: flex; gap: 32px; flex-wrap: wrap; margin: 16px 0; }}
.slide .kpi span {{ font-size: 1.5rem; font-weight: 700; color: #38bdf8; }}
.slide .meta {{ color: #64748b; font-size: 1rem; }}
.slide .chart-img {{ max-width: 100%; max-height: 55vh; object-fit: contain; margin-top: 16px; }}
</style></head><body>"""

    # Slide 1: Title
    html += f'<section class="slide"><h1>ITSM Analytics</h1><p class="meta">Monthly Report – {_safe(filename)}</p><p class="meta">Period: {data_period}</p><p class="meta">Generated: {datetime.now().strftime("%d-%b-%Y %H:%M")}</p></section>'

    # Slide 2: Agenda
    html += '''<section class="slide"><h2>Agenda</h2><ul style="font-size:1.1rem;line-height:1.8;">
<li>1. Key metrics</li><li>2. Workload trend (month-wise)</li><li>3. Priority by month / Workload by group</li>
<li>4. SLA status & SLA by category</li><li>5. Top services</li><li>6. SLA breach summary</li><li>7. AI summary</li>
</ul></section>'''

    # Slide 3: KPIs
    html += '<section class="slide"><h2>Key metrics</h2><div class="kpi"><span>Total tickets: ' + str(total) + '</span><span>SLA met: ' + str(sla_pct) + '%</span><span>Avg resolve: ' + _safe(avg_resolve, 'N/A') + 'h</span></div></section>'

    # Slide 3: Workload chart (month-wise)
    if images.get("workload"):
        html += f'<section class="slide"><h2>Monthly workload trend</h2><img class="chart-img" src="data:image/png;base64,{images["workload"]}" alt="Workload" /></section>'
    else:
        html += '<section class="slide"><h2>Monthly workload trend</h2><p class="meta">No workload data.</p></section>'
    if images.get("priority_by_month"):
        html += f'<section class="slide"><h2>Priority by month</h2><img class="chart-img" src="data:image/png;base64,{images["priority_by_month"]}" alt="Priority by Month" /></section>'
    if images.get("workload_by_group"):
        html += f'<section class="slide"><h2>Workload by group (month-wise)</h2><img class="chart-img" src="data:image/png;base64,{images["workload_by_group"]}" alt="Workload by Group" /></section>'

    # Slide: SLA pie chart
    if images.get("sla"):
        html += f'<section class="slide"><h2>SLA status</h2><img class="chart-img" src="data:image/png;base64,{images["sla"]}" alt="SLA" /></section>'
    if images.get("sla_by_category"):
        html += f'<section class="slide"><h2>SLA by category</h2><img class="chart-img" src="data:image/png;base64,{images["sla_by_category"]}" alt="SLA by Category" /></section>'
    # Slide: SLA by category table
    html += '<section class="slide"><h2>SLA by category</h2><table><tr><th>Category</th><th>Breached</th><th>Met</th><th>Total</th><th>SLA %</th></tr>'
    for row in (chart_data.get("sla_by_category") or [])[:8]:
        html += f"<tr><td>{_safe(row.get('category'))}</td><td>{row.get('breached', 0)}</td><td>{row.get('met', 0)}</td><td>{row.get('total', 0)}</td><td>{row.get('sla_pct', 0)}%</td></tr>"
    html += "</table></section>"

    # Slide 6: Top services chart
    if images.get("services"):
        html += f'<section class="slide"><h2>Top services (volume)</h2><img class="chart-img" src="data:image/png;base64,{images["services"]}" alt="Top Services" /></section>'
    # Slide 7: Top services table
    html += '<section class="slide"><h2>Top services</h2><table><tr><th>Service</th><th>Count</th></tr>'
    for item in (chart_data.get("services") or [])[:8]:
        name = item.get("name", item) if isinstance(item, dict) else item
        val = item.get("value", 0) if isinstance(item, dict) else 0
        html += f"<tr><td>{_safe(name)}</td><td>{val}</td></tr>"
    html += "</table></section>"

    # Slide 8: Breach summary
    html += f'<section class="slide"><h2>SLA breach summary</h2><p>{breach_count} breached ticket(s).</p>'
    html += '<table><tr><th>Ticket ID</th><th>Category</th><th>Priority</th></tr>'
    for row in breach_list[:15]:
        html += f"<tr><td>{_safe(row.get('ticket_id'))}</td><td>{_safe(row.get('category'))}</td><td>{_safe(row.get('priority'))}</td></tr>"
    html += "</table></section>"

    # Slide 9: AI summary
    html += '<section class="slide"><h2>AI summary</h2><p>' + _safe(ai_insights.get("summary", "N/A")) + '</p><p><strong>Recommendation:</strong> ' + _safe(ai_insights.get("recommendation", "N/A")) + '</p></section>'

    html += "</body></html>"
    return html


def build_slides_pptx(chart_data: dict, ai_insights: dict, filename: str = "Report") -> bytes:
    """Generate PowerPoint using python-pptx: title, agenda, KPIs, chart slides, tables, AI summary, slide numbers."""
    from pptx import Presentation
    from pptx.util import Inches, Pt

    prs = Presentation()
    prs.slide_width = Inches(10)
    prs.slide_height = Inches(7.5)

    def add_slide_number(slide, num):
        tb = slide.shapes.add_textbox(Inches(9.2), Inches(7.1), Inches(0.6), Inches(0.3))
        tb.text_frame.paragraphs[0].text = str(num)
        tb.text_frame.paragraphs[0].font.size = Pt(10)
        tb.text_frame.paragraphs[0].alignment = 2  # right

    def add_title_slide(title, subtitle=""):
        layout = prs.slide_layouts[6]  # blank
        slide = prs.slides.add_slide(layout)
        tx = slide.shapes.add_textbox(Inches(0.5), Inches(2.5), Inches(9), Inches(1))
        p = tx.text_frame.paragraphs[0]
        p.text = title
        p.font.size = Pt(32)
        p.font.bold = True
        if subtitle:
            tx2 = slide.shapes.add_textbox(Inches(0.5), Inches(3.8), Inches(9), Inches(1))
            tx2.text_frame.paragraphs[0].text = subtitle
            tx2.text_frame.paragraphs[0].font.size = Pt(18)
        add_slide_number(slide, len(prs.slides))

    def add_content_slide(title, body_lines):
        layout = prs.slide_layouts[6]
        slide = prs.slides.add_slide(layout)
        tx = slide.shapes.add_textbox(Inches(0.5), Inches(0.4), Inches(9), Inches(0.8))
        tx.text_frame.paragraphs[0].text = title
        tx.text_frame.paragraphs[0].font.size = Pt(24)
        tx.text_frame.paragraphs[0].font.bold = True
        tx2 = slide.shapes.add_textbox(Inches(0.5), Inches(1.4), Inches(9), Inches(5.5))
        tf = tx2.text_frame
        tf.word_wrap = True
        for line in body_lines:
            p = tf.add_paragraph()
            p.text = line
            p.font.size = Pt(14)
            p.space_after = Pt(6)
        add_slide_number(slide, len(prs.slides))

    def add_chart_slide(title, png_bytes, width_inches=8):
        if not png_bytes:
            add_content_slide(title, ["No chart data."])
            return
        layout = prs.slide_layouts[6]
        slide = prs.slides.add_slide(layout)
        tx = slide.shapes.add_textbox(Inches(0.5), Inches(0.4), Inches(9), Inches(0.7))
        tx.text_frame.paragraphs[0].text = title
        tx.text_frame.paragraphs[0].font.size = Pt(24)
        tx.text_frame.paragraphs[0].font.bold = True
        slide.shapes.add_picture(BytesIO(png_bytes), Inches(0.5), Inches(1.3), width=Inches(width_inches))
        add_slide_number(slide, len(prs.slides))

    total = chart_data.get("total_tickets") or 0
    sla_pct = chart_data.get("sla_met_pct") or 0
    avg_resolve = chart_data.get("avg_resolve_hours")
    data_period = chart_data.get("data_period") or "N/A"
    breach_list = chart_data.get("breach_list") or []

    add_title_slide("ITSM Analytics", f"Monthly Report – {filename} | Period: {data_period}")
    add_content_slide("Agenda", [
        "1. Key metrics",
        "2. Workload trend (month-wise)",
        "3. Priority by month / Workload by group",
        "4. SLA status & SLA by category",
        "5. Top services",
        "6. SLA breach summary",
        "7. AI summary",
    ])
    add_content_slide("Key metrics", [
        f"Total tickets: {total}",
        f"SLA met: {sla_pct}%",
        f"Avg resolve time: {avg_resolve or 'N/A'}h"
    ])
    try:
        add_chart_slide("Monthly workload trend", render_workload_bar(chart_data, 7, 4))
    except Exception:
        add_content_slide("Monthly workload trend", ["No workload data."])
    try:
        add_chart_slide("Priority by month", render_priority_by_month_bar(chart_data, 7, 4))
    except Exception:
        pass
    try:
        add_chart_slide("Workload by group (month-wise)", render_workload_by_group_bar(chart_data, 7, 4))
    except Exception:
        pass
    try:
        add_chart_slide("SLA status", render_sla_pie(chart_data, 5, 4), width_inches=5)
    except Exception:
        add_content_slide("SLA status", ["No SLA data."])
    try:
        add_chart_slide("SLA by category", render_sla_by_category_bar(chart_data, 7, 4))
    except Exception:
        pass
    sla_lines = [f"{row.get('category', '')}: Breached {row.get('breached', 0)}, Met {row.get('met', 0)}, SLA {row.get('sla_pct', 0)}%" for row in (chart_data.get("sla_by_category") or [])[:8]]
    add_content_slide("SLA by category (table)", sla_lines or ["No data"])
    try:
        add_chart_slide("Top services (volume)", render_services_bar(chart_data, 7, 4))
    except Exception:
        pass
    svc_lines = [f"{item.get('name', item)}: {item.get('value', 0)}" if isinstance(item, dict) else f"{item}: 0" for item in (chart_data.get("services") or [])[:8]]
    add_content_slide("Top services", svc_lines or ["No data"])
    breach_lines = [f"{row.get('ticket_id', '')} – {row.get('category', '')} ({row.get('priority', '')})" for row in breach_list[:15]]
    add_content_slide(f"SLA breach list ({len(breach_list)} total)", breach_lines or ["No breached tickets"])
    add_content_slide("AI summary", [
        _safe(ai_insights.get("summary", "N/A")),
        "",
        "Recommendation: " + _safe(ai_insights.get("recommendation", "N/A"))
    ])

    buf = BytesIO()
    prs.save(buf)
    buf.seek(0)
    return buf.read()


def build_report_appendix_excel(chart_data: dict) -> bytes:
    """Generate Excel file with sheets: Breach list, SLA by category, Workload table, Top services."""
    try:
        import openpyxl
    except ImportError:
        raise RuntimeError("openpyxl is required for Excel appendix; pip install openpyxl")

    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    # Sheet 1: Breach list
    breach_list = chart_data.get("breach_list") or []
    ws1 = wb.create_sheet("Breach list", 0)
    ws1.append(["Ticket ID", "Category", "Priority", "Summary", "SLA Status", "Resolution (days)"])
    for row in breach_list:
        ws1.append([
            _safe(row.get("ticket_id")),
            _safe(row.get("category")),
            _safe(row.get("priority")),
            _safe(row.get("summary"))[:500],
            _safe(row.get("sla_status")),
            row.get("resolution_days") if row.get("resolution_days") is not None else "",
        ])

    # Sheet 2: SLA by category
    sla_cat = chart_data.get("sla_by_category") or []
    ws2 = wb.create_sheet("SLA by category", 1)
    ws2.append(["Category", "Breached", "Met", "Warning", "Total", "SLA %"])
    for row in sla_cat:
        ws2.append([
            _safe(row.get("category")),
            row.get("breached", 0),
            row.get("met", 0),
            row.get("warning", 0),
            row.get("total", 0),
            row.get("sla_pct", 0),
        ])

    # Sheet 3: Workload table (service × month)
    wtab = chart_data.get("workload_table") or {}
    months = wtab.get("months") or []
    rows = wtab.get("rows") or []
    ws3 = wb.create_sheet("Workload table", 2)
    ws3.append(["Service"] + list(months) + ["Total"])
    for r in rows:
        ws3.append([_safe(r.get("name"))] + [r.get(m, 0) for m in months] + [r.get("total", 0)])
    gt = wtab.get("grand_total_row")
    if gt:
        ws3.append([_safe(gt.get("name"))] + [gt.get(m, 0) for m in months] + [gt.get("total", 0)])

    # Sheet 4: Top services
    services = chart_data.get("services") or []
    ws4 = wb.create_sheet("Top services", 3)
    ws4.append(["Service", "Count"])
    for item in services:
        name = item.get("name", item) if isinstance(item, dict) else item
        val = item.get("value", 0) if isinstance(item, dict) else 0
        ws4.append([_safe(name), val])

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf.read()


# --- Pivot-style / Excel-style PDF (yellow headers, month columns, Grand Total, SLA % colors) ---

def build_pivot_style_report_pdf(chart_data: dict, filename: str = "Report") -> bytes:
    """Generate a PDF report that looks like the Excel pivot report: yellow section headers,
    month-wise columns, Grand Total rows, light blue for totals, green/orange/red for SLA %."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak

    # Colors to match the Excel-style report
    YELLOW_HEADER = colors.HexColor("#FFEB3B")      # section header
    LIGHT_BLUE = colors.HexColor("#E3F2FD")        # subtotal / total row
    GREEN_SLA = colors.HexColor("#C8E6C9")         # SLA % >= 90
    ORANGE_SLA = colors.HexColor("#FFE0B2")        # SLA % 70-89
    RED_SLA = colors.HexColor("#FFCDD2")           # SLA % < 70

    def _footer(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 9)
        canvas.drawRightString(A4[0] - 2*cm, 1*cm, f"Page {canvas.getPageNumber()}")
        canvas.restoreState()

    buf = BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=A4, rightMargin=1.5*cm, leftMargin=1.5*cm, topMargin=1.2*cm, bottomMargin=1.2*cm,
        onFirstPage=_footer, onLaterPage=_footer,
    )
    styles = getSampleStyleSheet()
    h2_style = ParagraphStyle(name="SectionHeader", parent=styles["Heading2"], fontSize=12, spaceAfter=6, textColor=colors.HexColor("#1a1a1a"))
    cell_style = ParagraphStyle(name="TableCell", parent=styles["Normal"], fontSize=8, leading=9, wordWrap="CJK")

    story = []

    # --- Section 1: HPSM ICS WORKLOAD (Count of Incident ID) - category × month ---
    workload = chart_data.get("workload") or []
    categories = chart_data.get("categories") or []
    if workload and categories:
        story.append(Paragraph("HPSM ICS WORKLOAD", h2_style))
        story.append(Paragraph("Count of Incident ID", styles["Normal"]))
        month_names = [r.get("name", "") for r in workload]
        n_months = max(len(month_names), 1)
        # First column wide so full category names show; month columns narrow (all in pt)
        col0_width = 4.2 * cm
        available_pt = A4[0] - 2 * 1.5 * cm - col0_width
        month_width = max(28, available_pt / n_months)
        col_widths = [col0_width] + [month_width] * n_months
        # Month headers as Paragraph so "Jan 2025" shows on two lines (month / year)
        header_style = ParagraphStyle(name="MonthHeader", parent=styles["Normal"], fontSize=7, leading=8, alignment=1)
        month_header_cells = []
        for mn in month_names:
            ms = _safe(mn).strip()
            if " " in ms:
                parts = ms.split(" ", 1)
                month_header_cells.append(Paragraph(_escape_paragraph(parts[0]) + "<br/>" + _escape_paragraph(parts[1]), header_style))
            else:
                month_header_cells.append(Paragraph(_escape_paragraph(ms), header_style))
        # Table: Row0 = [""] + month headers, Row1..n = category (Paragraph) + values, Last = Grand Total
        data = [[""] + month_header_cells]
        for cat in categories:
            row = [Paragraph(_escape_paragraph(str(cat)), cell_style)]
            for r in workload:
                row.append(str(r.get(cat, 0) or 0))
            data.append(row)
        # Grand Total row
        gt_row = ["Grand Total"]
        for r in workload:
            gt_row.append(str(r.get("total", 0) or 0))
        data.append(gt_row)
        t = Table(data, colWidths=col_widths, repeatRows=1)
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), YELLOW_HEADER),
            ("BACKGROUND", (0, -1), (-1, -1), LIGHT_BLUE),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("FONTSIZE", (1, 0), (-1, -1), 8),
            ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ]))
        story.append(t)
        story.append(Spacer(1, 14))

    # --- Section 2: HPSM ICS SLA - Category, Breached, Met, Warning, Total, SLA % ---
    sla_cat = chart_data.get("sla_by_category") or []
    if sla_cat:
        story.append(Paragraph("HPSM ICS SLA", h2_style))
        story.append(Paragraph("Count of Incident ID by SLA status", styles["Normal"]))
        data = [["Category", "Breached", "Met", "Warning", "Total", "SLA %"]]
        for row in sla_cat[:20]:
            cat_name = _safe(row.get("category"))
            breached = row.get("breached", 0) or 0
            met = row.get("met", 0) or 0
            warning = row.get("warning", 0) or 0
            total = row.get("total", 0) or 0
            has_sla_data = (breached + met + warning) > 0
            sla_pct = row.get("sla_pct", 0) or 0
            sla_display = f"{sla_pct}%" if has_sla_data and total else ("N/A" if total else "0%")
            data.append([
                Paragraph(_escape_paragraph(cat_name), cell_style),
                str(breached), str(met), str(warning), str(total), sla_display
            ])
        col0_sla = 4.2 * cm
        t = Table(data, colWidths=[col0_sla, 50, 50, 50, 50, 48], repeatRows=1)
        style = TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), YELLOW_HEADER),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("FONTSIZE", (1, 0), (-1, -1), 8),
            ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ])
        for i in range(1, len(data)):
            try:
                r = sla_cat[i - 1]
                pct = int(r.get("sla_pct", 0) or 0)
                has_sla = (r.get("breached", 0) or 0) + (r.get("met", 0) or 0) + (r.get("warning", 0) or 0) > 0
            except (IndexError, TypeError):
                pct = 0
                has_sla = False
            if not has_sla:
                style.add("BACKGROUND", (5, i), (5, i), colors.HexColor("#F5F5F5"))  # grey for N/A
            elif pct >= 90:
                style.add("BACKGROUND", (5, i), (5, i), GREEN_SLA)
            elif pct >= 70:
                style.add("BACKGROUND", (5, i), (5, i), ORANGE_SLA)
            else:
                style.add("BACKGROUND", (5, i), (5, i), RED_SLA)
        t.setStyle(style)
        story.append(t)
        story.append(Spacer(1, 14))

    # --- Section 3: SAL Certificate related tickets ---
    sal_count = chart_data.get("sal_certificate_count") or 0
    story.append(Paragraph("SAL Certificate related tickets", h2_style))
    data = [["Total"], [str(sal_count)]]
    t = Table(data, colWidths=[120], repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), YELLOW_HEADER),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
    ]))
    story.append(t)
    story.append(Spacer(1, 14))

    # --- Section 4: SR Workload (Count of ID) - service × month ---
    wtab = chart_data.get("workload_table") or {}
    months = wtab.get("months") or []
    rows = wtab.get("rows") or []
    if months and rows:
        story.append(Paragraph("SR Workload", h2_style))
        story.append(Paragraph("Count of ID", styles["Normal"]))
        n_m = len(months)
        col0_w = 4.2 * cm
        available_sr = A4[0] - 2 * 1.5 * cm - col0_w - 40
        m_w = max(28, available_sr / (n_m + 1))  # narrow columns; headers use Paragraph wrap
        col_widths_sr = [col0_w] + [m_w] * n_m + [40]
        # Month headers as Paragraph with "Jan" / "2025" on two lines so year and month both show clearly
        header_style = ParagraphStyle(name="MonthHeader", parent=styles["Normal"], fontSize=7, leading=8, alignment=1)
        month_headers = []
        for m in months:
            ms = _safe(m).strip()
            if " " in ms:
                parts = ms.split(" ", 1)
                month_headers.append(Paragraph(_escape_paragraph(parts[0]) + "<br/>" + _escape_paragraph(parts[1]), header_style))
            else:
                month_headers.append(Paragraph(_escape_paragraph(ms), header_style))
        data = [["Service"] + month_headers + ["Total"]]
        for r in rows[:40]:
            data.append([Paragraph(_escape_paragraph(_safe(r.get("name"))), cell_style)] + [str(r.get(m, 0)) for m in months] + [str(r.get("total", 0))])
        gt = wtab.get("grand_total_row")
        if gt:
            data.append([_safe(gt.get("name"))] + [str(gt.get(m, 0)) for m in months] + [str(gt.get("total", 0))])
        t = Table(data, colWidths=col_widths_sr, repeatRows=1)
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), YELLOW_HEADER),
            ("BACKGROUND", (0, -1), (-1, -1), LIGHT_BLUE),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("FONTSIZE", (1, 0), (-1, -1), 7),
            ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ]))
        story.append(t)

    doc.build(story)
    buf.seek(0)
    return buf.read()


def build_full_consolidated_report_pdf(chart_data: dict, ai_insights: dict, filename: str = "Report") -> bytes:
    """Generate a single consolidated PDF containing Executive Summary, Charts, AI Insights,
    Breach List, and Detailed Pivot Tables (all-in-one report).
    Supports multiple record types (Incident, SR, Change) by creating sections for each."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image

    # Colors
    YELLOW_HEADER = colors.HexColor("#FFEB3B")
    LIGHT_BLUE = colors.HexColor("#E3F2FD")
    GREEN_SLA = colors.HexColor("#C8E6C9")
    ORANGE_SLA = colors.HexColor("#FFE0B2")
    RED_SLA = colors.HexColor("#FFCDD2")

    def _footer(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 9)
        canvas.drawRightString(A4[0] - 2 * cm, 1 * cm, f"Page {canvas.getPageNumber()}")
        canvas.restoreState()

    buf = BytesIO()
    doc = SimpleDocTemplate(
        buf,
        pagesize=A4,
        rightMargin=1.5 * cm,
        leftMargin=1.5 * cm,
        topMargin=1.5 * cm,
        bottomMargin=1.5 * cm,
        onFirstPage=_footer,
        onLaterPage=_footer,
    )
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(name="ReportTitle", parent=styles["Heading1"], fontSize=20, spaceAfter=20, alignment=1)
    h1_style = ParagraphStyle(name="H1", parent=styles["Heading1"], fontSize=16, spaceBefore=12, spaceAfter=12, textColor=colors.HexColor("#1e293b"))
    h2_style = ParagraphStyle(name="H2", parent=styles["Heading2"], fontSize=13, spaceBefore=10, spaceAfter=8, textColor=colors.HexColor("#334155"))
    cell_style = ParagraphStyle(name="TableCell", parent=styles["Normal"], fontSize=8, leading=9, wordWrap="CJK")

    story = []

    # --- PART 1: TITLE & EXECUTIVE SUMMARY (Global) ---
    story.append(Paragraph("Consolidated ITSM Report", title_style))
    story.append(Paragraph(f"<b>Data Source:</b> {_safe(filename)}", styles["Normal"]))
    story.append(Paragraph(f"<b>Period:</b> {chart_data.get('data_period') or 'N/A'}", styles["Normal"]))
    story.append(Paragraph(f"<b>Generated:</b> {datetime.now().strftime('%d-%b-%Y %H:%M')}", styles["Normal"]))
    story.append(Spacer(1, 24))

    # AI Summary
    story.append(Paragraph("1. Executive Summary (AI Insights)", h1_style))
    story.append(Paragraph(f"<b>Summary:</b> {_safe(ai_insights.get('summary', 'N/A'))}", styles["Normal"]))
    story.append(Spacer(1, 8))
    story.append(Paragraph(f"<b>Recommendation:</b> {_safe(ai_insights.get('recommendation', 'N/A'))}", styles["Normal"]))
    story.append(Spacer(1, 16))

    # --- HELPER: RENDER ANALYSIS SECTION ---
    def _add_analysis_section(data, section_title):
        # KPIs
        total = data.get("total_tickets") or 0
        sla_pct = data.get("sla_met_pct") or 0
        avg_resolve = data.get("avg_resolve_hours")
        
        story.append(Paragraph(section_title, h1_style))
        kpi_data = [[f"Total Tickets: {total}", f"SLA Met Rate: {sla_pct}%", f"Avg Resolution: {_safe(avg_resolve, 'N/A')}h"]]
        t_kpi = Table(kpi_data, colWidths=[160, 160, 160])
        t_kpi.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8fafc")),
            ("BOX", (0, 0), (-1, -1), 1, colors.HexColor("#e2e8f0")),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("FONTSIZE", (0, 0), (-1, -1), 12),
            ("PADDING", (0, 0), (-1, -1), 12),
            ("FONTNAME", (0, 0), (-1, -1), "Helvetica-Bold"),
        ]))
        story.append(t_kpi)
        story.append(Spacer(1, 20))

        # Charts (Generated for this subset)
        images = get_chart_images_base64(data, report_style=True)
        
        if images.get("workload"):
            story.append(Paragraph(f"{section_title} - Monthly Trend", h2_style))
            story.append(Image(BytesIO(images["workload"]), width=16 * cm, height=8 * cm))
            story.append(Spacer(1, 12))
            
        if images.get("priority_by_month"):
            story.append(Paragraph(f"{section_title} - Priority Distribution", h2_style))
            story.append(Image(BytesIO(images["priority_by_month"]), width=16 * cm, height=8 * cm))
            story.append(Spacer(1, 12))

        # Detailed Tables
        # Workload by Category
        workload = data.get("workload") or []
        categories = data.get("categories") or []
        if workload and categories:
            story.append(Paragraph("Workload by Category", h2_style))
            month_names = [r.get("name", "") for r in workload]
            n_months = max(len(month_names), 1)
            col0_width = 4.2 * cm
            available_pt = A4[0] - 2 * 1.5 * cm - col0_width
            month_width = max(28, available_pt / n_months)
            col_widths = [col0_width] + [month_width] * n_months
            
            header_style = ParagraphStyle(name="MonthHeader", parent=styles["Normal"], fontSize=7, leading=8, alignment=1)
            month_header_cells = []
            for mn in month_names:
                ms = _safe(mn).strip()
                if " " in ms:
                    parts = ms.split(" ", 1)
                    month_header_cells.append(Paragraph(_escape_paragraph(parts[0]) + "<br/>" + _escape_paragraph(parts[1]), header_style))
                else:
                    month_header_cells.append(Paragraph(_escape_paragraph(ms), header_style))
            
            tab_data = [["Category"] + month_header_cells]
            for cat in categories:
                row = [Paragraph(_escape_paragraph(str(cat)), cell_style)]
                for r in workload:
                    row.append(str(r.get(cat, 0) or 0))
                tab_data.append(row)
            
            gt_row = ["Grand Total"]
            for r in workload:
                gt_row.append(str(r.get("total", 0) or 0))
            tab_data.append(gt_row)
            
            t = Table(tab_data, colWidths=col_widths, repeatRows=1)
            t.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), YELLOW_HEADER),
                ("BACKGROUND", (0, -1), (-1, -1), LIGHT_BLUE),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                ("FONTSIZE", (1, 0), (-1, -1), 7),
                ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ]))
            story.append(t)
            story.append(Spacer(1, 16))

        # SLA by Category
        sla_cat = data.get("sla_by_category") or []
        if sla_cat:
            story.append(Paragraph("SLA Performance by Category", h2_style))
            sla_tab_data = [["Category", "Breached", "Met", "Warning", "Total", "SLA %"]]
            for row in sla_cat:
                cat_name = _safe(row.get("category"))
                breached = row.get("breached", 0) or 0
                met = row.get("met", 0) or 0
                warning = row.get("warning", 0) or 0
                total = row.get("total", 0) or 0
                has_sla_data = (breached + met + warning) > 0
                sla_pct_val = row.get("sla_pct", 0) or 0
                sla_display = f"{sla_pct_val}%" if has_sla_data and total else ("N/A" if total else "0%")
                sla_tab_data.append([
                    Paragraph(_escape_paragraph(cat_name), cell_style),
                    str(breached), str(met), str(warning), str(total), sla_display
                ])
                
            t_sla = Table(sla_tab_data, colWidths=[4.2*cm, 50, 50, 50, 50, 48], repeatRows=1)
            style_sla = TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), YELLOW_HEADER),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                ("FONTSIZE", (1, 0), (-1, -1), 8),
                ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ])
            for i in range(1, len(sla_tab_data)):
                try:
                    r = sla_cat[i - 1]
                    pct = int(r.get("sla_pct", 0) or 0)
                    has_sla = (r.get("breached", 0) or 0) + (r.get("met", 0) or 0) + (r.get("warning", 0) or 0) > 0
                except (IndexError, TypeError):
                    pct = 0
                    has_sla = False
                if not has_sla:
                    style_sla.add("BACKGROUND", (5, i), (5, i), colors.HexColor("#F5F5F5"))
                elif pct >= 90:
                    style_sla.add("BACKGROUND", (5, i), (5, i), GREEN_SLA)
                elif pct >= 70:
                    style_sla.add("BACKGROUND", (5, i), (5, i), ORANGE_SLA)
                else:
                    style_sla.add("BACKGROUND", (5, i), (5, i), RED_SLA)
            t_sla.setStyle(style_sla)
            story.append(t_sla)
            story.append(Spacer(1, 16))

        # Breach List
        breach_list = data.get("breach_list") or []
        if breach_list:
            story.append(Paragraph(f"SLA Breaches ({len(breach_list)} tickets)", h2_style))
            MAX_BREACH_PDF = 100
            display_breaches = breach_list[:MAX_BREACH_PDF]
            breach_headers = ["Ticket ID", "Category", "Priority", "Summary"]
            breach_data = [[Paragraph(h, cell_style) for h in breach_headers]]
            
            for row in display_breaches:
                breach_data.append([
                    Paragraph(_escape_paragraph(_safe(row.get("ticket_id"))), cell_style),
                    Paragraph(_escape_paragraph(_safe(row.get("category"))), cell_style),
                    Paragraph(_escape_paragraph(_safe(row.get("priority"))), cell_style),
                    Paragraph(_escape_paragraph(_safe(row.get("summary"))[:150]), cell_style),
                ])
            t_breach = Table(breach_data, colWidths=[70, 140, 60, 230], repeatRows=1)
            t_breach.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#fef2f2")),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ]))
            story.append(t_breach)
            if len(breach_list) > MAX_BREACH_PDF:
                 story.append(Paragraph(f"<i>... and {len(breach_list) - MAX_BREACH_PDF} more.</i>", styles["Normal"]))
        else:
            story.append(Paragraph("No SLA breaches detected for this section.", styles["Normal"]))

    # --- PART 2: DETERMINE SECTIONS ---
    sub_charts = chart_data.get("chart_data_by_type", {})
    
    if sub_charts and len(sub_charts) > 1:
        # Multiple types detected: Render separate sections
        # Defined sort order
        order = ["Incident", "Service Request", "Change Task"]
        keys = sorted(sub_charts.keys(), key=lambda x: order.index(x) if x in order else 99)
        
        for i, rtype in enumerate(keys):
            if i > 0: story.append(PageBreak()) # New page for subsequent sections
            elif story[-1].__class__.__name__ != 'Spacer': story.append(Spacer(1, 12)) # Formatting for first
            
            # Use data for this type
            _add_analysis_section(sub_charts[rtype], f"{rtype} Analytics")
            
    else:
        # Single type or no subtype breakdown: Render Global
        _add_analysis_section(chart_data, "Detailed Analysis")

    doc.build(story)
    buf.seek(0)
    return buf.read()
