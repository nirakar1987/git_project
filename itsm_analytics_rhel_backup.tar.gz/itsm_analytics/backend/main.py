from fastapi import FastAPI, UploadFile, File, Form, HTTPException, BackgroundTasks
from contextlib import contextmanager
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import StreamingResponse, HTMLResponse
import os
import shutil
import io
import uuid
import tempfile
import pandas as pd
from processor import ITSMProcessor
from reporting import (
    build_monthly_report_html,
    build_monthly_report_pdf,
    build_monthly_report_docx,
    build_slides_html,
    build_slides_pptx,
    build_report_appendix_excel,
    build_pivot_style_report_pdf,
    build_full_consolidated_report_pdf,
)
from dotenv import load_dotenv

load_dotenv()

@contextmanager
def temporary_file_context(suffix):
    """Context manager for temporary files that ensures cleanup."""
    tf = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    tf.close()
    try:
        yield tf.name
    finally:
        if os.path.exists(tf.name):
            try:
                os.remove(tf.name)
            except Exception as e:
                print(f"Cleanup warning: {e}")


load_dotenv()

# Optional DB and Redis (used when env vars set, e.g. in Docker)
USE_DB = bool(os.getenv("DATABASE_URL"))
USE_REDIS = bool(os.getenv("REDIS_URL"))
if USE_DB:
    from database import init_db, save_session, get_session_from_db, update_session_ai_insights, list_sessions
if USE_REDIS:
    from redis_store import cache_dataframe, get_cached_dataframe, set_pending_ai, get_pending_ai

app = FastAPI(title="ITSM AI Analytics Dashboard")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup():
    if USE_DB:
        init_db()


API_KEY = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
processor = ITSMProcessor(API_KEY)

current_df = None
# In-memory fallback when DB/Redis not used
sessions = {}
pending_ai = {}


def _filter_df_by_date(df, date_from, date_to):
    if not ('created_at' in df.columns and (date_from or date_to)):
        return df
    created = pd.to_datetime(df['created_at'], errors='coerce')
    if date_from:
        from_dt = pd.to_datetime(date_from, errors='coerce')
        if pd.notna(from_dt):
            df = df[created >= from_dt]
            created = pd.to_datetime(df['created_at'], errors='coerce')
    if date_to:
        to_dt = pd.to_datetime(date_to, errors='coerce')
        if pd.notna(to_dt):
            to_dt = to_dt + pd.Timedelta(days=1)
            df = df[created < to_dt]
    return df.reset_index(drop=True)


def _print_change_data_console_report(change_df: pd.DataFrame, reason: str = ""):
    """Print Priority, Planned Start, Planned End, Status, Approval Status to console (change data only)."""
    import sys
    try:
        sep = "=" * 55
        print("\n" + sep, flush=True)
        print("CHANGE DATA CONSOLE REPORT" + (f" ({reason})" if reason else ""), flush=True)
        print(sep, flush=True)
        print(f"Total change records: {len(change_df)}\n", flush=True)

        # Priority
        if "priority" in change_df.columns:
            p = change_df["priority"].astype(str).replace("", "N/A").value_counts()
            print("Priority:", flush=True)
            for k, v in p.items():
                print(f"  {k}: {int(v)}", flush=True)
            print(flush=True)

        # Planned Start (mapped as created_at in processor)
        if "created_at" in change_df.columns:
            ps = pd.to_datetime(change_df["created_at"], errors="coerce")
            valid = ps.notna()
            if valid.any():
                mn, mx = ps[valid].min(), ps[valid].max()
                print("Planned Start:", flush=True)
                print(f"  Range: {mn.strftime('%Y-%m-%d %H:%M')} to {mx.strftime('%Y-%m-%d %H:%M')}", flush=True)
                print(f"  With date: {int(valid.sum())}  |  Missing: {int((~valid).sum())}", flush=True)
            else:
                print("Planned Start: (no valid dates)", flush=True)
            print(flush=True)

        # Planned End (mapped as resolved_at in processor)
        if "resolved_at" in change_df.columns:
            pe = pd.to_datetime(change_df["resolved_at"], errors="coerce")
            valid = pe.notna()
            if valid.any():
                mn, mx = pe[valid].min(), pe[valid].max()
                print("Planned End:", flush=True)
                print(f"  Range: {mn.strftime('%Y-%m-%d %H:%M')} to {mx.strftime('%Y-%m-%d %H:%M')}", flush=True)
                print(f"  With date: {int(valid.sum())}  |  Missing: {int((~valid).sum())}", flush=True)
            else:
                print("Planned End: (no valid dates)", flush=True)
            print(flush=True)

        # Status
        if "status" in change_df.columns:
            s = change_df["status"].astype(str).replace("", "N/A").value_counts()
            print("Status:", flush=True)
            for k, v in s.items():
                print(f"  {k}: {int(v)}", flush=True)
            print(flush=True)

        # Approval Status
        if "approval_status" in change_df.columns:
            a = change_df["approval_status"].astype(str).replace("", "N/A").value_counts()
            print("Approval Status:", flush=True)
            for k, v in a.items():
                print(f"  {k}: {int(v)}", flush=True)
        else:
            print("Approval Status: (column not present)", flush=True)

        print(sep + "\n", flush=True)
    except Exception as e:
        print(f"Change console report error: {e}\n", flush=True)


def _get_df(session_id: str = None):
    """Get dataframe: from Redis by session_id, or in-memory current_df/sessions."""
    global current_df, sessions
    if session_id and USE_REDIS:
        df = get_cached_dataframe(session_id)
        if df is not None:
            return df
    if session_id and session_id in sessions:
        return sessions[session_id].get("df")
    return current_df


def _get_session_meta(session_id: str = None):
    """Get filename, chart_data, ai_insights: from DB then Redis pending_ai, or in-memory."""
    global sessions
    if session_id and USE_DB:
        meta = get_session_from_db(session_id)
        if meta:
            ai = meta.get("ai_insights")
            if not ai and USE_REDIS:
                ai = get_pending_ai(session_id)
            return {**meta, "ai_insights": ai}
    if session_id and session_id in sessions:
        s = sessions[session_id]
        ai = s.get("ai_insights") or (get_pending_ai(session_id) if USE_REDIS else None)
        return {"filename": s.get("filename"), "chart_data": s.get("chart_data"), "ai_insights": ai}
    return None


def _run_ai_insights(session_id: str):
    global sessions, pending_ai
    df = get_cached_dataframe(session_id) if USE_REDIS else sessions.get(session_id, {}).get("df")
    if df is None and session_id in sessions:
        df = sessions[session_id].get("df")
    if df is None:
        fallback = {"summary": "Session expired or data no longer cached.", "sentiment": "Neutral", "recommendation": "Re-upload data."}
        if USE_REDIS:
            set_pending_ai(session_id, fallback)
        else:
            pending_ai[session_id] = fallback
        if USE_DB:
            update_session_ai_insights(session_id, fallback)
        return
    try:
        insights = processor.get_ai_insights(df)
        if USE_REDIS:
            set_pending_ai(session_id, insights)
        else:
            pending_ai[session_id] = insights
        if session_id in sessions:
            sessions[session_id]["ai_insights"] = insights
        if USE_DB:
            update_session_ai_insights(session_id, insights)
    except Exception as e:
        fallback = {"summary": str(e), "sentiment": "Neutral", "recommendation": "Try again."}
        if USE_REDIS:
            set_pending_ai(session_id, fallback)
        else:
            pending_ai[session_id] = fallback
        if USE_DB:
            update_session_ai_insights(session_id, fallback)


@app.post("/upload")
async def upload_file(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    date_from: str = Form(None),
    date_to: str = Form(None),
    compare_from: str = Form(None),
    compare_to: str = Form(None),
    data_type: str = Form(None),
):
    file_ext = "." + file.filename.split('.')[-1].lower() if '.' in file.filename else ".csv"
    
    # Normalize data_type
    if data_type:
        data_type = data_type.strip()
        if data_type.lower() == 'auto':
            data_type = None
        elif data_type.lower() in ('service request', 'sr'):
            data_type = 'Service Request'
        elif data_type.lower() in ('change task', 'change'):
            data_type = 'Change Task'
        elif data_type.lower() == 'incident':
            data_type = 'Incident'

    try:
        with temporary_file_context(file_ext) as temp_path:
            with open(temp_path, "wb") as buffer:
                shutil.copyfileobj(file.file, buffer)

            df = processor.process_file(temp_path, file_ext.replace('.', ''), data_type=data_type)
            df = _filter_df_by_date(df, date_from, date_to)

            global current_df
            current_df = df
            session_id = str(uuid.uuid4())

            chart_data = processor.get_chart_data(df)
            verification = getattr(processor, "last_verification_report", None)

            # Change Data Console Report: only for change tickets (Priority, Planned Start/End, Status, Approval Status)
            # Trigger when: (1) record_type is "Change Task", or (2) filename suggests change (e.g. Change_Ticket.csv)
            is_change_by_record = (
                "record_type" in df.columns
                and (df["record_type"].astype(str).str.strip().str.lower() == "change task").any()
            )
            is_change_by_filename = file.filename and "change" in file.filename.lower()
            if is_change_by_record:
                change_df = df[df["record_type"].astype(str).str.strip().str.lower() == "change task"]
                _print_change_data_console_report(change_df, reason="record_type=Change Task")
            elif is_change_by_filename and len(df) > 0:
                _print_change_data_console_report(df, reason=f"filename contains 'change' ({file.filename})")

            # When multiple record types, precompute chart_data per type for dashboard filter
            chart_data_by_type = {}
            if chart_data.get("record_type_counts") and len(chart_data["record_type_counts"]) > 1:
                for rtype in chart_data["record_type_counts"]:
                    df_sub = df[df["record_type"].astype(str) == str(rtype)]
                    if len(df_sub) > 0:
                        chart_data_by_type[rtype] = processor.get_chart_data(df_sub)
                chart_data["chart_data_by_type"] = chart_data_by_type

            # Add suggested questions
            chart_data["suggested_questions"] = [
                "How many tickets in total?",
                "How many tickets breached SLA?",
                "Top 5 categories by volume?",
                "How many tickets mention certificate or SAL certificate?",
                "Find tickets with 'renew' or 'certificate' in description",
                "How many P1 or Critical tickets?",
                "Breakdown by status?",
                "SLA met percentage?",
            ]

            sessions[session_id] = {"df": df, "filename": file.filename, "chart_data": chart_data, "ai_insights": None}
            if USE_REDIS:
                cache_dataframe(session_id, df)
            if USE_DB:
                save_session(session_id, file.filename, chart_data, ai_insights=None)
            pending_ai[session_id] = None
            background_tasks.add_task(_run_ai_insights, session_id)

            # Trend comparison
            comparison = None
            if compare_from or compare_to:
                # For comparison, we need to process the file again (or copy df) but with diff dates.
                # Actually process_file reads from disk. Since we are in temp_path context, file exists!
                # We can reuse temp_path
                df_compare = processor.process_file(temp_path, file_ext.replace('.', ''), data_type=data_type)
                df_compare = _filter_df_by_date(df_compare, compare_from, compare_to)
                chart_prev = processor.get_chart_data(df_compare)
                cur = chart_data.get("total_tickets") or 0
                prev = chart_prev.get("total_tickets") or 0
                sla_cur = chart_data.get("sla_met_pct") or 0
                sla_prev = chart_prev.get("sla_met_pct") or 0
                comparison = {
                    "chart_data_previous": chart_prev,
                    "total_tickets_delta": cur - prev,
                    "sla_met_pct_delta": round(sla_cur - sla_prev, 1),
                    "period_current": f"{date_from or 'start'} to {date_to or 'end'}",
                    "period_previous": f"{compare_from or 'start'} to {compare_to or 'end'}",
                }

            return {
                "chart_data": chart_data,
                "ai_insights": None,
                "filename": file.filename,
                "verification": verification,
                "session_id": session_id,
                "comparison": comparison,
            }

    except Exception as e:
        print(f"Error processing file {file.filename}: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Processing error: {str(e)}")


@app.get("/sessions")
async def list_saved_sessions():
    """List all saved sessions (for sidebar). When using DB returns from PostgreSQL; else in-memory."""
    global sessions
    if USE_DB:
        rows = list_sessions()
        return {"sessions": rows}
    # In-memory fallback
    return {
        "sessions": [
            {"session_id": sid, "filename": s.get("filename", "—"), "created_at": None}
            for sid, s in list(sessions.items())[:50]
        ]
    }


@app.delete("/session")
async def delete_session_endpoint(session_id: str):
    """Delete a specific session."""
    global sessions
    deleted = False
    
    if USE_DB:
        from database import delete_session as db_delete
        deleted = db_delete(session_id)
        
    if session_id in sessions:
        del sessions[session_id]
        deleted = True
        
    if not deleted and not USE_DB: # If not using DB and not in memory, consider it gone or not found.
         pass # No-op, effectively idempotent if not found
         
    if not deleted and USE_DB: # If using DB and wasn't found there
         # Could return 404, but idempotency is nice. 
         pass

    return {"status": "deleted", "session_id": session_id}


@app.delete("/sessions")
async def delete_all_sessions_endpoint():
    """Clear all saved sessions."""
    global sessions
    sessions = {}
    
    if USE_DB:
        from database import delete_all_sessions as db_delete_all
        db_delete_all()
        
    return {"status": "cleared", "count": 0} # Count not easily available for mass delete without query first


@app.get("/session")
async def get_session(session_id: str = None):
    """Get saved session by id (from DB or in-memory). Used to restore dashboard after page refresh."""
    if not session_id:
        raise HTTPException(status_code=400, detail="session_id required")
    global sessions
    if USE_DB:
        meta = get_session_from_db(session_id)
        if meta and meta.get("chart_data") is not None:
            ai = meta.get("ai_insights")
            if not ai and USE_REDIS:
                ai = get_pending_ai(session_id)
            return {
                "session_id": session_id,
                "filename": meta.get("filename"),
                "chart_data": meta["chart_data"],
                "ai_insights": ai,
            }
    if session_id in sessions:
        s = sessions[session_id]
        ai = s.get("ai_insights") or (get_pending_ai(session_id) if USE_REDIS else None)
        return {
            "session_id": session_id,
            "filename": s.get("filename"),
            "chart_data": s.get("chart_data"),
            "ai_insights": ai,
        }
    raise HTTPException(status_code=404, detail="Session not found or expired.")


@app.get("/ai-insights")
async def get_ai_insights(session_id: str = None):
    """Get AI insights for the session (charts-first: call after upload)."""
    global current_df, sessions, pending_ai
    if session_id and USE_REDIS:
        ai = get_pending_ai(session_id)
        if ai is not None:
            return ai
    if session_id and session_id in pending_ai and pending_ai[session_id] is not None:
        return pending_ai[session_id]
    if session_id:
        meta = _get_session_meta(session_id)
        if meta and meta.get("ai_insights"):
            return meta["ai_insights"]
    if session_id and session_id in sessions and sessions[session_id].get("ai_insights"):
        return sessions[session_id]["ai_insights"]
    if current_df is not None and not session_id:
        return processor.get_ai_insights(current_df)
    return {"summary": "Loading...", "sentiment": "Neutral", "recommendation": "Wait or re-upload."}


@app.post("/chat")
async def chat_with_data(query: str = Form(...), session_id: str = Form(None)):
    """Natural Language Querying for the current dataset. Safer: timeout + restricted globals."""
    df = _get_df(session_id)
    if df is None:
        raise HTTPException(status_code=400, detail="No data uploaded yet.")
    result = processor.chat_with_data(df, query)
    return result


@app.post("/export-current")
async def export_current_view(format: str = "xlsx", session_id: str = Form(None), date_from: str = Form(None), date_to: str = Form(None)):
    """Export current view (no re-upload). Uses in-session data and optional date filter."""
    df = _get_df(session_id)
    if df is None:
        raise HTTPException(status_code=400, detail="No data loaded. Upload a file first.")
    df = _filter_df_by_date(df.copy(), date_from, date_to)
    for col in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.strftime("%d-%m-%Y %H:%M").replace("NaT", "")
    out = io.BytesIO()
    meta = _get_session_meta(session_id)
    name = (meta.get("filename") if meta else None) or (sessions.get(session_id, {}).get("filename") if session_id else None) or "current_view"
    safe_name = (name or "export").rsplit(".", 1)[0][:50]
    if format.lower() == "csv":
        df.to_csv(out, index=False, encoding="utf-8-sig")
        media_type = "text/csv"
        filename = f"{safe_name}_current_view.csv"
    else:
        df.to_excel(out, index=False, engine="openpyxl")
        media_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        filename = f"{safe_name}_current_view.xlsx"
    out.seek(0)
    return StreamingResponse(out, media_type=media_type, headers={"Content-Disposition": f"attachment; filename={filename}"})


@app.post("/compare")
async def compare_files(file1: UploadFile = File(...), file2: UploadFile = File(...)):
    """Multi-file comparison: process two files and return side-by-side KPIs and deltas."""
    temp_paths = []
    try:
        for i, f in enumerate([file1, file2]):
            ext = f.filename.split(".")[-1].lower()
            path = os.path.join(os.getcwd(), f"temp_compare_{uuid.uuid4()}.{ext}")
            with open(path, "wb") as buf:
                shutil.copyfileobj(f.file, buf)
            temp_paths.append((path, ext))
        df1 = processor.process_file(temp_paths[0][0], temp_paths[0][1])
        df2 = processor.process_file(temp_paths[1][0], temp_paths[1][1])
        c1 = processor.get_chart_data(df1)
        c2 = processor.get_chart_data(df2)
        t1 = c1.get("total_tickets") or 0
        t2 = c2.get("total_tickets") or 0
        s1 = c1.get("sla_met_pct") or 0
        s2 = c2.get("sla_met_pct") or 0
        return {
            "chart_data_1": c1,
            "chart_data_2": c2,
            "filename_1": file1.filename,
            "filename_2": file2.filename,
            "comparison": {
                "total_tickets_delta": t2 - t1,
                "sla_met_pct_delta": round(s2 - s1, 1),
                "total_1": t1,
                "total_2": t2,
                "sla_1": s1,
                "sla_2": s2,
            },
        }
    finally:
        for path, _ in temp_paths:
            if os.path.exists(path):
                try:
                    os.remove(path)
                except Exception:
                    pass


@app.get("/tickets_for_month")
async def get_tickets_for_month(session_id: str = None, month: str = None):
    """Return all ticket rows for a given month (e.g. month='Dec 2025'). Used by month-detail modal."""
    if not session_id or not month:
        raise HTTPException(status_code=400, detail="session_id and month required")
    df = _get_df(session_id)
    if df is None:
        raise HTTPException(status_code=404, detail="No data for this session.")
    month_col = "month_year" if "month_year" in df.columns else "month_name"
    if month_col not in df.columns:
        return {"columns": [], "rows": []}
    subset = df[df[month_col].astype(str).str.strip() == str(month).strip()].copy()
    for col in subset.columns:
        if pd.api.types.is_datetime64_any_dtype(subset[col]):
            subset[col] = subset[col].dt.strftime("%d-%m-%Y %H:%M").replace("NaT", "")
    subset = subset.fillna("")
    columns = [str(c) for c in subset.columns]
    rows = subset.astype(str).to_dict(orient="records")
    return {"columns": columns, "rows": rows, "month": month, "total": len(rows)}


@app.get("/workload-tickets")
async def get_workload_tickets(session_id: str = None, category: str = None, month: str = None):
    """Return tickets for a given service (category) and optionally month. For Detailed Service Workload cell click."""
    if not session_id or not category:
        raise HTTPException(status_code=400, detail="session_id and category required")
    df = _get_df(session_id)
    if df is None:
        raise HTTPException(status_code=404, detail="No data for this session.")
    subset = df[df["category"].astype(str).str.strip() == str(category).strip()].copy()
    if month:
        month_col = "month_year" if "month_year" in df.columns else "month_name"
        if month_col in subset.columns:
            subset = subset[subset[month_col].astype(str).str.strip() == str(month).strip()]
    for col in subset.columns:
        if pd.api.types.is_datetime64_any_dtype(subset[col]):
            subset[col] = subset[col].dt.strftime("%Y-%m-%d %H:%M").replace("NaT", "")
    subset = subset.fillna("")
    columns = [str(c) for c in subset.columns]
    rows = subset.astype(str).to_dict(orient="records")
    return {"columns": columns, "rows": rows, "total": len(rows), "category": category, "month": month or None}


@app.get("/raw-data")
async def get_raw_data(session_id: str = None, limit: int = 100, offset: int = 0):
    """Return paginated raw rows for the session (all columns). For dashboard raw-data table."""
    if not session_id:
        raise HTTPException(status_code=400, detail="session_id required")
    df = _get_df(session_id)
    if df is None:
        raise HTTPException(status_code=404, detail="No data for this session.")
    df = df.copy()
    for col in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.strftime("%Y-%m-%d %H:%M").replace("NaT", "")
    df = df.fillna("")
    total = len(df)
    subset = df.iloc[offset : offset + limit]
    columns = [str(c) for c in subset.columns]
    rows = subset.astype(str).to_dict(orient="records")
    return {"columns": columns, "rows": rows, "total": total, "limit": limit, "offset": offset}


@app.get("/filtered-chart-data")
async def get_filtered_chart_data(
    session_id: str = None,
    month: str = None,
    category: str = None,
    priority: str = None,
):
    """Return chart_data filtered by month, category, and/or priority. For dashboard slicers."""
    if not session_id:
        raise HTTPException(status_code=400, detail="session_id required")
    df = _get_df(session_id)
    if df is None:
        raise HTTPException(status_code=404, detail="No data for this session.")
    df = df.copy()
    if month:
        month_col = "month_year" if "month_year" in df.columns else "month_name"
        if month_col in df.columns:
            df = df[df[month_col].astype(str).str.strip() == str(month).strip()]
    if category:
        if "category" in df.columns:
            df = df[df["category"].astype(str).str.strip() == str(category).strip()]
    if priority:
        if "priority" in df.columns:
            df = df[df["priority"].astype(str).str.strip() == str(priority).strip()]
    if len(df) == 0:
        empty_cd = {"workload": [], "sla": [], "priority": [], "services": [], "total_tickets": 0, "sla_met_pct": 0, "workload_table": {"months": [], "rows": []}, "sla_by_category": [], "breach_list": [], "categories": []}
        return {"chart_data": empty_cd, "filtered": True, "total_rows": 0}
    chart_data = processor.get_chart_data(df)
    return {"chart_data": chart_data, "filtered": True, "total_rows": len(df)}


@app.get("/report", response_class=HTMLResponse)
async def template_report(session_id: str = None):
    """Template report: HTML of current view (KPIs, tables, AI summary)."""
    meta = _get_session_meta(session_id) if session_id else None
    df = _get_df(session_id)
    chart_data = None
    ai_insights = None
    fn = "Report"
    if session_id and meta:
        chart_data = meta.get("chart_data")
        ai_insights = meta.get("ai_insights")
        fn = meta.get("filename") or "Report"
    if df is not None:
        if not chart_data:
            chart_data = processor.get_chart_data(df)
        if not ai_insights:
            ai_insights = processor.get_ai_insights(df)
    if not session_id or not meta:
        fn = (sessions.get(session_id, {}).get("filename") if session_id else None) or fn
    chart_data = chart_data or (meta.get("chart_data") if meta else None) or {}
    ai_insights = ai_insights or (meta.get("ai_insights") if meta else None) or {"summary": "N/A", "recommendation": "N/A"}
    if not chart_data:
        return "<html><body><p>No data loaded. Upload a file first.</p></body></html>"
    html = f"""<!DOCTYPE html><html><head><meta charset="utf-8"/><title>ITSM Report - {fn}</title>
<style>body{{font-family:system-ui;margin:24px;background:#0f172a;color:#e2e8f0;}} table{{border-collapse:collapse;width:100%;}} th,td{{border:1px solid #334155;padding:8px;text-align:left;}} th{{background:#1e293b;}}</style></head><body>
<h1>ITSM Analytics Report</h1><p>Data: {fn}</p>
<h2>KPIs</h2><p>Total tickets: {chart_data.get('total_tickets', 0)} | SLA met: {chart_data.get('sla_met_pct')}% | Avg resolve: {chart_data.get('avg_resolve_hours')}h</p>
<h2>AI Summary</h2><p>{ai_insights.get('summary', 'N/A')}</p><p><strong>Recommendation:</strong> {ai_insights.get('recommendation', 'N/A')}</p>
<h2>SLA by Category (top 5)</h2><table><tr><th>Category</th><th>Breached</th><th>Met</th><th>Total</th><th>SLA %</th></tr>"""
    for row in (chart_data.get("sla_by_category") or [])[:5]:
        html += f"<tr><td>{row.get('category')}</td><td>{row.get('breached')}</td><td>{row.get('met')}</td><td>{row.get('total')}</td><td>{row.get('sla_pct')}%</td></tr>"
    html += "</table></body></html>"
    return html


def _get_chart_and_insights(session_id: str = None):
    """Return (chart_data, ai_insights, filename) for reporting; compute if missing."""
    meta = _get_session_meta(session_id) if session_id else None
    df = _get_df(session_id)
    chart_data = meta.get("chart_data") if meta else None
    ai_insights = meta.get("ai_insights") if meta else None
    fn = (meta.get("filename") if meta else None) or (sessions.get(session_id, {}).get("filename") if session_id else None) or "Report"
    if df is not None:
        if not chart_data:
            chart_data = processor.get_chart_data(df)
        if not ai_insights:
            ai_insights = processor.get_ai_insights(df)
    chart_data = chart_data or {}
    ai_insights = ai_insights or {"summary": "N/A", "recommendation": "N/A"}
    return chart_data, ai_insights, fn


@app.get("/report/monthly")
async def monthly_report(
    session_id: str = None,
    format: str = "pdf",
    full_breach_list: bool = False,
    max_breach: int = 50,
    max_categories: int = 12,
    include_appendix: bool = False,
):
    """Generate Monthly ITSM Report: PDF, Word (docx), or HTML. full_breach_list=1 or max_breach=0 for all breaches; max_categories=0 for all in main table; include_appendix=1 for appendix in report."""
    chart_data, ai_insights, fn = _get_chart_and_insights(session_id)
    if not chart_data:
        raise HTTPException(status_code=400, detail="No data loaded. Upload a file and use session_id.")
    safe_name = (fn or "Report").rsplit(".", 1)[0][:40]
    fmt = (format or "pdf").lower()
    opts = {"full_breach_list": full_breach_list, "max_breach": max_breach, "max_categories": max_categories, "include_appendix": include_appendix}
    if fmt == "html":
        html = build_monthly_report_html(chart_data, ai_insights, fn, **opts)
        return HTMLResponse(html)
    if fmt == "pdf":
        blob = build_monthly_report_pdf(chart_data, ai_insights, fn, **opts)
        return StreamingResponse(
            io.BytesIO(blob),
            media_type="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="{safe_name}_Monthly_Report.pdf"'},
        )
    if fmt == "docx":
        blob = build_monthly_report_docx(chart_data, ai_insights, fn, **opts)
        return StreamingResponse(
            io.BytesIO(blob),
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers={"Content-Disposition": f'attachment; filename="{safe_name}_Monthly_Report.docx"'},
        )
    raise HTTPException(status_code=400, detail="format must be pdf, docx, or html")


@app.get("/report/slides")
async def report_slides(session_id: str = None, format: str = "html"):
    """Export as presentation: HTML (one slide per section) or PPTX. Requires session_id with loaded data."""
    chart_data, ai_insights, fn = _get_chart_and_insights(session_id)
    if not chart_data:
        raise HTTPException(status_code=400, detail="No data loaded. Upload a file and use session_id.")
    safe_name = (fn or "Report").rsplit(".", 1)[0][:40]
    fmt = (format or "html").lower()
    if fmt == "html":
        html = build_slides_html(chart_data, ai_insights, fn)
        return HTMLResponse(html)
    if fmt == "pptx":
        blob = build_slides_pptx(chart_data, ai_insights, fn)
        return StreamingResponse(
            io.BytesIO(blob),
            media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
            headers={"Content-Disposition": f'attachment; filename="{safe_name}_Presentation.pptx"'},
        )
    raise HTTPException(status_code=400, detail="format must be html or pptx")


@app.get("/report/pivot-pdf")
async def report_pivot_pdf(session_id: str = None):
    """Generate pivot-style / Excel-style PDF: yellow section headers, month columns, Grand Total rows, SLA % colors. Same layout as the Excel pivot report."""
    chart_data, _, fn = _get_chart_and_insights(session_id)
    if not chart_data:
        raise HTTPException(status_code=400, detail="No data loaded. Upload a file and use session_id.")
    safe_name = (fn or "Report").rsplit(".", 1)[0][:40]
    blob = build_pivot_style_report_pdf(chart_data, fn)
    return StreamingResponse(
        io.BytesIO(blob),
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{safe_name}_Pivot_Report.pdf"'},
    )


@app.get("/report/full-pdf")
async def report_full_consolidated_pdf(session_id: str = None):
    """Generate a single Consolidated PDF containing Executive Summary, Charts, Breach List, and Detailed Pivot Tables in one file."""
    chart_data, ai_insights, fn = _get_chart_and_insights(session_id)
    if not chart_data:
        raise HTTPException(status_code=400, detail="No data loaded. Upload a file and use session_id.")
    safe_name = (fn or "Report").rsplit(".", 1)[0][:40]
    blob = build_full_consolidated_report_pdf(chart_data, ai_insights, fn)
    return StreamingResponse(
        io.BytesIO(blob),
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{safe_name}_Full_Report.pdf"'},
    )


@app.get("/report/appendix")
async def report_appendix(session_id: str = None):
    """Download data appendix as Excel: Breach list, SLA by category, Workload table, Top services. Requires session_id."""
    chart_data, _, fn = _get_chart_and_insights(session_id)
    if not chart_data:
        raise HTTPException(status_code=400, detail="No data loaded. Upload a file and use session_id.")
    safe_name = (fn or "Report").rsplit(".", 1)[0][:40]
    try:
        blob = build_report_appendix_excel(chart_data)
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))
    return StreamingResponse(
        io.BytesIO(blob),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{safe_name}_Data_Appendix.xlsx"'},
    )


@app.post("/export")
async def export_data(file: UploadFile = File(...), format: str = "xlsx"):
    """Export processed ITSM data as Excel or CSV for reports and data management."""
    import pandas as pd
    file_ext = file.filename.split(".")[-1].lower()
    temp_filename = f"temp_export_{uuid.uuid4()}.{file_ext}"
    temp_path = os.path.join(os.getcwd(), temp_filename)
    try:
        with open(temp_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        df = processor.process_file(temp_path, file_ext)
        # Normalize date columns to DD-MM-YYYY HH:MM for export
        for col in df.columns:
            if pd.api.types.is_datetime64_any_dtype(df[col]):
                df[col] = df[col].dt.strftime("%d-%m-%Y %H:%M").replace("NaT", "")
        out = io.BytesIO()
        safe_name = (file.filename or "export").rsplit(".", 1)[0][:50]
        if format.lower() == "csv":
            df.to_csv(out, index=False, encoding="utf-8-sig")
            media_type = "text/csv"
            filename = f"{safe_name}_processed.csv"
        else:
            df.to_excel(out, index=False, engine="openpyxl")
            media_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            filename = f"{safe_name}_processed.xlsx"
        out.seek(0)
        return StreamingResponse(
            out,
            media_type=media_type,
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )
    except Exception as e:
        print(f"Export error: {e}")
        raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")
    finally:
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except Exception:
                pass


# Serve the React frontend
frontend_dist = os.path.join(os.path.dirname(os.getcwd()), "frontend", "dist")
if os.path.exists(frontend_dist):
    app.mount("/", StaticFiles(directory=frontend_dist, html=True), name="frontend")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8005)
