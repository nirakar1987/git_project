"""Redis store for dataframe cache and pending AI (session data)."""
import os
import pickle
import base64
import json

import redis
import pandas as pd

REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
# TTL: dataframe cache 24h, pending AI 1h
DF_TTL = int(os.getenv("REDIS_DF_TTL", 86400))
PENDING_AI_TTL = int(os.getenv("REDIS_PENDING_AI_TTL", 3600))

_redis_client = None


def get_redis():
    global _redis_client
    if _redis_client is None:
        _redis_client = redis.from_url(REDIS_URL, decode_responses=False)
    return _redis_client


def cache_dataframe(session_id: str, df: pd.DataFrame):
    """Store dataframe in Redis (pickled)."""
    try:
        r = get_redis()
        key = f"session:df:{session_id}"
        r.setex(key, DF_TTL, pickle.dumps(df, protocol=pickle.HIGHEST_PROTOCOL))
    except Exception as e:
        print(f"Redis cache_dataframe error: {e}")


def get_cached_dataframe(session_id: str) -> pd.DataFrame | None:
    """Retrieve dataframe from Redis. Returns None if missing or error."""
    try:
        r = get_redis()
        key = f"session:df:{session_id}"
        data = r.get(key)
        if data is None:
            return None
        return pickle.loads(data)
    except Exception as e:
        print(f"Redis get_cached_dataframe error: {e}")
        return None


def set_pending_ai(session_id: str, ai_insights: dict):
    """Store pending/completed AI insights in Redis."""
    try:
        r = get_redis()
        key = f"pending_ai:{session_id}"
        r.setex(key, PENDING_AI_TTL, json.dumps(ai_insights).encode("utf-8"))
    except Exception as e:
        print(f"Redis set_pending_ai error: {e}")


def get_pending_ai(session_id: str) -> dict | None:
    """Get AI insights from Redis. Returns None if missing or error."""
    try:
        r = get_redis()
        key = f"pending_ai:{session_id}"
        data = r.get(key)
        if data is None:
            return None
        return json.loads(data.decode("utf-8"))
    except Exception as e:
        print(f"Redis get_pending_ai error: {e}")
        return None
