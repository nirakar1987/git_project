================================================================================
ITSM Analytics – Deploy on RHEL (Red Hat Enterprise Linux)
================================================================================

This archive contains the full app. Use it to deploy on RHEL (or any RHEL-based
system such as Rocky Linux, AlmaLinux, CentOS Stream).

PREREQUISITES ON RHEL
---------------------
• Docker and Docker Compose (v2). On RHEL 8/9 you can use:

    sudo dnf config-manager --add-repo https://download.docker.com/linux/rhel/docker-ce.repo
    sudo dnf install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
    sudo systemctl enable --now docker
    sudo usermod -aG docker $USER
    # Log out and back in (or run: newgrp docker)

STEPS ON THE RHEL SERVER
------------------------
1. Copy this archive to the server (e.g. scp, rsync, or USB).

2. Extract:
    tar -xzf itsm_analytics_rhel_backup.tar.gz
    cd itsm_analytics

3. Create .env (optional; for AI insights set GEMINI_API_KEY):
    cp .env.example .env
    # Edit .env if needed: nano .env

4. Build and start:
    docker compose up -d --build

5. Open in browser:
    http://<server-IP>:3000

6. (Optional) Open firewall:
    sudo firewall-cmd --permanent --add-port=3000/tcp
    sudo firewall-cmd --reload

For HTTPS and a domain name, put Nginx or Caddy in front (see DEPLOY_LINUX.md).

================================================================================
