# Analysis: Your Three HPSM Files (Incident, SR, Change)

Based on the structure of the three files you shared, here is how each maps to the app and how you can **analyze and visualize** them.

---

## 1. File Structures (Columns Observed)

All three files appear to be **UTF-16, tab-delimited** (typical HPSM export).

### 1.1 Incident – `HPSM_Tickets _IC.csv`

| Column         | Sample / notes | Maps to app |
|----------------|----------------|-------------|
| **Description** | Long text (multi-line possible) | summary (or keep as extra) |
| **SLT Breached** | TRUE / FALSE | sla_status → Met / Breached |
| **Incident ID** | IC3290981 | ticket_id |
| **Open Time**   | 01-08-2025 00:08 | created_at |
| **Assignee Name** | kumarsiva | (keep as extra) |
| **Alert Status** | closed | (optional status) |
| **Status**      | Closed | status |
| **Service**     | SAL-REMOTE-ACCESS-NEXT-GEN-BP-SERVICE | category |
| **Title**       | SAL - BP hosted access issue | summary (short) |

- **Close Time:** If your full export has a “Close Time” or “Closed Time” column, it should map to `resolved_at` for resolve-time and monthly charts.
- **Analysis:** This file fits the current app best: ID, open time, status, service (category), SLA, summary. You get **monthly workload by service**, **SLA %**, **priority** (if you add a Priority column or derive from elsewhere), **breach list**, etc.

### 1.2 Service Request – `SR_Tickets (1).csv`

| Column              | Sample / notes | Maps to app |
|---------------------|----------------|-------------|
| **ID**              | SR2293355      | ticket_id |
| **Current Phase**   | Avaya SR Processing | (workflow – keep as extra) |
| **Status (Sys Internal)** | closed | status |
| **Approval Status** | approved | (keep as extra) |
| **Brief Description** | “You are requesting Admin Access…” | summary |
| **Service**         | STARS-XUI, STARS-SSDP/ESCP, SAL-ALARMING-SERVICE, etc. | category |
| **Urgency**         | Minor | priority |
| **Escalation**      | (empty), SLA-Breached, SLA-Warning | sla_status |

- **Dates:** The header shown has **no “Submit Date” or “Delivery Date”**. If your full SR export has columns like “Submit Date”, “Request Date”, “Closed Date”, or “Delivery Date”, they should map to `created_at` and `resolved_at` so you get **monthly workload** and **fulfillment time**. If there are no date columns, the app can still show **volume by Service**, **SLA (from Escalation)**, **Urgency**, and **status** – but not by month.
- **SLA:** Map Escalation: “SLA-Breached” → Breached, “SLA-Warning” → Warning (or Met), blank → Met/N/A.

### 1.3 Change Task – `Change_Ticket (1).csv`

| Column          | Sample / notes | Maps to app |
|-----------------|----------------|-------------|
| **Title**       | Monthly deployment of latest SAL/Axeda… | summary |
| **Change ID**   | CR126763      | ticket_id |
| **Workflow**    | Avaya Standard Change, Avaya Change with Test… | category (or keep as extra) |
| **Priority**    | Medium, Low, High | priority |
| **Phase**       | Change Implementation, Change Evaluation and Closure… | status |
| **Planned Start** | 01-09-2025 03:30, 1/23/2025 3:30 | created_at |
| **Planned End** | 01-09-2025 04:30, 1/23/2025 6:29 | resolved_at (or use Actual End if present) |
| **Status**      | terminated, closed | status |
| **Approval Status** | Approved | (keep as extra) |

- **Actual Start/End:** If the export has “Actual Start” and “Actual End”, you can use those for `created_at` / `resolved_at` (or for a separate “actual duration” metric). Otherwise “Planned Start/End” still give you **monthly volume** and a proxy for timeline.
- **Analysis:** You get **monthly workload by Workflow**, **priority**, **status/phase**, and (if you add SLA or use status) success/terminated view.

---

## 2. How to Analyze & Visualize

### 2.1 Per-type analysis (upload one file at a time)

| Data type   | What you can do today / after mapping |
|------------|---------------------------------------|
| **Incident** | Monthly workload by Service, SLA %, breach list, top services, priority (if column exists). **Best fit** for current app. |
| **Service Request** | Volume by Service (category), SLA from Escalation, Urgency, Status. If you add date columns to the export, add mapping → same monthly and SLA views as Incident. |
| **Change** | Monthly workload by Workflow, Priority, Status/Phase. Use Planned Start/End (or Actual) for timeline. Optional: “By workflow” and “By phase” charts. |

### 2.2 Combined analysis (all three in one view)

- **Option A – Three separate uploads, same session:**  
  Extend the app so you can “add” a second and third file to the same session, each tagged as Incident / SR / Change. Backend concatenates with a `record_type` column. Then:
  - **Filter:** “All | Incident | Service Request | Change”.
  - **Charts:** Same KPIs and charts (workload, SLA, etc.) filtered by type.
  - **Volume by type:** One pie or bar: Incident vs SR vs Change.

- **Option B – One combined CSV:**  
  If you export or merge the three into one file with a “Type” column (Incident/SR/Change), map that to `record_type` and use the same filter + “Volume by type” as above.

### 2.3 Suggested visualizations

| Visualization        | Incident | SR | Change | Combined |
|----------------------|----------|-----|--------|----------|
| Monthly workload (stacked by category) | ✅ | ✅ (if dates) | ✅ | ✅ + filter by type |
| SLA % (Met vs Breached) | ✅ | ✅ (from Escalation) | ⚠ (if you add SLA) | ✅ |
| Top services / categories | ✅ | ✅ | ✅ (Workflow) | ✅ |
| Priority distribution | ✅ (if column) | ✅ (Urgency) | ✅ | ✅ |
| Breach list (export) | ✅ | ✅ | – | ✅ |
| Volume by type (pie/bar) | – | – | – | ✅ |
| By Phase (Change) | – | – | ✅ | – |
| By Urgency (SR) | – | ✅ | – | – |

---

## 3. What to Add in the App (Backend – Processor)

So the app can **ingest and analyze** all three formats:

### 3.1 Extend keyword mapping (processor.py)

Add mappings for **Service Request** and **Change** without breaking Incident:

**Service Request:**

- “ID” (when context is SR) → already matches “id” → ticket_id  
- “Brief Description” → summary  
- “Service” → category  
- “Urgency” → priority  
- “Status (Sys Internal)” or “Status” → status  
- “Escalation” → sla_status (map “SLA-Breached” → Breached, “SLA-Warning” → Warning)  
- If present: “Submit Date” / “Request Date” / “Creation Date” → created_at  
- If present: “Delivery Date” / “Closed Date” / “Actual Finish” → resolved_at  

**Change:**

- “Change ID” → ticket_id  
- “Title” → summary  
- “Workflow” (or “Assignment Group” if present) → category  
- “Priority” → priority  
- “Phase” or “Status” → status  
- “Planned Start” / “Schedule Start” / “Creation Date” → created_at  
- “Planned End” / “Actual End” / “Closed Date” → resolved_at  
- If present: “SLA” / “SLT Breached” → sla_status  

The existing logic that scores header rows and renames columns will pick these up if the keywords are in the mapping lists.

### 3.2 Add record_type (data type) when uploading

- **Option 1 – User selects type:** In the upload UI, add “Data type: Incident / Service Request / Change”. Backend adds `df['record_type'] = selected_type`. No need to change column logic per type; the same normalized schema is used.
- **Option 2 – Auto-detect:** If “Incident ID” and “Open Time” in columns → Incident; if “Change ID” and “Planned Start” → Change; if “ID” + “Brief Description” + “Service” (and no Incident/Change markers) → SR. Then set `record_type` accordingly.

### 3.3 SR: Escalation → sla_status

In normalization, after mapping “Escalation” to `sla_status`:

- `SLA-Breached` / `SLA Breached` → Breached  
- `SLA-Warning` / `SLA Warning` → Warning (or keep as separate for charts)  
- Empty or other → Met or N/A  

### 3.4 Change: date formats

Your Change file has mixed formats: `01-09-2025 03:30` (DD-MM-YYYY) and `1/23/2025 3:30` (M/D/YYYY). The app’s `_safe_parse_dates()` already tries multiple formats; ensure “Planned Start” and “Planned End” are in the list of date columns so they get parsed.

---

## 4. What to Add in the App (Frontend)

- **Upload:** Dropdown “Data type: Incident / Service Request / Change” (or “Auto”), send as `data_type` with the file.
- **Dashboard:** Filter or tabs “All | Incident | Service Request | Change” so all existing charts (workload, SLA, tables) apply to the selected type (or All).
- **Combined view:** When data has multiple `record_type` values, show a small “Volume by type” (pie or bar) and optionally “Monthly trend by type” (stacked or grouped bars).

---

## 5. Quick Reference: Column Mapping

| App field    | Incident (IC)   | Service Request (SR) | Change (CR)      |
|-------------|-----------------|----------------------|------------------|
| ticket_id   | Incident ID     | ID                   | Change ID        |
| created_at  | Open Time       | Submit Date (if any) | Planned Start    |
| resolved_at | Close Time (if any) | Delivery Date (if any) | Planned End / Actual End |
| status      | Status          | Status (Sys Internal) | Phase or Status  |
| category    | Service         | Service              | Workflow         |
| priority    | (if column)     | Urgency              | Priority         |
| summary     | Title or Description | Brief Description | Title            |
| sla_status  | SLT Breached    | Escalation           | (if column)      |

---

## 6. Next Steps

1. **Confirm SR/Change columns:** Check the full SR export for any “Submit Date”, “Closed Date”, or “Delivery Date” column; and Change for “Actual Start”/“Actual End” if you want actual duration.
2. **Implement keyword extensions** in `processor.py` for SR and Change (and Escalation → sla_status).
3. **Add `record_type`** at upload (user choice or auto-detect) and use it in charts and filter.
4. **Add “Data type” in upload UI** and **“Filter by type”** (and optionally “Volume by type”) in the dashboard.

After that, you can **analyze** all three datasets with the same KPIs and **visualize** them per type or combined as above.
