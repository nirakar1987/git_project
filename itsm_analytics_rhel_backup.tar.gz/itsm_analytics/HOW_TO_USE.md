# How to Use the ITSM Analytics App

## 1. Open the app

- **URL:** http://localhost:3000 (after `docker compose up -d` or `docker compose up --build -d`)
- If you see "Upload file" and no charts, the app is ready; you just need to upload data.

---

## 2. Upload your data

1. **Choose data type (optional but recommended for HPSM):**
   - **Auto** – App tries to detect: Incident / Service Request / Change Task from column names.
   - **Incident** – Use for Incident exports (e.g. `HPSM_Tickets _IC.csv`).
   - **Service Request** – Use for SR exports (e.g. `SR_Tickets (1).csv`).
   - **Change Task** – Use for Change exports (e.g. `Change_Ticket (1).csv`).

2. **Upload a file:**
   - Click **"Upload file"** or **"Choose file"** (or **"Upload New"** if you already have data).
   - Select a **CSV** or **Excel** file (e.g. from HPSM export).
   - The app will process it and show the dashboard.

3. **If you see "same data" or old session:**
   - The app may have **restored a previous session** (saved in browser/localStorage or DB).
   - To start fresh: upload a **new file** (that will replace the current session).
   - Or: in the **sidebar**, open **"Saved sessions"** and pick another session, or delete the current one and upload again.

---

## 3. What you see after upload

- **Tabs:** **Overview** | **Workload** | **SLA Analysis**
- **Overview:** KPIs (Total tickets, SLA %, High priority, Avg resolution), AI summary, Service pulse, High-level workload trend.
- **Workload:** Monthly workload (stacked) bar chart, Priority breakdown, Workload table (service × month). **Click a bar** on the monthly chart to open **month details** (breakdown + all tickets for that month + Export Excel/CSV).
- **SLA Analysis:** SLA pie, breach list, SLA by category.

If you chose a **data type** (Incident / Service Request / Change Task), you may see:
- **"Show:"** filter (All | Incident (N) | Service Request (N) | Change Task (N)).
- **"Volume by type"** pie when there is more than one type.

Use **"Show:"** to switch between **All** and a single type; charts and KPIs update for the selected view.

---

## 4. Optional: date range and compare

- **From / To:** Set dates and click **Apply** to filter the current dataset by that range (re-upload with filter).
- **Compare:** Set **Compare** From/To to compare with another period (deltas in KPIs).

---

## 5. Exports

- **Excel / CSV:** Export the **uploaded file** (processed once at upload).
- **Current → Excel / Current → CSV:** Export the **current view** (with date filter if applied).
- **Month details:** After you **click a bar** on the Monthly Workload chart, in the popup use **Export Excel** or **Export CSV** to download that month’s tickets.

---

## 6. If data looks wrong or "same" every time

1. **Check the file you’re uploading**
   - Different files (Incident vs SR vs Change) should show different numbers if the data is different.
   - Same file always gives the same result; that’s expected.

2. **Session / cache**
   - The app **saves the last session** (e.g. in DB/Redis or browser). Loading the page can **restore that session** instead of showing “no data”.
   - To force a clean view: upload a **new file** (or pick a different saved session from the sidebar).

3. **Browser console (F12)**
   - Open **Developer Tools (F12)** → **Console**.
   - Look for **red errors** (e.g. failed API calls, 404, 500). Those explain why data might not load or update.
   - **Network** tab: after you click Upload, check the **/upload** request: status 200 and response with `chart_data` means the backend processed the file; if you still see old data, the frontend is likely showing a previous session.

4. **Data type and columns**
   - For **Incident:** ensure columns like Incident ID, Open Time, Service, Status, SLT Breached (or similar) exist.
   - For **Service Request:** Brief Description, Service, Status, Urgency, Escalation (or similar).
   - For **Change Task:** Change ID, Planned Start, Planned End, Workflow, Priority, Phase/Status (or similar).
   - If columns don’t match, choose the correct **Data type** or use **Auto** and check the verification message after upload.

---

## 7. Quick checklist

| Step | Action |
|------|--------|
| 1 | Open http://localhost:3000 |
| 2 | (Optional) Select **Data type**: Auto / Incident / Service Request / Change Task |
| 3 | Click **Upload file** / **Choose file** and select your CSV or Excel |
| 4 | Wait for dashboard to load (Overview, Workload, SLA tabs) |
| 5 | Use **Show:** (if visible) to switch All vs one type |
| 6 | Click a **bar** on Monthly Workload to see month details and export that month |
| 7 | Use **Current → Excel/CSV** or **Export** for full or filtered export |

If you tell me exactly what you see (e.g. “same numbers for Incident and SR” or “console error: …”), I can suggest the next step (e.g. check backend logs or request format).
