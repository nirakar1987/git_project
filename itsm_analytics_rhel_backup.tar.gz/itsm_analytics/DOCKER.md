# ITSM Analytics – Docker Setup

Run the app with **PostgreSQL** (session storage) and **Redis** (dataframe cache) using Docker Compose.

## Prerequisites

- Docker and Docker Compose
- Optional: `GEMINI_API_KEY` for AI insights (set in `.env` or export)

## Quick start

```bash
# From project root (itsm_analytics)
docker compose up --build
```

- **App (frontend + API proxy):** http://localhost:3000  
- **Backend API only:** http://localhost:8005  
- **PostgreSQL:** localhost:5432 (user `itsm`, password `itsm_secret`, db `itsm_analytics`)  
- **Redis:** localhost:6379  

## Environment variables

Create a `.env` in the project root (optional):

```env
GEMINI_API_KEY=your_gemini_api_key
```

Compose uses:

- `DATABASE_URL` – set automatically for the backend (PostgreSQL)
- `REDIS_URL` – set automatically for the backend (Redis)
- `GEMINI_API_KEY` – optional; can be passed via `.env`

## How data is saved

When you upload a file (with Docker running):

1. **Backend** processes the file and generates `chart_data` (KPIs, workload, SLA, etc.) and starts AI insights in the background.
2. **PostgreSQL** (when `DATABASE_URL` is set):
   - Saves a row per upload: `session_id`, `filename`, `chart_data` (JSON), `ai_insights` (JSON, updated when AI finishes), `created_at`.
   - Used to restore session metadata; chart data and AI summary persist across restarts.
3. **Redis** (when `REDIS_URL` is set):
   - Caches the raw dataframe (pickled) for the session with TTL 24 hours.
   - Used for **Export current view** and **Chat** so they work without re-uploading.
   - After 24h the cache expires; chart data in PostgreSQL remains, but export/chat for that session need a re-upload.
4. **Volumes** `postgres_data` and `redis_data` keep DB and Redis data across `docker compose down`.

Without Docker (no `DATABASE_URL` / `REDIS_URL`), sessions are in-memory only and are lost on backend restart.

## Run without Docker

Without `DATABASE_URL` and `REDIS_URL`, the app runs with in-memory sessions only (no persistence). Run backend and frontend as usual.
