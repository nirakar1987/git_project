# Deploy ITSM Analytics on a Linux Server

This guide explains how to deploy the ITSM Analytics app on another Linux server (e.g. Ubuntu, Debian, RHEL, or any distro with Docker).

---

## Prerequisites on the Linux server

1. **Docker** (20.10+)
2. **Docker Compose** (v2+)
3. **Git** (optional; if you deploy by cloning the repo)

### Install Docker and Docker Compose (Ubuntu/Debian)

```bash
# Update and install dependencies
sudo apt-get update
sudo apt-get install -y ca-certificates curl gnupg

# Add Docker’s official GPG key and repo
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Install Docker Engine and Compose plugin
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# Allow your user to run Docker (optional)
sudo usermod -aG docker $USER
# Log out and back in (or newgrp docker) for group to apply
```

---

## 1. Copy the app to the Linux server

### Option A: Copy project folder (e.g. from Windows)

From your Windows machine (PowerShell or similar):

```powershell
# Using SCP (replace user and server with your Linux user and hostname/IP)
scp -r C:\Linux_Application\itsm_analytics user@your-linux-server:/home/user/itsm_analytics
```

Or use **rsync** (if available) to exclude large/unnecessary folders:

```bash
rsync -avz --exclude 'node_modules' --exclude '__pycache__' --exclude '.git' \
  /path/to/itsm_analytics/ user@your-linux-server:/home/user/itsm_analytics/
```

### Option B: Clone from Git (if the project is in a repo)

On the Linux server:

```bash
cd /home/user  # or your preferred directory
git clone <your-repo-url> itsm_analytics
cd itsm_analytics
```

---

## 2. Configure environment on the server

```bash
cd /home/user/itsm_analytics   # or wherever you copied/cloned the app

# Create .env from example (optional)
cp .env.example .env

# Edit .env: set GEMINI_API_KEY if you use AI insights
nano .env
```

Example `.env`:

```env
# Optional: for AI insights
GEMINI_API_KEY=your_gemini_api_key

# Optional: override if using external PostgreSQL/Redis (see section 5)
# DATABASE_URL=postgresql://user:pass@external-host:5432/itsm_analytics
# REDIS_URL=redis://external-redis:6379/0
```

Leave `DATABASE_URL` and `REDIS_URL` unset to use the Postgres and Redis containers from `docker-compose.yml`.

---

## 3. Build and start the app

```bash
cd /home/user/itsm_analytics

# Build images and start all services in the background
docker compose up -d --build
```

- **First run:** `--build` builds the frontend and backend images.
- **App (frontend + API):** http://\<server-ip\>:3000  
- **Backend API only:** http://\<server-ip\>:8005  

To open the frontend port in the firewall (Ubuntu with UFW):

```bash
sudo ufw allow 3000/tcp
sudo ufw reload
```

---

## 4. Use a reverse proxy (recommended for production)

To serve the app over **HTTPS** and a **domain name**, put Nginx (or Caddy) in front of the app on the same server.

### Example: Nginx as reverse proxy

1. Install Nginx on the server (not in Docker):  
   `sudo apt-get install -y nginx`

2. Create a site config, e.g. `/etc/nginx/sites-available/itsm-analytics`:

```nginx
server {
    listen 80;
    server_name your-domain.com;   # or your server IP

    client_max_body_size 50M;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

3. Enable the site and reload Nginx:

```bash
sudo ln -s /etc/nginx/sites-available/itsm-analytics /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

4. (Optional) Add HTTPS with **Let’s Encrypt**:

```bash
sudo apt-get install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

Then users access the app at **https://your-domain.com**. You can close direct access to port 3000 in the firewall and leave only 80/443 open.

### Alternative: Caddy

Caddy can terminate HTTPS automatically. Example `Caddyfile`:

```
your-domain.com {
    reverse_proxy localhost:3000
}
```

---

## 5. Production tips

### Persistence

- **PostgreSQL** and **Redis** data are stored in Docker volumes (`postgres_data`, `redis_data`). They persist across `docker compose down` and restarts.
- Back up the volume data if you need to restore later (e.g. `docker run --rm -v itsm_analytics_postgres_data:/data -v $(pwd):/backup alpine tar czf /backup/postgres_backup.tar.gz -C /data .`).

### Restart policy

To make the stack start on boot and restart on failure, add to each service in `docker-compose.yml`:

```yaml
restart: unless-stopped
```

Then:

```bash
docker compose up -d
```

### Secrets

- Do **not** commit `.env` with real keys. Use `.env.example` as a template and keep `.env` only on the server.
- For production, consider stronger PostgreSQL and Redis passwords and set them via `.env` (and adjust `DATABASE_URL` / `REDIS_URL` in `docker-compose.yml` or in the backend service env).

### Using external PostgreSQL or Redis

If you already have PostgreSQL or Redis on the same server or another host:

1. Set in `.env` (or in the backend service environment):
   - `DATABASE_URL=postgresql://user:password@host:5432/itsm_analytics`
   - `REDIS_URL=redis://host:6379/0`
2. In `docker-compose.yml`, you can **remove** the `postgres` and `redis` services and their `depends_on` from the backend, then run only `backend` and `frontend`.

### Ports

- By default the app exposes **3000** (frontend) and **8005** (backend). If you use a reverse proxy, you can bind the backend to `127.0.0.1:8005` only so it is not reachable from the internet.

---

## 6. Useful commands on the server

```bash
cd /home/user/itsm_analytics

# View logs
docker compose logs -f

# Stop
docker compose down

# Stop and remove volumes (deletes DB and Redis data)
docker compose down -v

# Rebuild after code changes
docker compose up -d --build
```

---

## Quick checklist

| Step | Action |
|------|--------|
| 1 | Install Docker and Docker Compose on the Linux server |
| 2 | Copy or clone the project to the server |
| 3 | Create `.env` and set `GEMINI_API_KEY` if needed |
| 4 | Run `docker compose up -d --build` |
| 5 | Open port 3000 (or 80/443 if using reverse proxy) in the firewall |
| 6 | (Optional) Configure Nginx/Caddy + HTTPS for production |

After that, the app is available at **http://\<server-ip\>:3000** (or your configured domain).
