# ITSM Analytics – Deep Analysis from Scratch & Advanced Suggestions

This document gives a **from-scratch analysis** of the app and **concrete suggestions** for dashboard, enterprise style, and advanced features.

---

## Part 1: What the App Is (Architecture from Scratch)

### Purpose
ITSM Analytics is a **ticket analytics dashboard** for HPSM-style data (Incidents, Service Requests, Change Tasks). Users upload CSV/Excel, see KPIs and charts, and use AI chat over the same data.

### Tech Stack

| Layer | Technology | Role |
|-------|------------|------|
| **Frontend** | React 19, Vite 7 | SPA; components: Sidebar, DashboardHeader, UploadView, AnalyticsDashboard, ChatPanel, MonthDetailModal |
| **Charts** | Recharts | Bar, Pie, stacked workload, SLA, priority |
| **UI** | Framer Motion, Lucide icons | Animations, icons |
| **Backend** | FastAPI, Python 3.11 | REST API, file processing, AI |
| **Data** | Pandas | In-memory DataFrame per session; column normalization, date parsing |
| **AI** | Google Gemini (gemini-2.0-flash) | Executive summary, NL chat (code-gen + exec over df) |
| **Optional** | PostgreSQL, Redis | Persistent sessions, cached dataframe when env vars set |
| **Deploy** | Docker Compose | frontend (nginx), backend (uvicorn), postgres, redis |

### Data Flow (End-to-End)

1. **Upload**  
   User selects CSV/Excel and optional date range / data type (Incident | SR | Change).  
   → Backend saves temp file → `processor.process_file()` (encoding, delimiter, header detection, column mapping, date correction, `record_type`) → optional date filter → `get_chart_data()` + background `get_ai_insights()` → response with `chart_data`, `session_id`; dataframe stored in session (Redis/DB or in-memory).

2. **Dashboard**  
   Frontend shows KPIs (total tickets, SLA %, avg resolve), tabs: Overview, Workload Analysis, SLA Analysis. Record-type filter (All / Incident / SR / Change) when multiple types exist. Click month bar → Month Detail modal with full rows for that month (data source switch, record-type filter, search, sort, export CSV).

3. **Chat**  
   User asks in natural language. Backend builds prompt with schema + text-column hints, Gemini returns pandas code, backend `exec()` on session df → result as number, text, or table.

4. **Export & Reports**  
   - Export current view (filtered by date/session) → Excel/CSV.  
   - Monthly report → PDF / Word / HTML (KPIs, SLA by category, top services, breach list, AI summary).  
   - Slides → HTML or PPTX (one section per slide).

### API Surface (Backend)

| Method | Endpoint | Purpose |
|--------|----------|---------|
| POST | `/upload` | Upload file; optional date_from/to, data_type; returns chart_data, session_id |
| GET | `/session?session_id=` | Get session metadata + chart_data (restore saved view) |
| GET | `/sessions` | List saved sessions (sidebar) |
| DELETE | `/session?session_id=` | Delete one session |
| DELETE | `/sessions` | Delete all sessions |
| GET | `/ai-insights?session_id=` | Poll for AI executive summary |
| POST | `/chat` | NL query over session df; returns text or table |
| POST | `/export-current` | Export current view (session + date filter) as Excel/CSV |
| POST | `/compare` | Compare two files; returns chart_data_1, chart_data_2, comparison |
| GET | `/tickets_for_month?session_id=&month=` | Rows for one month (month detail modal) |
| GET | `/report?session_id=` | HTML report |
| GET | `/report/monthly?session_id=&format=pdf|docx|html` | Monthly report (PDF/Word/HTML) |
| GET | `/report/slides?session_id=&format=html|pptx` | Presentation (HTML/PPTX) |
| POST | `/export` | Export by re-uploading file (legacy) |

### Current Frontend Structure

- **App.jsx** – State, effects, upload/export/chat handlers; composes layout and components.
- **Sidebar** – Nav (Overview, Workload, SLA), saved sessions list, upload type.
- **DashboardHeader** – Date filters, Present, Excel/CSV, Current→Excel/CSV, Report, Monthly→PDF/Word, Presentation→HTML/PPTX, Upload New.
- **UploadView** – Empty state + file picker when no data.
- **AnalyticsDashboard** – Tabs, KPIs, workload chart (click → month modal), workload table, SLA pie, breach list, raw sample.
- **MonthDetailModal** – Month rows table; data source (IC/SR/CHG) switch, record-type filter, search, sort, export CSV, maximize/close.
- **ChatPanel** – Floating chat; history, suggestions, send; shows text or table.

---

## Part 2: Current Strengths & Gaps

### Strengths
- **Ingestion**: UTF-16, tab/CSV, multi-format dates, header/column detection, verification report.
- **Analytics**: Workload by service × month (with year), workload by 5 groups, SLA by category, breach list, priority by month, SAL cert count, record-type split.
- **UX**: Date range, record-type filter, presentation mode, month drill-down, data source switch in modal.
- **AI**: Executive summary (async), chat with schema + text-search hints, code over df.
- **Reporting**: Monthly report (PDF/Word/HTML), slides (HTML/PPTX), export current view.
- **Persistence**: Optional PostgreSQL + Redis; saved sessions, restore on load.

### Gaps / Risks
- **Scale**: Full CSV in memory → risk for 100k+ rows.
- **Security**: Chat uses `exec()` on Gemini-generated code; no auth.
- **UX**: No theme toggle, no keyboard shortcuts doc, no custom column mapping UI.
- **Analytics**: No period-over-period trend comparison UI; compare is two-file only.

---

## Part 3: Dashboard & Enterprise-Style Suggestions

### 3.1 Dashboard Look & Feel

| Suggestion | What to do | Benefit |
|------------|------------|--------|
| **KPI cards with trend** | Add small sparkline or “vs last period” (e.g. ↑5%) next to Total tickets, SLA %, Avg resolve. | Feels enterprise; quick read on direction. |
| **Executive summary strip** | Fixed strip at top: “Reporting period: Jan–Dec 2025 | 1,234 tickets | SLA 94% | 6 breaches”. | One-line context for leadership. |
| **Dashboard density toggle** | “Compact” vs “Comfortable” – reduce padding/font in charts and tables. | Fits more on one screen for power users. |
| **Branding slot** | Header area for logo + “ITSM Analytics” + optional “Environment” (e.g. Production / Demo). | Enterprise look; multi-env clarity. |
| **Time of last refresh** | Show “Data as of &lt;date&gt;” or “Last uploaded: &lt;filename&gt; at &lt;time&gt;” under KPIs. | Trust and audit. |

### 3.2 Enterprise-Style Features

| Feature | Description | Benefit |
|---------|-------------|--------|
| **Role-based views** | “Manager” (KPIs + charts only, no raw/export) vs “Analyst” (full). Optional “Viewer” (read-only). | Safe for different audiences. |
| **Optional auth** | API key or OAuth2; scope sessions by user/tenant. | Multi-team / SaaS ready. |
| **Audit log** | Log: upload (filename, user/session, time), report generated, export. Store in DB or append-only file. | Compliance and traceability. |
| **Configurable SLA targets** | Per category or global target (e.g. 95%); show “Met / Missed” vs target, not only raw %. | Aligns with policy. |
| **Custom branding** | Logo URL, primary color, product name from env or config. | White-label / enterprise. |

### 3.3 Navigation & Layout

| Suggestion | What to do | Benefit |
|------------|------------|--------|
| **Breadcrumbs** | e.g. “Dashboard > Workload Analysis > Dec 2025”. | Orientation in deep drill-down. |
| **Saved views / bookmarks** | Save “Q1 2025”, “SERVER only”, “Critical only” as named presets; load in one click. | Repeat analysis faster. |
| **Keyboard shortcuts** | Ctrl+U upload, Ctrl+E export, Esc close modals; show “?” for shortcut list. | Power users. |
| **Dark/light theme** | Toggle; persist in localStorage. | Accessibility and preference. |

---

## Part 4: Advanced Function Suggestions

### 4.1 Analytics & Reporting

| Feature | Description | Benefit |
|---------|-------------|--------|
| **Trend comparison (period vs period)** | “This period vs previous”: same length, e.g. Jan–Mar vs Apr–Jun; volume delta, SLA delta, priority mix; % change and small sparklines. | Before/after for reviews. |
| **Multi-file comparison (enhanced)** | Beyond current two-file compare: side-by-side KPIs + “Delta” column; optional common time axis. | Period-over-period in one view. |
| **Custom column mapping UI** | If auto-detect fails or user wants to override: map “Column A → ticket_id”, “Column B → created_at”, etc.; save as profile. | Any ITSM/Excel format. |
| **Scheduled / batch reports** | Cron or task queue: run on fixed files (or last uploaded); generate PDF/Excel; email or save to folder. | Recurring monthly/quarterly. |
| **Template report (customizable)** | Admin defines sections (e.g. KPIs, SLA table, breach list, AI summary); one-click “Generate report” from template. | Consistent deliverables. |

### 4.2 AI & Intelligence

| Feature | Description | Benefit |
|---------|-------------|--------|
| **Charts-first, AI async** | Return chart_data immediately; run AI summary in background; frontend polls or SSE. | Faster time-to-first-chart. |
| **AI drill-down** | Click category/priority/service → “Explain this segment” → Gemini summary for that slice only. | Deeper narratives. |
| **Suggested questions** | 5–10 clickable questions from schema + sample (“How many breaches by category?”, “Top 5 services?”). | Lower barrier to chat. |
| **Safer chat** | Replace raw `exec()` with sandbox (e.g. restricted pandas, no I/O, timeout) or Gemini “execute code” / safe DSL. | Security and multi-tenant. |
| **NL to filter** | “Show only P1 and SERVER” → apply filter to current view without re-upload. | Combines NL with filters. |

### 4.3 Scale & Performance

| Feature | Description | Benefit |
|---------|-------------|--------|
| **Chunked CSV processing** | Read in chunks (e.g. 10k rows); aggregate for charts; full data only for export or “Load all”. | 100k–500k+ rows without OOM. |
| **Export current view (no re-upload)** | Already present; ensure all filters (date, record type, future saved view) apply. | Export = what you see. |
| **Cache by file hash** | If same file uploaded again within TTL, return cached chart_data (optional). | Fewer duplicate runs. |
| **Lazy load / code-split** | React.lazy for Recharts and heavy dashboard sections; smaller initial bundle. | Faster first load. |

### 4.4 Integrations & Automation

| Feature | Description | Benefit |
|---------|-------------|--------|
| **REST API for external tools** | Documented: POST /upload, GET /datasets, POST /analyze?dataset=id. | Scripts, CI, other apps. |
| **Webhook on completion** | Optional URL called when processing finishes (e.g. Slack, Teams). | Notify others. |
| **Import from URL** | “Analyze from URL”: fetch CSV/Excel from link (with auth if needed). | No manual download. |
| **Connectors (ServiceNow / Jira / HPSM)** | Read from ITSM API; normalize to app’s schema; optional sync. | Direct integration. |

### 4.5 Security & Compliance

| Feature | Description | Benefit |
|---------|-------------|--------|
| **No exec() for chat** | Sandbox or safe DSL / “execute code” API. | Removes arbitrary code execution. |
| **Input validation** | Upload: size, type, row limit; chat: length, blocklisted patterns. | Abuse and prompt injection. |
| **PII handling** | Option to redact or hash PII columns before storage or AI. | Privacy and compliance. |

---

## Part 5: Prioritized Recommendation List

### Tier 1 – Quick wins (1–2 weeks)

| # | Feature | Why |
|---|---------|-----|
| 1 | **Charts-first, AI async** | Return chart_data immediately; run AI in background; poll or SSE. Big UX win. |
| 2 | **Executive summary strip** | One line under header: period, total tickets, SLA %, breaches. Enterprise feel. |
| 3 | **KPI trend (vs previous)** | e.g. “Total tickets: 1,234 (↑5% vs prior period)” if compare data exists. |
| 4 | **Keyboard shortcuts** | Ctrl+U, Ctrl+E, Esc; “?” overlay with list. |
| 5 | **Dark/light theme toggle** | Single theme switch; persist in localStorage. |

### Tier 2 – High impact (2–4 weeks)

| # | Feature | Why |
|---|---------|-----|
| 6 | **Trend comparison (period vs period)** | “This period vs previous” with % deltas and sparklines. |
| 7 | **Saved views / bookmarks** | Save filter presets (date + record type + future filters); load by name. |
| 8 | **Custom column mapping UI** | When auto-detect fails, user maps columns; save as profile. |
| 9 | **Safer chat (sandbox or no exec)** | Required for multi-tenant or untrusted input. |
| 10 | **Role-based views** | Manager vs Analyst (hide raw/export for Manager). |

### Tier 3 – Scale & enterprise (1–2 months)

| # | Feature | Why |
|---|---------|-----|
| 11 | **Chunked CSV processing** | Support 100k+ rows without OOM. |
| 12 | **Optional auth (API key or OAuth2)** | Multi-team and SaaS. |
| 13 | **Audit log** | Upload, report, export events. |
| 14 | **Scheduled / batch reports** | Recurring PDF/Excel to email or folder. |
| 15 | **Connectors (ServiceNow / Jira / HPSM)** | Direct pull from ITSM tools. |

### Tier 4 – Polish & differentiation

| # | Feature | Why |
|---|---------|-----|
| 16 | **AI drill-down** | Click segment → “Explain this” summary. |
| 17 | **Configurable SLA targets** | Per category or global; show Met/Missed vs target. |
| 18 | **Import from URL** | Analyze from URL. |
| 19 | **Webhook on completion** | Notify external systems. |
| 20 | **Custom branding (logo, color, name)** | White-label. |

---

## Part 6: One-Page Summary

| Area | Top 3 suggestions |
|------|-------------------|
| **Dashboard** | Executive summary strip; KPI trend vs prior period; density toggle. |
| **Enterprise style** | Role-based views; optional auth; audit log. |
| **Advanced analytics** | Trend comparison (period vs period); saved views; custom column mapping. |
| **AI** | Charts-first + AI async; safer chat (no exec); suggested questions. |
| **Scale** | Chunked CSV; cache by file hash; lazy load frontend. |
| **Integrations** | REST API; connectors (ServiceNow/Jira/HPSM); webhook. |

The app is already strong on ingestion, HPSM-style analytics, reporting (PDF/Word/PPTX), and session persistence. The highest-impact next steps are **charts-first + AI async**, **trend comparison**, **saved views**, **safer chat**, and **optional auth + audit log** for an enterprise-ready product.

---

**See also:** `ADVANCED_FEATURES_AND_PRESENTATION_IMPROVEMENTS.md` for **additional advanced features** (forecasting, anomaly detection, benchmarking, comparison report, executive one-pager, copy chart as image, tenant/workspace, localization, etc.) and a **concrete plan to improve PDF and presentation exports** with **charts, graphs, and full data** (matplotlib chart images, full breach list option, appendix, consistent styling).
