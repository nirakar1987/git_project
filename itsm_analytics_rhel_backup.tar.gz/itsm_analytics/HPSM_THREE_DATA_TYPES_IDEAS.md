# HPSM: Incident, Service Request & Change Task – How to Visualize All 3 in This App

This document suggests how to add or improve the app so it can handle **three HPSM data types** (Incident, Service Request, Change Task) even though each export has **different columns**.

---

## 1. The Challenge

| Data Type        | Typical HPSM Columns (examples) | Overlap with others |
|------------------|----------------------------------|----------------------|
| **Incident**     | Incident Number, Open Time, Closed Time, Status, Priority, Impact, Urgency, Assignment Group, Summary, SLA, etc. | ID, dates, status, priority, group, SLA |
| **Service Request** | Request ID, Submit Date, Delivery Date, Status, Requested For, Catalog Item, Support Group, Fulfillment Group, etc. | ID, dates, status, group-like |
| **Change Task**  | Change ID, Schedule Start/End, Actual Start/End, Status, Risk, Change Type, Assignment Group, Implementation Status, etc. | ID, dates, status, group |

- **Same idea, different names**: “Open Time” (Incident) ≈ “Submit Date” (SR) ≈ “Schedule Start” (Change) → all can map to **created_at**.
- **Same idea, different names**: “Assignment Group” / “Support Group” / “Fulfillment Group” → **category** (service/queue).
- **Type-specific columns**: Impact/Urgency (Incident), Catalog Item (SR), Risk/Change Type (Change) – we can keep these as **extra columns** and use them in type-specific views.

---

## 2. Recommended Approach: One Unified Schema + Record Type

### 2.1 Keep one “normalized” schema

The app already maps many column names to a **common set**:

- `ticket_id`, `status`, `priority`, `category`, `summary`, `created_at`, `resolved_at`, `sla_status`

**Idea:** Extend the **keyword mapping** in `processor.py` so that **all three** HPSM export types map into this same set:

- **Incident:** Already fits (Open Time → created_at, Assignment Group → category, etc.).
- **Service Request:** Add mappings, e.g.  
  - “Submit Date” / “Request Date” / “Creation Date” → `created_at`  
  - “Delivery Date” / “Actual Finish” / “Completion Date” → `resolved_at`  
  - “Support Group” / “Fulfillment Group” / “Assignment Group” → `category`  
  - “Request ID” / “Request Number” → `ticket_id`
- **Change Task:** Add mappings, e.g.  
  - “Schedule Start” / “Planned Start” / “Creation Date” → `created_at`  
  - “Actual End” / “Completion Date” / “Closed Date” → `resolved_at`  
  - “Assignment Group” / “Implementing Group” → `category`  
  - “Change ID” / “Change Number” → `ticket_id`

Then **every** record has the same core fields for existing charts (workload by month/category, SLA, priority, etc.).

### 2.2 Add a “record type” (Incident / Service Request / Change)

- **Option A – User selects type at upload:**  
  In the upload UI, add a dropdown: **“Data type: Incident | Service Request | Change Task”**.  
  Backend gets `data_type` and adds a column `record_type` to the dataframe (e.g. `"Incident"`, `"Service Request"`, `"Change Task"`).  
  No need to auto-detect; user knows their file.

- **Option B – Auto-detect from columns:**  
  If the file has columns like “Impact”, “Urgency”, “Incident Number” → `record_type = "Incident"`.  
  If “Catalog Item”, “Requested For”, “Request ID” → `"Service Request"`.  
  If “Risk”, “Change Type”, “Schedule Start” → `"Change Task"`.  
  Else → `"Unknown"` or “Mixed” if you later support combined files.

- **Option C – Combined file with a type column:**  
  Some HPSM exports have a column like “Type” or “Ticket Type” with values Incident/SR/Change.  
  Map that column to `record_type` and keep one combined dataframe.

Recommendation: **Start with Option A** (user selects type) so column mapping is clear; add **Option B or C** later if you want “one file with mixed types” or “detect from filename/columns”.

---

## 3. Visualization Ideas (Using Existing + New Charts)

All current charts (Monthly Workload, SLA, Priority, Workload table, etc.) are **already** built from the normalized fields. Once every record has `record_type`, you can:

### 3.1 Filter by data type (simplest)

- Add a **global filter**: “Show: All | Incident | Service Request | Change Task”.
- Backend: when building `chart_data`, optionally filter:  
  `df = df[df['record_type'] == selected_type]` (or keep all and filter in frontend if you send `record_type` with each row).
- **Better:** Filter on backend so KPIs, workload, SLA, breach list, and exports all respect the chosen type. Then:
  - **Incident** view: same charts, only incident data.
  - **Service Request** view: same charts, only SR data.
  - **Change Task** view: same charts, only change data.
- **“All”**: use full dataset (or combined upload). Optionally show a small **stacked bar or pie** “Volume by type” (Incident vs SR vs Change) so users see the mix.

### 3.2 Compare types side by side

- **KPI row:** One row of KPIs for “All” and one row (or cards) per type:  
  e.g. **Incident:** total, SLA %, avg resolve time | **Service Request:** total, SLA %, avg fulfillment time | **Change:** total, SLA %, avg implementation time.
- **Same chart, split by type:**  
  - **Monthly Workload:** grouped bar (e.g. each month has 3 bars: Incident, SR, Change) **or** stacked bar (stack = Incident + SR + Change) with legend “Incident / Service Request / Change”.
  - **SLA:** one pie “All” or three small pies “Incident / SR / Change”.
- **Table:** Workload table (Service × Month) with a first column or filter “Type” so users can see Incident vs SR vs Change per service/month.

### 3.3 Type-specific visuals (optional, high value)

Use **extra columns** that only exist for that type:

| Type            | Extra columns (examples)     | Visualization idea |
|-----------------|-----------------------------|---------------------|
| **Incident**    | Impact, Urgency             | Pie or bar: “By Impact”, “By Urgency”; or heatmap Impact × Urgency. |
| **Service Request** | Catalog Item, Requested For | Bar: “Top catalog items”; table: SRs by catalog item × month. |
| **Change Task** | Risk, Change Type           | Pie: “By Risk” (Low/Medium/High); bar: “By Change Type”; optional “Success vs Rollback” if you have status. |

These can be **extra sections** on the dashboard when “Data type” filter is set to that type (or in a “Detail by type” tab).

### 3.4 Single combined upload (3 files → 1 view)

- **Upload flow:** “Upload Incident file”, “Upload Service Request file”, “Upload Change Task file” (or 3 file inputs).
- Backend: process each file with the right column mapping (or same mapping + user-selected type per file), add `record_type` to each, **concatenate** into one dataframe.
- Store one `chart_data` that includes a **by_type** breakdown (e.g. `workload_by_type`, `sla_by_type`) and optional `record_type` on each row for filtering.
- Dashboard: “Volume by type” chart; filter “All | Incident | SR | Change”; rest of charts respect filter.

---

## 4. Implementation Outline (Backend)

1. **Extend keyword mapping** in `processor.py`:
   - Add SR- and Change-specific header keywords for `created_at`, `resolved_at`, `category`, `ticket_id` (see table in 2.1).
   - Keep existing Incident-oriented keywords; avoid breaking current files.

2. **Add `record_type` to the dataframe:**
   - If upload includes `data_type` (Incident / Service Request / Change Task), add column:  
     `df['record_type'] = data_type`.
   - If you implement “combined upload”, set `record_type` per file before concatenation.

3. **Optional: keep type-specific columns:**
   - After normalizing to the common schema, **do not drop** columns that didn’t map (e.g. “Impact”, “Catalog Item”, “Risk”). Keep them in `df` so:
     - Month-detail “All tickets” table and Excel export show them.
     - Later you can add type-specific charts (Impact, Catalog Item, Risk) when filter = that type.

4. **Chart data by type:**
   - In `get_chart_data()` (or a helper), optionally accept `filter_record_type` (All | Incident | Service Request | Change Task).
   - If not “All”, filter: `df = df[df['record_type'] == filter_record_type]` before building workload, SLA, priority, etc.
   - Add to `chart_data`:
     - `record_type_counts`: e.g. `{ "Incident": 1200, "Service Request": 800, "Change Task": 150 }` for “Volume by type” pie/bar.
     - Optionally: `workload_by_type` (month × type counts) for stacked/grouped “Monthly volume by type”.

5. **API:**
   - Upload: add optional form/query param `data_type` (Incident | Service Request | Change Task).
   - Session/load: if you store `data_type` or combined data with `record_type`, return it so the frontend can show the filter and type-specific sections.

---

## 5. Implementation Outline (Frontend)

1. **Upload:**
   - Add dropdown: “Data type: Incident / Service Request / Change Task” (or “Auto” if you add detection). Send `data_type` with the file.

2. **Dashboard:**
   - Add filter: “Data type: All | Incident | Service Request | Change Task” (or tabs). On change, either:
     - Reload chart data with `filter_record_type` (backend filter), or  
     - If backend sends full data with `record_type`, filter in frontend (heavier).
   - Add a small **“Volume by type”** chart (pie or bar) when data has multiple record types.

3. **Existing charts:**
   - No change to chart structure; they already use `workload`, `sla`, `priority`, etc. They just reflect the filtered dataset (Incident-only, SR-only, Change-only, or All).

4. **Month-detail / Export:**
   - “All tickets” table and Excel export already show all columns; they will automatically show type-specific columns (Impact, Catalog Item, Risk, etc.) if you keep them in the dataframe. Add a column `record_type` in the table and export when data is combined.

---

## 6. Summary Table

| Goal                         | Approach |
|-----------------------------|----------|
| Same app for all 3 types    | One normalized schema; extend column mapping for SR and Change. |
| Different columns per type  | Map common fields (id, dates, status, category, SLA); add `record_type`; keep extra columns for type-specific views. |
| Visualize by type           | Filter “All / Incident / SR / Change”; optional “Volume by type” and “Monthly by type”; same KPIs and charts per type. |
| Type-specific insights      | When filter = one type, show extra charts (Impact, Catalog Item, Risk) using reserved columns. |
| Combined view               | Optional: upload 3 files → one combined dataset with `record_type`; filter and compare. |

If you tell me whether you prefer **“one file + user selects type”** or **“three files combined”** first, I can outline the exact code changes (file-by-file) next.
