# Dashboard Continuous Animation – Suggestions (for approval)

Below are suggestions to add **continuous / recurring** animations so all widgets feel animated. No widget content or behavior will change—only visual motion. Animations are kept **subtle** so the dashboard stays professional.

---

## 1. **Slicers row** (Monthly Slicer, Category, Priority, Clear filters)

| Suggestion | Description |
|------------|-------------|
| **Border glow pulse** | Very slow CSS keyframe (e.g. 3–4 s) on the slicer container: `box-shadow` or `border-color` gently fades in/out (e.g. accent 20% → 40% opacity). |
| **Active month button** | Selected month/category/priority: very soft pulse on background (e.g. opacity 0.15 → 0.25 over 2 s, repeat). Unselected buttons: no loop. |

---

## 2. **KPI cards** (Total Tickets, SLA Met, Breached, Avg Resolution)

| Suggestion | Description |
|------------|-------------|
| **Icon subtle pulse** | On the icon wrapper (`.kpi-icon`): very slow scale loop, e.g. `scale(1)` → `scale(1.05)` → `scale(1)` over ~2 s, repeat. |
| **Card border glow** | Same idea as slicers: very slow pulse on `box-shadow` or border (e.g. 4 s cycle) so the card feels “alive” without distracting. |
| **Apply to** | Dashboard tab KPIs + Overview tab KPIs (same treatment). |

---

## 3. **Chart cards** (all Bar and Pie chart widgets)

| Suggestion | Description |
|------------|-------------|
| **Card border glow** | One shared CSS class (e.g. `.chart-card-animated`) with a slow keyframe on `box-shadow` or border (3–4 s cycle). Apply to: SLA Status, Tickets by Month, Priority, Month Breakdown, Top Services, Approval Status, and same card types in Overview / Workload / SLA tabs. |
| **Optional: donut slow rotation** | For Pie/donut charts only: wrap the chart in a `motion.div` with `animate={{ rotate: 360 }}`, `transition={{ repeat: Infinity, duration: 45–60, ease: 'linear' }}`. Very slow spin for a “live” feel. **Optional**—skip if you find it distracting. |

---

## 4. **Top 5 Categories (leaderboard + progress bars)**

| Suggestion | Description |
|------------|-------------|
| **Progress bar shimmer** | You already have a shimmer keyframe in CSS. Use it on the progress fill (e.g. a thin overlay) with a long duration (e.g. 3 s) so the fill has a slow, subtle shine that repeats. |
| **Row hover** | Already has Framer `whileHover`. No change. |

---

## 5. **Tables** (Detailed Service Workload, Raw Data, SLA tables, etc.)

| Suggestion | Description |
|------------|-------------|
| **Staggered row entrance** | On first load / when data appears: each row fades in with a small delay (e.g. 30–50 ms per row) so the table “fills in” smoothly. One-time, not continuous. |
| **Optional: very subtle row pulse** | One optional idea: alternating rows get a very slow background opacity pulse (e.g. 0.02 → 0.05) over 4–5 s. **Optional**—can be skipped to avoid clutter. |

---

## 6. **Overview tab – specific widgets**

| Widget | Suggestion |
|--------|------------|
| **Executive Decision Support card** | Same card border glow as chart cards. Optional: very slow pulse on the left accent border. |
| **Bottleneck / Top Service Risk inner boxes** | Very subtle border or shadow pulse (3–4 s) so they feel part of the “live” dashboard. |
| **Service Pulse (status dots)** | Status dot: slow pulse on `box-shadow` or scale (e.g. 1 → 1.1 → 1 over 2 s) so the “pulse” name is reflected. |
| **High-Level Workload Trend (bar chart)** | Wrap card in same `.chart-card-animated` border glow; keep chart as-is. |

---

## 7. **Workload tab**

| Widget | Suggestion |
|--------|------------|
| **Monthly Workload (stacked bar)** | Same chart card border glow; ensure Recharts `animationDuration` is set for initial draw (e.g. 1.5 s) if not already. |
| **Priority Breakdown bar chart** | Same card glow. |
| **Detailed Service Workload table** | Same table suggestions as in §5. |

---

## 8. **SLA tab**

| Widget | Suggestion |
|--------|------------|
| **SLA Distribution pie** | Same chart card glow; optional donut slow rotation as in §3. |
| **SLA Risk Radar / Compliance cards** | Same subtle border or shadow pulse as Overview insight cards. |
| **SLA tables / Breach Watchlist** | Same table entrance and optional row pulse as in §5. |

---

## 9. **Global (optional)**

| Suggestion | Description |
|------------|-------------|
| **Page background** | Very slow gradient position animation (e.g. `background-position` shift over 20–30 s, repeat). Gives a gentle “ambient” motion. **Optional**—can be omitted. |

---

## Summary

- **Apply everywhere (recommended):**  
  - Card border glow (chart cards + KPI cards + slicer row).  
  - KPI icon subtle pulse.  
  - Active slicer button soft pulse.  
  - Progress bar shimmer on Top 5 Categories.

- **Apply where you want:**  
  - Donut slow rotation (Pie charts).  
  - Table staggered row entrance + optional row pulse.  
  - Service Pulse dot animation.  
  - Page background gradient motion.

- **No changes to:**  
  - Data, labels, or behavior of any widget.  
  - Chart types or colors.  
  - Existing one-time entrance animations (they stay as-is).

If you approve this plan (or a subset), say which sections you want (e.g. “all recommended” or “only KPIs and chart cards”), and implementation can follow.
