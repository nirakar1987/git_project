import React from 'react';
import { Upload } from 'lucide-react';
import { motion } from 'framer-motion';

export default function UploadView({
    error,
    uploadDataType,
    setUploadDataType,
    onFileUpload,
    compareFiles,
    setCompareFiles,
    onCompareFiles
}) {
    // Helper to trigger the hidden file input (which is in Header or we can have a local one)
    // Actually the design had a button calling document.getElementById('fileInput').
    // To be clean, we should have a local input or pass a ref. 
    // I will add a local input here for the "Choose file" button in the big card.

    return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} style={{ marginTop: '24px' }}>
            {error && <div style={{ color: '#fb7185', padding: '20px', background: 'rgba(251, 113, 133, 0.1)', borderRadius: '8px', marginBottom: '24px' }}>{error}</div>}

            {/* Local input for the big button */}
            <input id="uploadViewInput" type="file" hidden onChange={onFileUpload} accept=".csv,.xlsx,.xls" />

            <div className="chart-card" style={{ marginBottom: '24px', textAlign: 'center', padding: '48px 24px' }}>
                <Upload size={56} color="var(--accent)" style={{ marginBottom: '16px' }} />
                <h2 style={{ fontSize: '20px', marginBottom: '8px' }}>Upload your data</h2>
                <p style={{ color: 'var(--text-muted)', marginBottom: '24px' }}>CSV or Excel (HPSM / SNOW) to see KPIs, charts and AI insights. Data is saved when running with Docker (PostgreSQL + Redis).</p>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap', marginBottom: '16px', justifyContent: 'center' }}>
                    <label style={{ fontSize: '13px', color: 'var(--text-muted)' }}>Data type:</label>
                    <select value={uploadDataType} onChange={(e) => setUploadDataType(e.target.value)} style={{ padding: '8px 12px', borderRadius: '8px', border: '1px solid var(--border)', background: 'var(--card)', color: 'inherit', fontSize: '13px' }}>
                        <option value="Auto">Auto (detect from file)</option>
                        <option value="Incident">Incident</option>
                        <option value="Service Request">Service Request</option>
                        <option value="Change Task">Change Task</option>
                    </select>
                </div>
                <button type="button" className="header-btn" onClick={() => document.getElementById('uploadViewInput').click()} style={{ display: 'inline-flex', alignItems: 'center', gap: '8px' }}>
                    <Upload size={20} /> Choose file
                </button>
            </div>

            <div className="chart-card" style={{ maxWidth: '560px', margin: '0 auto' }}>
                <h3 style={{ fontSize: '16px', marginBottom: '12px' }}>Compare two files</h3>
                <p style={{ color: 'var(--text-muted)', fontSize: '13px', marginBottom: '12px' }}>Upload two CSV/Excel files to see ticket and SLA deltas.</p>
                <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', alignItems: 'center' }}>
                    <label className="header-btn header-btn-ghost" style={{ cursor: 'pointer', margin: 0 }}>
                        {compareFiles.file1 ? compareFiles.file1.name : 'File 1'}
                        <input type="file" hidden accept=".csv,.xlsx,.xls" onChange={(e) => setCompareFiles((prev) => ({ ...prev, file1: e.target.files[0] || null }))} />
                    </label>
                    <label className="header-btn header-btn-ghost" style={{ cursor: 'pointer', margin: 0 }}>
                        {compareFiles.file2 ? compareFiles.file2.name : 'File 2'}
                        <input type="file" hidden accept=".csv,.xlsx,.xls" onChange={(e) => setCompareFiles((prev) => ({ ...prev, file2: e.target.files[0] || null }))} />
                    </label>
                    <button type="button" className="header-btn" onClick={onCompareFiles} disabled={!compareFiles.file1 || !compareFiles.file2}>Compare</button>
                </div>
            </div>
        </motion.div>
    );
}
