import React from 'react';
import { Upload, X, Presentation, Download } from 'lucide-react';

export default function DashboardHeader({
    data,
    uploadedFile,
    dateFrom, setDateFrom,
    dateTo, setDateTo,
    compareFrom, setCompareFrom,
    compareTo, setCompareTo,
    applyingFilter,
    onApplyDateFilter,
    presentationMode,
    setPresentationMode,
    exporting,
    onExportFile,
    onExportCurrentView,
    onOpenReport,
    onMonthlyReport,
    onPivotReport,
    onFullReport,
    onGenerateSlides,
    uploadDataType,
    setUploadDataType,
    onFileUpload
}) {
    return (
        <header
            className="dashboard-header-sticky"
            style={{
                position: 'sticky',
                top: 0,
                zIndex: 100,
                background: 'linear-gradient(180deg, var(--background) 0%, var(--background-subtle) 100%)',
                borderBottom: '1px solid var(--border)',
                marginBottom: '12px',
                paddingBottom: '12px',
                backdropFilter: 'blur(8px)',
            }}
        >
            {/* Hidden Input for Upload */}
            <input id="headerFileInput" type="file" hidden onChange={onFileUpload} accept=".csv,.xlsx,.xls" />

            {/* Row 1: Title + filters at top */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '10px', marginBottom: data ? '10px' : 0 }}>
                <div>
                    <h1 style={{ fontSize: '22px', margin: 0, marginBottom: '2px' }}>Analytics Overview</h1>
                    <p style={{ margin: 0, fontSize: '12px', color: 'var(--text-muted)' }}>
                        {data?.filename ? `Data Source: ${data.filename}` : 'Upload CSV or Excel to see analytics'}
                    </p>
                </div>
                {data ? (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '12px' }}>
                            <label style={{ color: 'var(--text-muted)' }}>From</label>
                            <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} style={{ padding: '4px 6px', borderRadius: '4px', border: '1px solid var(--border)', background: 'var(--card)', color: 'inherit', fontSize: '12px' }} />
                            <label style={{ color: 'var(--text-muted)' }}>To</label>
                            <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} style={{ padding: '4px 6px', borderRadius: '4px', border: '1px solid var(--border)', background: 'var(--card)', color: 'inherit', fontSize: '12px' }} />
                        </span>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '12px', color: 'var(--text-muted)' }}>
                            Compare:
                            <input type="date" value={compareFrom} onChange={(e) => setCompareFrom(e.target.value)} style={{ padding: '4px 6px', borderRadius: '4px', border: '1px solid var(--border)', background: 'var(--card)', color: 'inherit', fontSize: '12px' }} />
                            <input type="date" value={compareTo} onChange={(e) => setCompareTo(e.target.value)} style={{ padding: '4px 6px', borderRadius: '4px', border: '1px solid var(--border)', background: 'var(--card)', color: 'inherit', fontSize: '12px' }} />
                        </span>
                        <button type="button" disabled={applyingFilter} className="header-btn header-btn-ghost" style={{ padding: '4px 10px', fontSize: '12px' }} onClick={onApplyDateFilter}>{applyingFilter ? 'Applying…' : 'Apply'}</button>
                        <button onClick={() => setPresentationMode(!presentationMode)} className="header-btn" style={{ padding: '4px 10px', fontSize: '12px' }} title="Presentation mode">
                            {presentationMode ? <X size={16} /> : <Presentation size={16} />}
                            {presentationMode ? ' Exit' : ' Present'}
                        </button>
                        <label style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Data type:</label>
                        <select value={uploadDataType} onChange={(e) => setUploadDataType(e.target.value)} style={{ padding: '4px 8px', borderRadius: '4px', border: '1px solid var(--border)', background: 'var(--card)', color: 'inherit', fontSize: '11px' }}>
                            <option value="Auto">Auto</option>
                            <option value="Incident">Incident</option>
                            <option value="Service Request">Service Request</option>
                            <option value="Change Task">Change Task</option>
                        </select>
                        <button type="button" className="header-btn" style={{ padding: '4px 10px', fontSize: '12px' }} onClick={() => document.getElementById('headerFileInput').click()}>Upload New</button>
                    </div>
                ) : (
                    <button type="button" className="header-btn" onClick={() => document.getElementById('headerFileInput').click()} style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '6px 12px' }}>
                        <Upload size={18} /> Upload file
                    </button>
                )}
            </div>

            {/* Row 2: Reports & Export Dropdown */}
            {data && (
                <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '8px' }}>
                    <div className="dropdown" style={{ position: 'relative', display: 'inline-block' }}>
                        <button className="header-btn" style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '6px 12px' }}>
                            <Download size={16} /> Export Reports <span style={{ fontSize: '10px' }}>▼</span>
                        </button>
                        <div className="dropdown-content">
                            <div className="dropdown-section">Data Export</div>
                            <button disabled={exporting} onClick={() => onExportFile('xlsx')}>Full Dataset (Excel)</button>
                            <button disabled={exporting} onClick={() => onExportFile('csv')}>Full Dataset (CSV)</button>
                            <button disabled={exporting} onClick={() => onExportCurrentView('xlsx')}>Current View (Excel)</button>
                            <button disabled={exporting} onClick={() => onExportCurrentView('csv')}>Current View (CSV)</button>

                            <div className="dropdown-section">Monthly Reports</div>
                            <button disabled={exporting} onClick={() => onFullReport()}>All-in-One Report (PDF) ★</button>
                            <button disabled={exporting} onClick={() => onMonthlyReport('pdf')}>Summary Report (PDF)</button>
                            <button disabled={exporting} onClick={() => onMonthlyReport('docx')}>Summary Report (Word)</button>
                            <button disabled={exporting} onClick={onPivotReport}>Detailed Pivot Table (PDF)</button>

                            <div className="dropdown-section">Presentation</div>
                            <button disabled={exporting} onClick={() => onGenerateSlides('html')}>Executive Deck (HTML)</button>
                            <button disabled={exporting} onClick={() => onGenerateSlides('pptx')}>Executive Deck (PPTX)</button>
                        </div>
                    </div>
                </div>
            )}
        </header>
    );
}
