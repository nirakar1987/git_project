import React, { useRef, useEffect } from 'react';
import { Sparkles, BrainCircuit, Minus, Trash2, Send, Copy } from 'lucide-react';
import { motion } from 'framer-motion';

export default function ChatPanel({
    data,
    isChatMinimized,
    setIsChatMinimized,
    chatMessages,
    setChatMessages,
    chatQuery,
    setChatQuery,
    chatLoading,
    onChatSubmit,
    chatBodyRef
}) {
    if (!data) return null;

    return (
        <div className={`floating-chat-container chat-panel-glass ${isChatMinimized ? 'minimized' : ''}`} onClick={isChatMinimized ? () => setIsChatMinimized(false) : undefined}>
            {isChatMinimized ? (
                <div className="chat-bubble-toggle">
                    <Sparkles size={28} strokeWidth={2} />
                    <span className="chat-bubble-badge">AI</span>
                </div>
            ) : (
                <>
                    <div className="chat-header-modern">
                        <div className="chat-header-left">
                            <div className="chat-avatar">
                                <BrainCircuit size={22} strokeWidth={2} />
                            </div>
                            <div>
                                <span className="chat-title">Data AI Assistant</span>
                                <span className="chat-subtitle">Ask anything about your data</span>
                            </div>
                        </div>
                        <div className="chat-header-actions">
                            <button type="button" className="chat-icon-btn" onClick={() => setIsChatMinimized(true)} title="Minimize">
                                <Minus size={18} />
                            </button>
                            <button type="button" className="chat-icon-btn" onClick={() => { setChatMessages([]); setChatQuery(''); }} title="Clear conversation">
                                <Trash2 size={18} />
                            </button>
                        </div>
                    </div>

                    <div className="chat-body-modern" ref={chatBodyRef}>
                        {chatMessages.length === 0 && !chatLoading && (
                            <div className="chat-welcome">
                                <div className="chat-welcome-icon"><Sparkles size={40} strokeWidth={1.5} /></div>
                                <p className="chat-welcome-title">Ask anything about your data</p>
                                <p className="chat-welcome-desc">Counts, breakdowns, text search (certificate, renew), or raw-data questions.</p>
                                <div className="chat-suggestions">
                                    {(data?.chart_data?.suggested_questions || ['How many tickets in total?', 'Top 5 categories', 'SLA met %']).map(hint => (
                                        <button key={hint} type="button" className="chat-suggestion-chip" onClick={() => setChatQuery(hint)}>
                                            {hint}
                                        </button>
                                    ))}
                                </div>
                                <p className="chat-hint">Press Enter to send</p>
                            </div>
                        )}

                        {chatMessages.map((msg, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, y: 8 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ duration: 0.2 }}
                                className={`chat-message-row ${msg.role}`}
                            >
                                {msg.role === 'user' ? (
                                    <div className="chat-bubble user-bubble">
                                        <span>{msg.content}</span>
                                    </div>
                                ) : (
                                    <div className="chat-bubble assistant-bubble">
                                        <div className="assistant-bubble-header">
                                            <BrainCircuit size={14} className="assistant-icon" />
                                            <span>Assistant</span>
                                            {msg.result?.type === 'text' && (
                                                <button
                                                    type="button"
                                                    className="chat-copy-btn"
                                                    onClick={() => navigator.clipboard?.writeText(msg.result.data)}
                                                    title="Copy"
                                                >
                                                    <Copy size={12} />
                                                </button>
                                            )}
                                        </div>
                                        {msg.result?.type === 'text' ? (
                                            <div className="assistant-text">{msg.result.data}</div>
                                        ) : (
                                            <div className="assistant-table-wrap">
                                                <span className="assistant-table-label">Found {msg.result?.count ?? 0} results</span>
                                                <div className="chat-data-table-wrap">
                                                    <table className="chat-data-table">
                                                        <thead>
                                                            <tr>
                                                                {(msg.result?.columns || []).map(col => <th key={col}>{col}</th>)}
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            {(msg.result?.data || []).map((row, i) => (
                                                                <tr key={i}>
                                                                    {(msg.result?.columns || []).map(col => <td key={col}>{String(row[col] ?? '')}</td>)}
                                                                </tr>
                                                            ))}
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                )}
                            </motion.div>
                        ))}

                        {chatLoading && (
                            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="chat-message-row assistant">
                                <div className="chat-bubble assistant-bubble typing-bubble">
                                    <div className="typing-dots">
                                        <span /><span /><span />
                                    </div>
                                    <span className="typing-label">Analyzing your data...</span>
                                </div>
                            </motion.div>
                        )}
                    </div>

                    <div className="chat-input-modern">
                        <form onSubmit={onChatSubmit} className="chat-form">
                            <input
                                type="text"
                                placeholder="Ask anything about your data..."
                                value={chatQuery}
                                onChange={(e) => setChatQuery(e.target.value)}
                                className="chat-input-field"
                                autoFocus
                                disabled={chatLoading}
                            />
                            <button type="submit" disabled={chatLoading || !chatQuery.trim()} className="chat-send-btn" title="Send">
                                <Send size={18} strokeWidth={2} />
                            </button>
                        </form>
                        <p className="chat-input-hint">Powered by your uploaded dataset</p>
                    </div>
                </>
            )}
        </div>
    );
}
