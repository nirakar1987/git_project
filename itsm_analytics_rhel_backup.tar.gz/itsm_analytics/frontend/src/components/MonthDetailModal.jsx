import React, { useEffect } from 'react';
import { BarChart3, Minimize2, Maximize2, X, FileSpreadsheet, Search, Download } from 'lucide-react';
import { motion } from 'framer-motion';

export default function MonthDetailModal({
    monthDetailModal,
    setMonthDetailModal,
    monthDetailTickets,
    monthDetailMaximized,
    setMonthDetailMaximized,
    monthDetailSearch,
    setMonthDetailSearch,
    monthDetailSort,
    setMonthDetailSort
}) {
    if (!monthDetailModal) return null;

    const cols = monthDetailTickets.columns || [];
    const rawRows = monthDetailTickets.rows || [];
    const searchLower = (monthDetailSearch || '').trim().toLowerCase();

    // Derived state for filtered/sorted rows
    const filteredRows = searchLower
        ? rawRows.filter((row) => cols.some((c) => String(row[c] ?? '').toLowerCase().includes(searchLower)))
        : rawRows;

    const sortedRows = monthDetailSort.col && cols.includes(monthDetailSort.col)
        ? [...filteredRows].sort((a, b) => {
            const va = String(a[monthDetailSort.col] ?? '');
            const vb = String(b[monthDetailSort.col] ?? '');
            const cmp = va.localeCompare(vb, undefined, { numeric: true });
            return monthDetailSort.dir === 'asc' ? cmp : -cmp;
        })
        : filteredRows;

    const exportMonthCSV = () => {
        if (cols.length === 0 || sortedRows.length === 0) return;
        const BOM = '\uFEFF';
        const header = cols.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',');
        const lines = sortedRows.map((row) => cols.map((c) => `"${String(row[c] ?? '').replace(/"/g, '""')}"`).join(','));
        const csv = BOM + [header, ...lines].join('\r\n');
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `${(monthDetailModal.monthName || 'month').replace(/\s+/g, '_')}_tickets.csv`;
        link.click();
        URL.revokeObjectURL(link.href);
    };

    return (
        <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            style={{
                position: 'fixed',
                inset: 0,
                zIndex: 2000,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                padding: monthDetailMaximized ? 0 : '24px',
                background: 'rgba(2, 6, 23, 0.9)',
                backdropFilter: 'blur(8px)',
            }}
            onClick={() => setMonthDetailModal(null)}
        >
            <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                style={{
                    width: monthDetailMaximized ? '98vw' : '100%',
                    maxWidth: monthDetailMaximized ? '98vw' : 'min(1200px, 95vw)',
                    height: monthDetailMaximized ? '98vh' : 'auto',
                    maxHeight: monthDetailMaximized ? '98vh' : '90vh',
                    background: 'linear-gradient(180deg, var(--card) 0%, #12101f 100%)',
                    border: '1px solid rgba(129, 140, 248, 0.25)',
                    borderRadius: monthDetailMaximized ? 0 : '20px',
                    boxShadow: '0 25px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.05)',
                    display: 'flex',
                    flexDirection: 'column',
                    overflow: 'hidden',
                }}
                onClick={(e) => e.stopPropagation()}
            >
                {/* Header: title + Maximize + Close */}
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 24px', borderBottom: '1px solid var(--border)', background: 'rgba(129, 140, 248, 0.1)', flexShrink: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                        <div style={{ width: '44px', height: '44px', borderRadius: '12px', background: 'linear-gradient(135deg, var(--accent) 0%, var(--purple) 100%)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                            <BarChart3 size={24} />
                        </div>
                        <div>
                            <h2 style={{ margin: 0, fontSize: '20px', fontWeight: 700, color: 'var(--text-main)' }}>
                                {monthDetailModal.monthName} – All tickets
                            </h2>
                            <p style={{ margin: '2px 0 0 0', fontSize: '12px', color: 'var(--text-muted)' }}>
                                Full data for this month · Click column header to sort · Use search to filter
                            </p>
                        </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <button
                            type="button"
                            onClick={() => setMonthDetailMaximized((m) => !m)}
                            style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid var(--border)', color: 'var(--text-main)', width: '40px', height: '40px', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
                            title={monthDetailMaximized ? 'Restore' : 'Maximize'}
                        >
                            {monthDetailMaximized ? <Minimize2 size={18} /> : <Maximize2 size={18} />}
                        </button>
                        <button
                            type="button"
                            onClick={() => setMonthDetailModal(null)}
                            style={{ background: 'rgba(239, 68, 68, 0.15)', border: '1px solid rgba(239, 68, 68, 0.3)', color: 'var(--danger)', width: '40px', height: '40px', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
                            title="Close"
                        >
                            <X size={20} />
                        </button>
                    </div>
                </div>
                <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column', padding: '16px 24px' }}>
                    {monthDetailTickets.loading ? (
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '200px', color: 'var(--accent)' }}>
                            <div className="spinning" style={{ width: '32px', height: '32px', border: '3px solid var(--border)', borderTopColor: 'var(--accent)', borderRadius: '50%' }} />
                            <span style={{ marginLeft: '12px', fontSize: '15px' }}>Loading month data...</span>
                        </div>
                    ) : monthDetailTickets.rows.length === 0 ? (
                        <div style={{ textAlign: 'center', padding: '48px 24px', color: 'var(--text-muted)' }}>
                            <FileSpreadsheet size={48} style={{ marginBottom: '16px', opacity: 0.5 }} />
                            <p style={{ margin: 0, fontSize: '15px' }}>No tickets found for this month.</p>
                        </div>
                    ) : (
                        <>
                            {/* Toolbar: Search + Export CSV */}
                            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px', flexWrap: 'wrap' }}>
                                <div style={{ position: 'relative', flex: '1', minWidth: '200px' }}>
                                    <Search size={18} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                                    <input
                                        type="text"
                                        placeholder="Search in all columns..."
                                        value={monthDetailSearch}
                                        onChange={(e) => setMonthDetailSearch(e.target.value)}
                                        style={{ width: '100%', padding: '10px 12px 10px 40px', borderRadius: '10px', border: '1px solid var(--border)', background: 'rgba(15, 23, 42, 0.9)', color: 'var(--text-main)', fontSize: '14px' }}
                                    />
                                </div>
                                <button
                                    type="button"
                                    onClick={exportMonthCSV}
                                    className="header-btn header-btn-ghost"
                                    style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
                                >
                                    <Download size={16} /> Export CSV
                                </button>
                                <span style={{ fontSize: '13px', color: 'var(--text-muted)' }}>
                                    {sortedRows.length} of {rawRows.length} row(s)
                                    {searchLower ? ` matching "${monthDetailSearch}"` : ''}
                                </span>
                            </div>
                            <div style={{ flex: 1, overflow: 'auto', border: '1px solid var(--border)', borderRadius: '12px', background: 'rgba(255,255,255,0.02)' }}>
                                <table className="excel-table" style={{ minWidth: '100%', fontSize: '13px' }}>
                                    <thead>
                                        <tr>
                                            {cols.map((col) => (
                                                <th
                                                    key={col}
                                                    onClick={() => setMonthDetailSort((s) => ({ col, dir: s.col === col && s.dir === 'asc' ? 'desc' : 'asc' }))}
                                                    style={{ padding: '12px 14px', whiteSpace: 'nowrap', position: 'sticky', top: 0, background: '#1e293b', zIndex: 1, cursor: 'pointer', userSelect: 'none' }}
                                                    title="Click to sort"
                                                >
                                                    {col}
                                                    {monthDetailSort.col === col && (monthDetailSort.dir === 'asc' ? ' ↑' : ' ↓')}
                                                </th>
                                            ))}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {sortedRows.map((row, i) => (
                                            <tr key={i} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                                                {cols.map((col) => (
                                                    <td key={col} style={{ padding: '10px 14px', maxWidth: '320px', overflow: 'hidden', textOverflow: 'ellipsis' }} title={String(row[col] ?? '')}>
                                                        {String(row[col] ?? '')}
                                                    </td>
                                                ))}
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </>
                    )}
                </div>
            </motion.div>
        </motion.div>
    );
}
