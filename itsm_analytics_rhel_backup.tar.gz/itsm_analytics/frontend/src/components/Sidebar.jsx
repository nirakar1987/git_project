import React from 'react';
import { LayoutDashboard, BarChart3, BrainCircuit, Trash2 } from 'lucide-react';

export default function Sidebar({
    activeTab,
    setActiveTab,
    savedSessions,
    currentSessionId,
    onLoadSession,
    onDeleteSession,
    onClearAllSessions
}) {
    return (
        <div className="sidebar">
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '40px' }}>
                <div style={{ background: 'linear-gradient(135deg, var(--accent) 0%, var(--purple) 100%)', padding: '8px', borderRadius: '8px', boxShadow: '0 2px 8px rgba(129, 140, 248, 0.35)' }}>
                    <BarChart3 color="white" size={24} />
                </div>
                <h2 style={{ fontSize: '20px', fontWeight: 'bold' }}>ITSM Analytics</h2>
            </div>

            <nav>
                <button type="button" onClick={() => setActiveTab('dashboard')} className={`nav-link ${activeTab === 'dashboard' ? 'active' : ''}`}>
                    <LayoutDashboard size={20} /> Dashboard
                </button>
                <button type="button" onClick={() => setActiveTab('overview')} className={`nav-link ${activeTab === 'overview' ? 'active' : ''}`}>
                    <LayoutDashboard size={20} /> Overview
                </button>
                <button type="button" onClick={() => setActiveTab('workload')} className={`nav-link ${activeTab === 'workload' ? 'active' : ''}`}>
                    <BarChart3 size={20} /> Workload
                </button>
                <button type="button" onClick={() => setActiveTab('sla')} className={`nav-link ${activeTab === 'sla' ? 'active' : ''}`}>
                    <BrainCircuit size={20} /> SLA analysis
                </button>
                <div style={{ padding: '24px 12px 12px', fontSize: '11px', fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Data Source</div>
                {savedSessions.length > 0 && (
                    <div style={{ marginTop: '8px', paddingLeft: '12px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                            <div style={{ fontSize: '11px', fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Saved data</div>
                            <button
                                onClick={onClearAllSessions}
                                style={{ background: 'transparent', border: 'none', color: 'var(--danger)', fontSize: '10px', cursor: 'pointer', padding: '2px 6px', borderRadius: '4px' }}
                            >CLEAR ALL</button>
                        </div>
                        <div className="session-list">
                            {savedSessions.map((s) => (
                                <div key={s.session_id} style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
                                    <button
                                        type="button"
                                        onClick={() => onLoadSession(s.session_id)}
                                        className={`session-btn ${currentSessionId === s.session_id ? 'active' : ''}`}
                                        title={s.filename}
                                        style={{ paddingRight: '30px' }}
                                    >
                                        {s.filename || 'Untitled Session'}
                                    </button>
                                    <button
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            onDeleteSession(s.session_id);
                                        }}
                                        className="delete-session-btn"
                                        title="Delete"
                                    >
                                        <Trash2 size={13} />
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </nav>
        </div>
    );
}
