import React, { useState } from 'react';
import { FileSpreadsheet, Search, Download, X, Maximize2, Minimize2, ListTodo } from 'lucide-react';
import { motion } from 'framer-motion';

export default function WorkloadTicketsModal({
    workloadTicketsModal,
    setWorkloadTicketsModal,
    workloadTicketsData,
    workloadTicketsMaximized,
    setWorkloadTicketsMaximized,
}) {
    const [search, setSearch] = useState('');
    const [sort, setSort] = useState({ col: null, dir: 'asc' });

    if (!workloadTicketsModal) return null;

    const cols = workloadTicketsData?.columns || [];
    const rawRows = workloadTicketsData?.rows || [];
    const loading = workloadTicketsData?.loading ?? false;
    const searchLower = (search || '').trim().toLowerCase();

    const filteredRows = searchLower
        ? rawRows.filter((row) => cols.some((c) => String(row[c] ?? '').toLowerCase().includes(searchLower)))
        : rawRows;

    const sortedRows = sort.col && cols.includes(sort.col)
        ? [...filteredRows].sort((a, b) => {
            const va = String(a[sort.col] ?? '');
            const vb = String(b[sort.col] ?? '');
            const cmp = va.localeCompare(vb, undefined, { numeric: true });
            return sort.dir === 'asc' ? cmp : -cmp;
        })
        : filteredRows;

    const exportCSV = () => {
        if (cols.length === 0 || sortedRows.length === 0) return;
        const BOM = '\uFEFF';
        const header = cols.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',');
        const lines = sortedRows.map((row) => cols.map((c) => `"${String(row[c] ?? '').replace(/"/g, '""')}"`).join(','));
        const csv = BOM + [header, ...lines].join('\r\n');
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        const label = workloadTicketsModal.month
            ? `${String(workloadTicketsModal.category).replace(/\s+/g, '_')}_${String(workloadTicketsModal.month).replace(/\s+/g, '_')}_tickets`
            : `${String(workloadTicketsModal.category).replace(/\s+/g, '_')}_all_tickets`;
        link.download = `${label}.csv`;
        link.click();
        URL.revokeObjectURL(link.href);
    };

    const title = workloadTicketsModal.month
        ? `${workloadTicketsModal.category} · ${workloadTicketsModal.month}`
        : `${workloadTicketsModal.category} · All months (Total)`;

    return (
        <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            style={{
                position: 'fixed',
                inset: 0,
                zIndex: 2000,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                padding: workloadTicketsMaximized ? 0 : '24px',
                background: 'rgba(2, 6, 23, 0.9)',
                backdropFilter: 'blur(8px)',
            }}
            onClick={() => setWorkloadTicketsModal(null)}
        >
            <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                style={{
                    width: workloadTicketsMaximized ? '98vw' : '100%',
                    maxWidth: workloadTicketsMaximized ? '98vw' : 'min(1200px, 95vw)',
                    height: workloadTicketsMaximized ? '98vh' : 'auto',
                    maxHeight: workloadTicketsMaximized ? '98vh' : '90vh',
                    background: 'linear-gradient(180deg, var(--card) 0%, #12101f 100%)',
                    border: '1px solid rgba(129, 140, 248, 0.25)',
                    borderRadius: workloadTicketsMaximized ? 0 : '20px',
                    boxShadow: '0 25px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.05)',
                    display: 'flex',
                    flexDirection: 'column',
                    overflow: 'hidden',
                }}
                onClick={(e) => e.stopPropagation()}
            >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 24px', borderBottom: '1px solid var(--border)', background: 'rgba(129, 140, 248, 0.1)', flexShrink: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                        <div style={{ width: '44px', height: '44px', borderRadius: '12px', background: 'linear-gradient(135deg, var(--accent) 0%, var(--purple) 100%)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                            <ListTodo size={24} />
                        </div>
                        <div>
                            <h2 style={{ margin: 0, fontSize: '20px', fontWeight: 700, color: 'var(--text-main)' }}>
                                Tickets – {title}
                            </h2>
                            <p style={{ margin: '2px 0 0 0', fontSize: '12px', color: 'var(--text-muted)' }}>
                                Click column header to sort · Use search to filter · Export to CSV
                            </p>
                        </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <button
                            type="button"
                            onClick={() => setWorkloadTicketsMaximized((m) => !m)}
                            style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid var(--border)', color: 'var(--text-main)', width: '40px', height: '40px', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
                            title={workloadTicketsMaximized ? 'Restore' : 'Maximize'}
                        >
                            {workloadTicketsMaximized ? <Minimize2 size={18} /> : <Maximize2 size={18} />}
                        </button>
                        <button
                            type="button"
                            onClick={() => setWorkloadTicketsModal(null)}
                            style={{ background: 'rgba(239, 68, 68, 0.15)', border: '1px solid rgba(239, 68, 68, 0.3)', color: 'var(--danger)', width: '40px', height: '40px', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
                            title="Close"
                        >
                            <X size={20} />
                        </button>
                    </div>
                </div>
                <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column', padding: '16px 24px' }}>
                    {loading ? (
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '200px', color: 'var(--accent)' }}>
                            <div className="spinning" style={{ width: '32px', height: '32px', border: '3px solid var(--border)', borderTopColor: 'var(--accent)', borderRadius: '50%' }} />
                            <span style={{ marginLeft: '12px', fontSize: '15px' }}>Loading tickets...</span>
                        </div>
                    ) : rawRows.length === 0 ? (
                        <div style={{ textAlign: 'center', padding: '48px 24px', color: 'var(--text-muted)' }}>
                            <FileSpreadsheet size={48} style={{ marginBottom: '16px', opacity: 0.5 }} />
                            <p style={{ margin: 0, fontSize: '15px' }}>No tickets found for this selection.</p>
                        </div>
                    ) : (
                        <>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px', flexWrap: 'wrap' }}>
                                <div style={{ position: 'relative', flex: '1', minWidth: '200px' }}>
                                    <Search size={18} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                                    <input
                                        type="text"
                                        placeholder="Search in all columns..."
                                        value={search}
                                        onChange={(e) => setSearch(e.target.value)}
                                        style={{ width: '100%', padding: '10px 12px 10px 40px', borderRadius: '10px', border: '1px solid var(--border)', background: 'rgba(15, 23, 42, 0.9)', color: 'var(--text-main)', fontSize: '14px' }}
                                    />
                                </div>
                                <button type="button" onClick={exportCSV} className="header-btn header-btn-ghost" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                    <Download size={16} /> Export CSV
                                </button>
                                <span style={{ fontSize: '13px', color: 'var(--text-muted)' }}>
                                    {sortedRows.length} of {rawRows.length} ticket(s)
                                    {searchLower ? ` matching "${search}"` : ''}
                                </span>
                            </div>
                            <div style={{ flex: 1, overflow: 'auto', border: '1px solid var(--border)', borderRadius: '12px', background: 'rgba(255,255,255,0.02)' }}>
                                <table className="excel-table" style={{ minWidth: '100%', fontSize: '13px' }}>
                                    <thead>
                                        <tr>
                                            {cols.map((col) => (
                                                <th
                                                    key={col}
                                                    onClick={() => setSort((s) => ({ col, dir: s.col === col && s.dir === 'asc' ? 'desc' : 'asc' }))}
                                                    style={{ padding: '12px 14px', whiteSpace: 'nowrap', position: 'sticky', top: 0, background: '#1e293b', zIndex: 1, cursor: 'pointer', userSelect: 'none' }}
                                                    title="Click to sort"
                                                >
                                                    {col}
                                                    {sort.col === col && (sort.dir === 'asc' ? ' ↑' : ' ↓')}
                                                </th>
                                            ))}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {sortedRows.map((row, i) => (
                                            <tr key={i} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                                                {cols.map((col) => (
                                                    <td key={col} style={{ padding: '10px 14px', maxWidth: '320px', overflow: 'hidden', textOverflow: 'ellipsis' }} title={String(row[col] ?? '')}>
                                                        {String(row[col] ?? '')}
                                                    </td>
                                                ))}
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </>
                    )}
                </div>
            </motion.div>
        </motion.div>
    );
}
