from sqlmodel import SQLModel, Field
from datetime import datetime
from typing import Optional

class ScheduledJob(SQLModel, table=True):
    __tablename__ = "scheduled_jobs"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    description: Optional[str] = None
    playbook_tags: str  # e.g., "cleanup", "patch", "metrics"
    extra_vars: str = "{}"  # JSON string
    schedule_type: str  # "daily", "weekly", "monthly", "cron"
    schedule_value: str  # e.g., "02:00" for daily, "Sunday 02:00" for weekly, or cron expression
    target_hosts: str = "all"  # Comma-separated hostnames or "all"
    enabled: bool = True
    last_run: Optional[datetime] = None
    next_run: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    created_by: str = "admin"
    
class JobExecution(SQLModel, table=True):
    __tablename__ = "job_executions"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    job_id: int
    job_name: str
    status: str  # "success", "failed", "running"
    started_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    output: Optional[str] = None
    error: Optional[str] = None
