from typing import Optional, List
from datetime import datetime
from sqlmodel import SQLModel, Field
from sqlalchemy import Column, JSON

class SystemMetric(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    cpu_percent: float
    memory_percent: float
    disk_percent: float
    network_sent: float
    network_recv: float
    iops_read: float = 0.0
    iops_write: float = 0.0
    host: str = Field(default="localhost")

class Playbook(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    content: str
    description: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)

class TaskLog(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    task_id: str  # Celery task ID
    playbook_id: Optional[int] = Field(default=None, foreign_key="playbook.id")
    status: str # pending, running, success, failed
    output: str = ""
    created_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    task_type: str # cleanup, patch, install, custom

class PatchHistory(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    run_date: datetime = Field(default_factory=datetime.utcnow)
    packages_updated: List[str] = Field(default=[], sa_column=Column(JSON))
    status: str
    log_output: str

class InstalledPackage(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    version: str
    installed_at: datetime = Field(default_factory=datetime.utcnow)
