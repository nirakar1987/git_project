from fastapi import APIRouter, Depends, UploadFile, File
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlmodel import select
from app.core.db import get_session
from app.models.models import SystemMetric
from app.services.system_service import SystemService
from app.services.ansible_runner import AnsibleService

router = APIRouter()
ansible_service = AnsibleService()

@router.get("/latest")
async def get_latest_metrics(host: str = "localhost", session: AsyncSession = Depends(get_session)):
    if host == "localhost" or host == "127.0.0.1":
        # Fetch live metrics for local
        metrics_data = SystemService.get_metrics()
    else:
        # Generate mock metrics for other hosts to simulate activity
        import random
        metrics_data = {
            "cpu_percent": round(random.uniform(10, 90), 1),
            "memory_percent": round(random.uniform(20, 80), 1),
            "disk_percent": round(random.uniform(30, 70), 1),
            "network_sent": round(random.uniform(0, 100), 1),
            "network_recv": round(random.uniform(0, 100), 1),
            "iops_read": round(random.uniform(10, 500), 1),
            "iops_write": round(random.uniform(10, 200), 1),
        }
    
    # Save to DB
    metrics_data["host"] = host
    metric = SystemMetric(**metrics_data)
    session.add(metric)
    await session.commit()
    await session.refresh(metric)
    
    return metric

@router.get("/history")
async def get_metrics_history(host: str = "localhost", limit: int = 100, session: AsyncSession = Depends(get_session)):
    statement = select(SystemMetric).where(SystemMetric.host == host).order_by(SystemMetric.timestamp.desc()).limit(limit)
    result = await session.exec(statement)
    return result.all()

@router.post("/discover")
async def discover_metrics(file: UploadFile = File(...), session: AsyncSession = Depends(get_session)):
    content = await file.read()
    playbook_content = content.decode("utf-8")
    
    metrics_data = ansible_service.run_metrics_discovery(playbook_content)
    
    # Save to DB so history graph updates
    metric = SystemMetric(**metrics_data)
    session.add(metric)
    await session.commit()
    await session.refresh(metric)
    
    return metric

@router.post("/fetch/master")
async def fetch_master_metrics(session: AsyncSession = Depends(get_session)):
    # Run metrics using site.yml
    metrics_data = ansible_service.run_metrics_by_name("site.yml")
    
    # Save to DB
    metric = SystemMetric(**metrics_data)
    session.add(metric)
    await session.commit()
    await session.refresh(metric)
    
    return metric

@router.get("/predictions/{host}")
async def get_predictions(host: str, session: AsyncSession = Depends(get_session)):
    """Get predictive analytics for a specific host."""
    from app.services.analytics_service import AnalyticsService
    
    # Convert async session to sync for analytics service
    # In production, you'd want to make AnalyticsService async-compatible
    predictions = AnalyticsService.get_all_predictions(session, host)
    
    return predictions

