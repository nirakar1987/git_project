from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from datetime import datetime
from typing import List
from pydantic import BaseModel

from app.core.db import get_session
from app.models.scheduler_models import ScheduledJob, JobExecution
from app.services.scheduler_service import SchedulerService
from app.services.ansible_runner import AnsibleService

router = APIRouter()
ansible_service = AnsibleService()

class JobCreate(BaseModel):
    name: str
    description: str = ""
    playbook_tags: str
    extra_vars: str = "{}"
    schedule_type: str
    schedule_value: str
    target_hosts: str = "all"
    enabled: bool = True

class JobUpdate(BaseModel):
    name: str = None
    description: str = None
    enabled: bool = None
    schedule_type: str = None
    schedule_value: str = None
    target_hosts: str = None
    extra_vars: str = None

@router.get("/jobs", response_model=List[ScheduledJob])
async def list_jobs(session: Session = Depends(get_session)):
    """Get all scheduled jobs."""
    statement = select(ScheduledJob).order_by(ScheduledJob.created_at.desc())
    result = await session.exec(statement)
    return result.all()

@router.post("/jobs")
async def create_job(job: JobCreate, session: Session = Depends(get_session)):
    """Create a new scheduled job."""
    # Calculate next run time
    next_run = SchedulerService.calculate_next_run(job.schedule_type, job.schedule_value)
    
    new_job = ScheduledJob(
        **job.dict(),
        next_run=next_run
    )
    
    session.add(new_job)
    await session.commit()
    await session.refresh(new_job)
    
    return new_job

@router.put("/jobs/{job_id}")
async def update_job(job_id: int, job_update: JobUpdate, session: Session = Depends(get_session)):
    """Update a scheduled job."""
    statement = select(ScheduledJob).where(ScheduledJob.id == job_id)
    result = await session.exec(statement)
    job = result.first()
    
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    
    # Update fields
    update_data = job_update.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(job, key, value)
    
    # Recalculate next run if schedule changed
    if "schedule_type" in update_data or "schedule_value" in update_data:
        job.next_run = SchedulerService.calculate_next_run(job.schedule_type, job.schedule_value)
    
    await session.commit()
    await session.refresh(job)
    
    return job

@router.delete("/jobs/{job_id}")
async def delete_job(job_id: int, session: Session = Depends(get_session)):
    """Delete a scheduled job."""
    statement = select(ScheduledJob).where(ScheduledJob.id == job_id)
    result = await session.exec(statement)
    job = result.first()
    
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    
    await session.delete(job)
    await session.commit()
    
    return {"message": "Job deleted successfully"}

@router.post("/jobs/{job_id}/run")
async def run_job_now(job_id: int, session: Session = Depends(get_session)):
    """Manually trigger a job to run immediately."""
    statement = select(ScheduledJob).where(ScheduledJob.id == job_id)
    result = await session.exec(statement)
    job = result.first()
    
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    
    # Create execution record
    execution = JobExecution(
        job_id=job.id,
        job_name=job.name,
        status="running"
    )
    session.add(execution)
    await session.commit()
    await session.refresh(execution)
    
    try:
        # Parse extra vars
        extra_vars = SchedulerService.parse_extra_vars(job.extra_vars)
        
        # Run the playbook
        result = ansible_service.run_playbook_by_name(
            "site.yml",
            extra_vars=extra_vars,
            tags=job.playbook_tags
        )
        
        # Update execution record
        execution.status = "success"
        execution.completed_at = datetime.utcnow()
        execution.output = result.get("stdout", "")
        
        # Update job last run
        job.last_run = datetime.utcnow()
        
    except Exception as e:
        execution.status = "failed"
        execution.completed_at = datetime.utcnow()
        execution.error = str(e)
    
    await session.commit()
    await session.refresh(execution)
    
    return execution

@router.get("/jobs/{job_id}/executions")
async def get_job_executions(job_id: int, limit: int = 10, session: Session = Depends(get_session)):
    """Get execution history for a job."""
    statement = select(JobExecution).where(
        JobExecution.job_id == job_id
    ).order_by(JobExecution.started_at.desc()).limit(limit)
    
    result = await session.exec(statement)
    return result.all()

@router.get("/executions/recent")
async def get_recent_executions(limit: int = 20, session: Session = Depends(get_session)):
    """Get recent job executions across all jobs."""
    statement = select(JobExecution).order_by(JobExecution.started_at.desc()).limit(limit)
    result = await session.exec(statement)
    return result.all()
