from fastapi import APIRouter, Depends, Response
from sqlmodel import Session, select
from datetime import datetime, timedelta
from typing import Optional
import io
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
from reportlab.lib.units import inch

from app.core.db import get_session
from app.models.models import SystemMetric

router = APIRouter()

@router.get("/export/metrics/pdf")
async def export_metrics_pdf(
    host: str = "localhost",
    days: int = 7,
    session: Session = Depends(get_session)
):
    """Generate PDF report of system metrics."""
    
    # Fetch metrics
    since_date = datetime.utcnow() - timedelta(days=days)
    statement = select(SystemMetric).where(
        SystemMetric.host == host,
        SystemMetric.timestamp >= since_date
    ).order_by(SystemMetric.timestamp.desc())
    
    result = await session.exec(statement)
    metrics = list(result.all())
    
    if not metrics:
        return {"error": "No metrics found for this period"}
    
    # Create PDF
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    elements = []
    styles = getSampleStyleSheet()
    
    # Title
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#1e40af'),
        spaceAfter=30,
    )
    title = Paragraph(f"System Metrics Report - {host}", title_style)
    elements.append(title)
    
    # Report Info
    info_style = styles['Normal']
    info = Paragraph(f"<b>Report Generated:</b> {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}<br/>"
                     f"<b>Period:</b> Last {days} days<br/>"
                     f"<b>Total Data Points:</b> {len(metrics)}", info_style)
    elements.append(info)
    elements.append(Spacer(1, 20))
    
    # Summary Statistics
    if metrics:
        latest = metrics[0]
        avg_cpu = sum(m.cpu_percent for m in metrics) / len(metrics)
        avg_memory = sum(m.memory_percent for m in metrics) / len(metrics)
        avg_disk = sum(m.disk_percent for m in metrics) / len(metrics)
        
        summary_data = [
            ['Metric', 'Current', 'Average', 'Status'],
            ['CPU Usage', f'{latest.cpu_percent}%', f'{avg_cpu:.1f}%', 
             'Normal' if avg_cpu < 80 else 'High'],
            ['Memory Usage', f'{latest.memory_percent}%', f'{avg_memory:.1f}%',
             'Normal' if avg_memory < 80 else 'High'],
            ['Disk Usage', f'{latest.disk_percent}%', f'{avg_disk:.1f}%',
             'Normal' if avg_disk < 90 else 'Critical'],
        ]
        
        summary_table = Table(summary_data, colWidths=[2*inch, 1.5*inch, 1.5*inch, 1.5*inch])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e40af')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(Paragraph("<b>Summary Statistics</b>", styles['Heading2']))
        elements.append(Spacer(1, 10))
        elements.append(summary_table)
        elements.append(Spacer(1, 20))
    
    # Recent Metrics Table
    elements.append(Paragraph("<b>Recent Metrics (Last 10 Readings)</b>", styles['Heading2']))
    elements.append(Spacer(1, 10))
    
    metrics_data = [['Timestamp', 'CPU %', 'Memory %', 'Disk %']]
    for metric in metrics[:10]:
        metrics_data.append([
            metric.timestamp.strftime('%Y-%m-%d %H:%M'),
            f'{metric.cpu_percent}%',
            f'{metric.memory_percent}%',
            f'{metric.disk_percent}%'
        ])
    
    metrics_table = Table(metrics_data, colWidths=[2*inch, 1.5*inch, 1.5*inch, 1.5*inch])
    metrics_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e40af')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.white),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.lightgrey])
    ]))
    
    elements.append(metrics_table)
    
    # Build PDF
    doc.build(elements)
    buffer.seek(0)
    
    return Response(
        content=buffer.getvalue(),
        media_type="application/pdf",
        headers={
            "Content-Disposition": f"attachment; filename=metrics_report_{host}_{datetime.utcnow().strftime('%Y%m%d')}.pdf"
        }
    )

@router.get("/export/metrics/csv")
async def export_metrics_csv(
    host: str = "localhost",
    days: int = 7,
    session: Session = Depends(get_session)
):
    """Export metrics as CSV."""
    
    since_date = datetime.utcnow() - timedelta(days=days)
    statement = select(SystemMetric).where(
        SystemMetric.host == host,
        SystemMetric.timestamp >= since_date
    ).order_by(SystemMetric.timestamp.desc())
    
    result = await session.exec(statement)
    metrics = list(result.all())
    
    # Generate CSV
    csv_content = "Timestamp,Host,CPU %,Memory %,Disk %,Network Sent MB,Network Recv MB\n"
    for metric in metrics:
        csv_content += f"{metric.timestamp},{metric.host},{metric.cpu_percent},{metric.memory_percent},{metric.disk_percent},{metric.network_sent},{metric.network_recv}\n"
    
    return Response(
        content=csv_content,
        media_type="text/csv",
        headers={
            "Content-Disposition": f"attachment; filename=metrics_{host}_{datetime.utcnow().strftime('%Y%m%d')}.csv"
        }
    )

@router.get("/reports/summary")
async def get_summary_report(
    days: int = 7,
    session: Session = Depends(get_session)
):
    """Get summary report for all hosts."""
    
    since_date = datetime.utcnow() - timedelta(days=days)
    statement = select(SystemMetric).where(
        SystemMetric.timestamp >= since_date
    )
    
    result = await session.exec(statement)
    all_metrics = list(result.all())
    
    # Group by host
    hosts_summary = {}
    for metric in all_metrics:
        if metric.host not in hosts_summary:
            hosts_summary[metric.host] = {
                "host": metric.host,
                "data_points": 0,
                "avg_cpu": 0,
                "avg_memory": 0,
                "avg_disk": 0,
                "max_cpu": 0,
                "max_memory": 0,
                "max_disk": 0,
                "latest": None
            }
        
        summary = hosts_summary[metric.host]
        summary["data_points"] += 1
        summary["avg_cpu"] += metric.cpu_percent
        summary["avg_memory"] += metric.memory_percent
        summary["avg_disk"] += metric.disk_percent
        summary["max_cpu"] = max(summary["max_cpu"], metric.cpu_percent)
        summary["max_memory"] = max(summary["max_memory"], metric.memory_percent)
        summary["max_disk"] = max(summary["max_disk"], metric.disk_percent)
        
        if summary["latest"] is None or metric.timestamp > summary["latest"]["timestamp"]:
            summary["latest"] = {
                "timestamp": metric.timestamp,
                "cpu": metric.cpu_percent,
                "memory": metric.memory_percent,
                "disk": metric.disk_percent
            }
    
    # Calculate averages
    for host, summary in hosts_summary.items():
        if summary["data_points"] > 0:
            summary["avg_cpu"] = round(summary["avg_cpu"] / summary["data_points"], 1)
            summary["avg_memory"] = round(summary["avg_memory"] / summary["data_points"], 1)
            summary["avg_disk"] = round(summary["avg_disk"] / summary["data_points"], 1)
    
    return {
        "period_days": days,
        "total_hosts": len(hosts_summary),
        "total_data_points": len(all_metrics),
        "hosts": list(hosts_summary.values())
    }
