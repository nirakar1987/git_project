from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from app.services.ansible_runner import AnsibleService
from pydantic import BaseModel
from typing import List

router = APIRouter()
ansible_service = AnsibleService(playbook_dir="/app/ansible_playbooks")

# In-memory storage for demo purposes
discovered_hosts = []

class PackageReq(BaseModel):
    name: str

@router.get("/hosts")
async def list_hosts():
    if discovered_hosts:
        return discovered_hosts
        
    # Mocked inventory data for demo if nothing discovered yet
    return [
        {"hostname": "VM.Linux.server3", "ip": "172.16.10.48", "disk_total": "146.5GB", "disk_free": "75.6GB", "status": "online"},
        {"hostname": "DB.Postgres.01", "ip": "172.16.10.50", "disk_total": "500GB", "disk_free": "120GB", "status": "online"},
        {"hostname": "Web.Nginx.02", "ip": "172.16.10.51", "disk_total": "80GB", "disk_free": "10GB", "status": "warning"},
        {"hostname": "localhost", "ip": "127.0.0.1", "disk_total": "100GB", "disk_free": "45GB", "status": "online"}
    ]

@router.post("/discover")
async def discover_hosts(file: UploadFile = File(...)):
    content = await file.read()
    playbook_content = content.decode("utf-8")
    
    hosts = ansible_service.run_discovery(playbook_content)
    
    # For demo purposes, we merge the actual discovered hosts (likely just localhost)
    # with our mock inventory so the UI looks populated.
    demo_hosts = [
        {"hostname": "VM.Linux.server3", "ip": "172.16.10.48", "disk_total": "146.5GB", "disk_free": "75.6GB", "status": "online"},
        {"hostname": "DB.Postgres.01", "ip": "172.16.10.50", "disk_total": "500GB", "disk_free": "120GB", "status": "online"},
        {"hostname": "Web.Nginx.02", "ip": "172.16.10.51", "disk_total": "80GB", "disk_free": "10GB", "status": "warning"}
    ]
    
    # Deduplicate based on hostname
    existing_hostnames = {h['hostname'] for h in hosts}
    for demo_host in demo_hosts:
        if demo_host['hostname'] not in existing_hostnames:
            hosts.append(demo_host)
    
    # Update global state
    global discovered_hosts
    discovered_hosts = hosts
    
    return hosts

@router.post("/cleanup/{type}")
async def run_cleanup(type: str, host: str = None):
    playbook_map = {
        "logs": "clean_logs.yml",
        "tmp": "clean_tmp.yml",
        "cache": "clean_tmp.yml" # Reusing for demo
    }
    
    if type not in playbook_map:
        raise HTTPException(status_code=400, detail="Invalid cleanup type")
        
    # If host is provided, we limit the playbook execution to that host
    # Note: In a real scenario, the host must exist in the inventory.
    # For this demo, if host is 'localhost', we run on local.
    # If it's one of the mocked ones, we might fail unless we add them to inventory.
    # To make the demo 'work' visually, we will just return success for mocked hosts
    # and actually run for localhost.
    
    if host and host != "localhost":
        # Mock success for external hosts in this demo environment
        return {
            "status": "successful",
            "rc": 0,
            "stdout": f"Mock cleanup of {type} on {host} completed successfully.\n(No actual connection to {host} in this demo)"
        }

    result = ansible_service.run_playbook_by_name(playbook_map[type], limit=host)
    return result

@router.post("/patch/check")
async def check_updates():
    # In a real scenario, this would run a playbook with --check or dry-run
    return {"status": "Updates available", "count": 5}

@router.post("/patch/apply")
async def apply_updates():
    result = ansible_service.run_playbook_by_name("update_packages.yml")
    return result

@router.post("/package/install")
async def install_package(pkg: PackageReq):
    result = ansible_service.run_playbook_by_name("install_package.yml", extra_vars={"package_name": pkg.name})
    return result

@router.post("/package/remove")
async def remove_package(pkg: PackageReq):
    result = ansible_service.run_playbook_by_name("remove_package.yml", extra_vars={"package_name": pkg.name})
    return result

@router.get("/package/list")
async def list_packages():
    # Mocked for demo as running dpkg -l via ansible is slow for a simple GET
    return [
        {"name": "python3", "version": "3.10"},
        {"name": "docker-ce", "version": "24.0"},
        {"name": "ansible", "version": "2.15"}
    ]

class MasterRunReq(BaseModel):
    tags: str # Comma separated tags: metrics, cleanup, patch, software
    extra_vars: dict = {}

@router.post("/master/run")
async def run_master_playbook(req: MasterRunReq):
    # Runs the master site.yml with specific tags
    # This allows one playbook to handle everything
    
    # Merge default vars with request vars
    final_vars = {"cleanup_type": "logs", "patch_action": "check"}
    final_vars.update(req.extra_vars)
    
    result = ansible_service.run_playbook_by_name(
        "site.yml", 
        extra_vars=final_vars,
        tags=req.tags
    )
    return result

@router.post("/master/upload")
async def upload_master_playbook(file: UploadFile = File(...)):
    content = await file.read()
    playbook_content = content.decode("utf-8")
    
    # Save as site.yml in the playbook directory
    import os
    playbook_path = os.path.join(ansible_service.playbook_dir, "site.yml")
    with open(playbook_path, "w") as f:
        f.write(playbook_content)
        
    return {"status": "success", "message": "Master playbook uploaded successfully"}

@router.post("/discover/master")
async def discover_hosts_master():
    # Run discovery using site.yml
    hosts = ansible_service.run_discovery_by_name("site.yml")
    
    # Merge with demo hosts
    demo_hosts = [
        {"hostname": "VM.Linux.server3", "ip": "172.16.10.48", "disk_total": "146.5GB", "disk_free": "75.6GB", "status": "online"},
        {"hostname": "DB.Postgres.01", "ip": "172.16.10.50", "disk_total": "500GB", "disk_free": "120GB", "status": "online"},
        {"hostname": "Web.Nginx.02", "ip": "172.16.10.51", "disk_total": "80GB", "disk_free": "10GB", "status": "warning"}
    ]
    
    existing_hostnames = {h['hostname'] for h in hosts}
    for demo_host in demo_hosts:
        if demo_host['hostname'] not in existing_hostnames:
            hosts.append(demo_host)
    
    global discovered_hosts
    discovered_hosts = hosts
    
    return hosts
