from fastapi import APIRouter, Depends, HTTPException
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlmodel import select
from app.core.db import get_session
from app.models.models import Playbook, TaskLog
from app.services.ansible_runner import AnsibleService
from app.services.ai_generator import AIGenerator
from pydantic import BaseModel

router = APIRouter()
ansible_service = AnsibleService()
ai_generator = AIGenerator()

class PlaybookCreate(BaseModel):
    name: str
    content: str
    description: str = None

class PlaybookRun(BaseModel):
    playbook_id: int
    hosts: str = "all"

class AIRequest(BaseModel):
    prompt: str

@router.post("/upload")
async def upload_playbook(playbook: PlaybookCreate, session: AsyncSession = Depends(get_session)):
    db_playbook = Playbook(name=playbook.name, content=playbook.content, description=playbook.description)
    session.add(db_playbook)
    await session.commit()
    await session.refresh(db_playbook)
    return db_playbook

@router.get("/list")
async def list_playbooks(session: AsyncSession = Depends(get_session)):
    statement = select(Playbook)
    result = await session.exec(statement)
    return result.all()

@router.post("/run")
async def run_playbook(run_req: PlaybookRun, session: AsyncSession = Depends(get_session)):
    statement = select(Playbook).where(Playbook.id == run_req.playbook_id)
    result = await session.exec(statement)
    playbook = result.first()
    if not playbook:
        raise HTTPException(status_code=404, detail="Playbook not found")

    # Run synchronously for now (or use Celery in real prod, but for this demo sync is easier to show output immediately if short)
    # Ideally this should be a background task.
    # I will run it and return the result.
    
    result = ansible_service.run_playbook(playbook.content)
    
    # Log the run
    log = TaskLog(
        task_id="sync_run", # Placeholder
        playbook_id=playbook.id,
        status=result['status'],
        output=result['stdout'],
        task_type="custom"
    )
    session.add(log)
    await session.commit()
    
    return result

@router.post("/generate")
async def generate_playbook(req: AIRequest):
    content = await ai_generator.generate_playbook(req.prompt)
    return {"content": content}
