from datetime import datetime, timedelta
from typing import Optional
from jose import JWTError, jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel

# Configuration
SECRET_KEY = "your-secret-key-change-in-production-use-env-var"  # TODO: Move to .env
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 480  # 8 hours

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")

# Mock user database (in production, use PostgreSQL with hashed passwords)
# For demo purposes, using plain text passwords
fake_users_db = {
    "admin": {
        "username": "admin",
        "full_name": "System Administrator",
        "email": "admin@ansibleops.com",
        "password": "admin123",  # Plain text for demo
        "role": "admin",
        "disabled": False,
    },
    "operator": {
        "username": "operator",
        "full_name": "System Operator",
        "email": "operator@ansibleops.com",
        "password": "operator123",  # Plain text for demo
        "role": "operator",
        "disabled": False,
    },
    "viewer": {
        "username": "viewer",
        "full_name": "Read Only User",
        "email": "viewer@ansibleops.com",
        "password": "viewer123",  # Plain text for demo
        "role": "viewer",
        "disabled": False,
    }
}

class Token(BaseModel):
    access_token: str
    token_type: str
    role: str
    username: str

class TokenData(BaseModel):
    username: Optional[str] = None
    role: Optional[str] = None

class User(BaseModel):
    username: str
    email: Optional[str] = None
    full_name: Optional[str] = None
    role: str
    disabled: Optional[bool] = None

def get_user(username: str):
    if username in fake_users_db:
        user_dict = fake_users_db[username].copy()
        user_dict.pop('password', None)  # Remove password from user object
        return User(**user_dict)

def authenticate_user(username: str, password: str):
    if username not in fake_users_db:
        return False
    user_data = fake_users_db[username]
    if password != user_data["password"]:
        return False
    return get_user(username)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        role: str = payload.get("role")
        if username is None:
            raise credentials_exception
        token_data = TokenData(username=username, role=role)
    except JWTError:
        raise credentials_exception
    user = get_user(username=token_data.username)
    if user is None:
        raise credentials_exception
    return user

async def get_current_active_user(current_user: User = Depends(get_current_user)):
    if current_user.disabled:
        raise HTTPException(status_code=400, detail="Inactive user")
    return current_user

# Role-based access control decorators
def require_role(required_role: str):
    async def role_checker(current_user: User = Depends(get_current_active_user)):
        role_hierarchy = {"viewer": 1, "operator": 2, "admin": 3}
        
        user_level = role_hierarchy.get(current_user.role, 0)
        required_level = role_hierarchy.get(required_role, 999)
        
        if user_level < required_level:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Insufficient permissions. Required role: {required_role}"
            )
        return current_user
    return role_checker

# Specific role requirements
require_admin = require_role("admin")
require_operator = require_role("operator")
require_viewer = require_role("viewer")
