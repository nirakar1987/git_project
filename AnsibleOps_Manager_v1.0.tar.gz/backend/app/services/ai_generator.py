import openai
from app.core.config import settings

class AIGenerator:
    def __init__(self):
        self.api_key = settings.OPENAI_API_KEY
        if self.api_key:
            openai.api_key = self.api_key

    async def generate_playbook(self, prompt: str) -> str:
        if not self.api_key:
            return "# Error: OpenAI API Key not configured in .env"

        system_prompt = """
        You are an expert Ansible developer. 
        Generate a complete, valid Ansible playbook YAML based on the user's request.
        Return ONLY the YAML code, no markdown formatting, no explanations.
        Start with ---
        """

        try:
            response = await openai.ChatCompletion.acreate(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt}
                ]
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            return f"# Error generating playbook: {str(e)}"
