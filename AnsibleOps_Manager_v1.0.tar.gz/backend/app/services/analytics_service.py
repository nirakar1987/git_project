import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from sqlmodel import Session, select
from app.models.models import SystemMetric

class AnalyticsService:
    @staticmethod
    def predict_resource_exhaustion(session: Session, host: str, metric_type: str = "disk_percent") -> Dict:
        """
        Predict when a resource will be exhausted based on historical trends.
        Uses linear regression on historical data.
        """
        # Get historical data for the last 7 days
        statement = select(SystemMetric).where(
            SystemMetric.host == host
        ).order_by(SystemMetric.timestamp.desc()).limit(100)
        
        result = session.exec(statement)
        metrics = list(result.all())
        
        if len(metrics) < 5:
            return {
                "status": "insufficient_data",
                "message": "Not enough historical data for prediction",
                "days_until_full": None,
                "current_usage": 0,
                "predicted_usage": []
            }
        
        # Reverse to get chronological order
        metrics.reverse()
        
        # Extract timestamps and values
        timestamps = []
        values = []
        
        for m in metrics:
            if metric_type == "disk_percent":
                values.append(m.disk_percent)
            elif metric_type == "memory_percent":
                values.append(m.memory_percent)
            elif metric_type == "cpu_percent":
                values.append(m.cpu_percent)
            
            # Convert timestamp to hours since first measurement
            if not timestamps:
                base_time = m.timestamp
                timestamps.append(0)
            else:
                time_diff = (m.timestamp - base_time).total_seconds() / 3600
                timestamps.append(time_diff)
        
        # Perform linear regression
        if len(timestamps) < 2:
            return {
                "status": "insufficient_data",
                "message": "Not enough data points",
                "days_until_full": None,
                "current_usage": values[-1] if values else 0,
                "predicted_usage": []
            }
        
        # Calculate slope and intercept
        x = np.array(timestamps)
        y = np.array(values)
        
        # Linear regression: y = mx + b
        n = len(x)
        m = (n * np.sum(x * y) - np.sum(x) * np.sum(y)) / (n * np.sum(x**2) - np.sum(x)**2)
        b = (np.sum(y) - m * np.sum(x)) / n
        
        current_usage = values[-1]
        current_time = timestamps[-1]
        
        # Predict future values (next 7 days)
        future_predictions = []
        hours_ahead = 24 * 7  # 7 days
        
        for i in range(0, hours_ahead + 1, 6):  # Every 6 hours
            future_time = current_time + i
            predicted_value = m * future_time + b
            
            future_predictions.append({
                "hours_from_now": i,
                "predicted_value": min(100, max(0, round(predicted_value, 1)))
            })
        
        # Calculate days until exhaustion (reaching 95%)
        days_until_full = None
        if m > 0:  # Only if usage is increasing
            hours_until_95 = (95 - current_usage) / m if m != 0 else None
            if hours_until_95 and hours_until_95 > 0:
                days_until_full = round(hours_until_95 / 24, 1)
        
        # Determine trend
        if m > 0.1:
            trend = "increasing"
        elif m < -0.1:
            trend = "decreasing"
        else:
            trend = "stable"
        
        return {
            "status": "success",
            "host": host,
            "metric_type": metric_type,
            "current_usage": round(current_usage, 1),
            "trend": trend,
            "growth_rate_per_day": round(m * 24, 2),
            "days_until_full": days_until_full,
            "predicted_usage": future_predictions,
            "recommendation": AnalyticsService._generate_recommendation(
                metric_type, current_usage, days_until_full, trend
            )
        }
    
    @staticmethod
    def _generate_recommendation(metric_type: str, current_usage: float, days_until_full: Optional[float], trend: str) -> str:
        """Generate actionable recommendation based on prediction."""
        if days_until_full and days_until_full < 7:
            return f"⚠️ URGENT: {metric_type.replace('_', ' ').title()} will reach critical levels in {days_until_full} days. Immediate action required!"
        elif days_until_full and days_until_full < 30:
            return f"⚡ WARNING: {metric_type.replace('_', ' ').title()} will reach critical levels in {days_until_full} days. Plan maintenance soon."
        elif trend == "increasing" and current_usage > 70:
            return f"📊 MONITOR: {metric_type.replace('_', ' ').title()} is trending upward. Keep monitoring."
        elif trend == "stable":
            return f"✅ HEALTHY: {metric_type.replace('_', ' ').title()} is stable. No action needed."
        else:
            return f"✅ HEALTHY: {metric_type.replace('_', ' ').title()} is within normal range."
    
    @staticmethod
    def get_all_predictions(session: Session, host: str) -> Dict:
        """Get predictions for all metrics."""
        return {
            "disk": AnalyticsService.predict_resource_exhaustion(session, host, "disk_percent"),
            "memory": AnalyticsService.predict_resource_exhaustion(session, host, "memory_percent"),
            "cpu": AnalyticsService.predict_resource_exhaustion(session, host, "cpu_percent")
        }
