import ansible_runner
import os
import shutil

class AnsibleService:
    def __init__(self, playbook_dir: str = "/app/ansible_playbooks", inventory_dir: str = "/app/inventory"):
        self.playbook_dir = playbook_dir
        self.inventory_dir = inventory_dir
        os.makedirs(self.playbook_dir, exist_ok=True)
        os.makedirs(self.inventory_dir, exist_ok=True)
        
        # Ensure inventory file exists
        if not os.path.exists(os.path.join(self.inventory_dir, "hosts")):
            with open(os.path.join(self.inventory_dir, "hosts"), "w") as f:
                f.write("[local]\nlocalhost ansible_connection=local\n")

    def run_playbook(self, playbook_content: str, extra_vars: dict = None, limit: str = None):
        # Save playbook to file
        playbook_path = os.path.join(self.playbook_dir, "temp_playbook.yml")
        with open(playbook_path, "w") as f:
            f.write(playbook_content)

        r = ansible_runner.run(
            private_data_dir='/app',
            playbook=playbook_path,
            inventory=os.path.join(self.inventory_dir, "hosts"),
            extravars=extra_vars or {},
            limit=limit
        )
        
        return {
            "status": r.status,
            "rc": r.rc,
            "stdout": r.stdout.read() if r.stdout else "No output"
        }

    def run_playbook_by_name(self, playbook_name: str, extra_vars: dict = None, limit: str = None, tags: str = None):
         # Assuming playbooks are stored in the dir
        playbook_path = os.path.join(self.playbook_dir, playbook_name)
        if not os.path.exists(playbook_path):
            raise FileNotFoundError(f"Playbook {playbook_name} not found")

        r = ansible_runner.run(
            private_data_dir='/app',
            playbook=playbook_path,
            inventory=os.path.join(self.inventory_dir, "hosts"),
            extravars=extra_vars or {},
            limit=limit,
            tags=tags
        )
        
        return {
            "status": r.status,
            "rc": r.rc,
            "stdout": r.stdout.read() if r.stdout else "No output"
        }

    def run_discovery(self, playbook_content: str):
        # Save discovery playbook
        playbook_path = os.path.join(self.playbook_dir, "discovery.yml")
        with open(playbook_path, "w") as f:
            f.write(playbook_content)

        # Run with event gathering
        r = ansible_runner.run(
            private_data_dir='/app',
            playbook=playbook_path,
            inventory=os.path.join(self.inventory_dir, "hosts")
        )

        hosts_data = []
        
        # Parse events to find facts
        # We look for 'runner_on_ok' events where task was 'Gathering Facts' or similar, 
        # or any task that returns ansible_facts.
        for event in r.events:
            if event['event'] == 'runner_on_ok':
                event_data = event.get('event_data', {})
                res = event_data.get('res', {})
                facts = res.get('ansible_facts', {})
                
                if facts:
                    host = event_data.get('host')
                    
                    # Extract relevant info
                    # Note: Structure depends on what the playbook gathers.
                    # We try to find standard fields.
                    
                    # Disk usage is tricky in standard facts without custom parsing, 
                    # but let's try to find mount points or just return basic info.
                    
                    mounts = facts.get('ansible_mounts', [])
                    disk_total = "N/A"
                    disk_free = "N/A"
                    
                    if mounts:
                        # Find root or first mount
                        root = next((m for m in mounts if m['mount'] == '/'), mounts[0])
                        total_gb = round(root.get('size_total', 0) / (1024**3), 1)
                        free_gb = round(root.get('size_available', 0) / (1024**3), 1)
                        disk_total = f"{total_gb}GB"
                        disk_free = f"{free_gb}GB"

                    ip = facts.get('ansible_default_ipv4', {}).get('address', 'Unknown')
                    
                    hosts_data.append({
                        "hostname": host,
                        "ip": ip,
                        "disk_total": disk_total,
                        "disk_free": disk_free,
                        "status": "online"
                    })

        # Deduplicate by hostname (in case multiple tasks return facts)
        unique_hosts = {h['hostname']: h for h in hosts_data}.values()
        return list(unique_hosts)

    def run_metrics_discovery(self, playbook_content: str):
        # Save discovery playbook
        playbook_path = os.path.join(self.playbook_dir, "metrics_discovery.yml")
        with open(playbook_path, "w") as f:
            f.write(playbook_content)

        # Run with event gathering
        r = ansible_runner.run(
            private_data_dir='/app',
            playbook=playbook_path,
            inventory=os.path.join(self.inventory_dir, "hosts")
        )

        # Default metrics
        metrics = {
            "cpu_percent": 0.0,
            "memory_percent": 0.0,
            "disk_percent": 0.0,
            "network_sent": 0.0,
            "network_recv": 0.0,
            "iops_read": 0.0,
            "iops_write": 0.0
        }
        
        for event in r.events:
            if event['event'] == 'runner_on_ok':
                event_data = event.get('event_data', {})
                res = event_data.get('res', {})
                facts = res.get('ansible_facts', {})
                
                if facts:
                    # Memory
                    mem_total = facts.get('ansible_memtotal_mb', 0)
                    mem_free = facts.get('ansible_memfree_mb', 0)
                    if mem_total > 0:
                        metrics['memory_percent'] = round(((mem_total - mem_free) / mem_total) * 100, 1)
                    
                    # Disk (Root)
                    mounts = facts.get('ansible_mounts', [])
                    if mounts:
                        root = next((m for m in mounts if m['mount'] == '/'), mounts[0])
                        size_total = root.get('size_total', 0)
                        size_available = root.get('size_available', 0)
                        if size_total > 0:
                            metrics['disk_percent'] = round(((size_total - size_available) / size_total) * 100, 1)
                            
                    # CPU/Network/IOPS are not in standard facts. 
                    # We check if the playbook set custom facts (e.g. via set_fact module)
                    if 'custom_cpu_percent' in facts:
                        metrics['cpu_percent'] = float(facts['custom_cpu_percent'])
                    if 'custom_network_sent' in facts:
                        metrics['network_sent'] = float(facts['custom_network_sent'])
                    if 'custom_network_recv' in facts:
                        metrics['network_recv'] = float(facts['custom_network_recv'])

        return metrics

    def run_discovery_by_name(self, playbook_name: str):
        playbook_path = os.path.join(self.playbook_dir, playbook_name)
        if not os.path.exists(playbook_path):
            raise FileNotFoundError(f"Playbook {playbook_name} not found")

        # Run with event gathering
        r = ansible_runner.run(
            private_data_dir='/app',
            playbook=playbook_path,
            inventory=os.path.join(self.inventory_dir, "hosts"),
            tags='discovery'
        )

        hosts_data = []
        for event in r.events:
            if event['event'] == 'runner_on_ok':
                event_data = event.get('event_data', {})
                res = event_data.get('res', {})
                facts = res.get('ansible_facts', {})
                
                if facts:
                    host = event_data.get('host')
                    mounts = facts.get('ansible_mounts', [])
                    disk_total = "N/A"
                    disk_free = "N/A"
                    if mounts:
                        root = next((m for m in mounts if m['mount'] == '/'), mounts[0])
                        total_gb = round(root.get('size_total', 0) / (1024**3), 1)
                        free_gb = round(root.get('size_available', 0) / (1024**3), 1)
                        disk_total = f"{total_gb}GB"
                        disk_free = f"{free_gb}GB"

                    ip = facts.get('ansible_default_ipv4', {}).get('address', 'Unknown')
                    
                    hosts_data.append({
                        "hostname": host,
                        "ip": ip,
                        "disk_total": disk_total,
                        "disk_free": disk_free,
                        "status": "online"
                    })

        unique_hosts = {h['hostname']: h for h in hosts_data}.values()
        return list(unique_hosts)

    def run_metrics_by_name(self, playbook_name: str):
        playbook_path = os.path.join(self.playbook_dir, playbook_name)
        if not os.path.exists(playbook_path):
            raise FileNotFoundError(f"Playbook {playbook_name} not found")

        r = ansible_runner.run(
            private_data_dir='/app',
            playbook=playbook_path,
            inventory=os.path.join(self.inventory_dir, "hosts"),
            tags='metrics'
        )

        metrics = {
            "cpu_percent": 0.0,
            "memory_percent": 0.0,
            "disk_percent": 0.0,
            "network_sent": 0.0,
            "network_recv": 0.0,
            "iops_read": 0.0,
            "iops_write": 0.0
        }
        
        for event in r.events:
            if event['event'] == 'runner_on_ok':
                event_data = event.get('event_data', {})
                res = event_data.get('res', {})
                facts = res.get('ansible_facts', {})
                
                if facts:
                    mem_total = facts.get('ansible_memtotal_mb', 0)
                    mem_free = facts.get('ansible_memfree_mb', 0)
                    if mem_total > 0:
                        metrics['memory_percent'] = round(((mem_total - mem_free) / mem_total) * 100, 1)
                    
                    mounts = facts.get('ansible_mounts', [])
                    if mounts:
                        root = next((m for m in mounts if m['mount'] == '/'), mounts[0])
                        size_total = root.get('size_total', 0)
                        size_available = root.get('size_available', 0)
                        if size_total > 0:
                            metrics['disk_percent'] = round(((size_total - size_available) / size_total) * 100, 1)
                            
                    if 'custom_cpu_percent' in facts:
                        metrics['cpu_percent'] = float(facts['custom_cpu_percent'])
                    if 'custom_network_sent' in facts:
                        metrics['network_sent'] = float(facts['custom_network_sent'])
                    if 'custom_network_recv' in facts:
                        metrics['network_recv'] = float(facts['custom_network_recv'])

        return metrics
