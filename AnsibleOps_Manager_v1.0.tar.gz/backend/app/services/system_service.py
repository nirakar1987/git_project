import psutil
import time

class SystemService:
    @staticmethod
    def get_metrics():
        cpu = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        net_io = psutil.net_io_counters()
        disk_io = psutil.disk_io_counters()

        return {
            "cpu_percent": cpu,
            "memory_percent": memory.percent,
            "disk_percent": disk.percent,
            "network_sent": net_io.bytes_sent,
            "network_recv": net_io.bytes_recv,
            "iops_read": disk_io.read_count if disk_io else 0,
            "iops_write": disk_io.write_count if disk_io else 0
        }
