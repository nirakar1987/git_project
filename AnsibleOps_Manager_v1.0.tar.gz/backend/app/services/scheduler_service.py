from datetime import datetime, timedelta
from typing import List, Optional
import json
from croniter import croniter

class SchedulerService:
    @staticmethod
    def calculate_next_run(schedule_type: str, schedule_value: str, from_time: datetime = None) -> datetime:
        """Calculate the next run time based on schedule type and value."""
        if from_time is None:
            from_time = datetime.utcnow()
        
        if schedule_type == "daily":
            # schedule_value format: "HH:MM" (e.g., "02:00")
            hour, minute = map(int, schedule_value.split(":"))
            next_run = from_time.replace(hour=hour, minute=minute, second=0, microsecond=0)
            
            # If time has passed today, schedule for tomorrow
            if next_run <= from_time:
                next_run += timedelta(days=1)
            
            return next_run
        
        elif schedule_type == "weekly":
            # schedule_value format: "Monday 02:00", "Sunday 14:30", etc.
            day_name, time_str = schedule_value.rsplit(" ", 1)
            hour, minute = map(int, time_str.split(":"))
            
            days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
            target_day = days.index(day_name)
            current_day = from_time.weekday()
            
            days_ahead = target_day - current_day
            if days_ahead < 0:  # Target day already passed this week
                days_ahead += 7
            elif days_ahead == 0:  # Same day - check if time has passed
                next_run = from_time.replace(hour=hour, minute=minute, second=0, microsecond=0)
                if next_run <= from_time:
                    days_ahead = 7
            
            next_run = from_time + timedelta(days=days_ahead)
            next_run = next_run.replace(hour=hour, minute=minute, second=0, microsecond=0)
            
            return next_run
        
        elif schedule_type == "monthly":
            # schedule_value format: "1 02:00" (day of month and time)
            day, time_str = schedule_value.split(" ")
            day = int(day)
            hour, minute = map(int, time_str.split(":"))
            
            next_run = from_time.replace(day=day, hour=hour, minute=minute, second=0, microsecond=0)
            
            # If date has passed this month, go to next month
            if next_run <= from_time:
                if from_time.month == 12:
                    next_run = next_run.replace(year=from_time.year + 1, month=1)
                else:
                    next_run = next_run.replace(month=from_time.month + 1)
            
            return next_run
        
        elif schedule_type == "cron":
            # schedule_value is a cron expression
            cron = croniter(schedule_value, from_time)
            return cron.get_next(datetime)
        
        else:
            raise ValueError(f"Unknown schedule type: {schedule_type}")
    
    @staticmethod
    def is_job_due(job) -> bool:
        """Check if a job is due to run."""
        if not job.enabled:
            return False
        
        if job.next_run is None:
            return True  # First run
        
        return datetime.utcnow() >= job.next_run
    
    @staticmethod
    def parse_extra_vars(extra_vars_str: str) -> dict:
        """Parse extra_vars JSON string to dict."""
        try:
            return json.loads(extra_vars_str) if extra_vars_str else {}
        except:
            return {}
    
    @staticmethod
    def format_schedule_display(schedule_type: str, schedule_value: str) -> str:
        """Format schedule for human-readable display."""
        if schedule_type == "daily":
            return f"Daily at {schedule_value}"
        elif schedule_type == "weekly":
            return f"Every {schedule_value}"
        elif schedule_type == "monthly":
            day, time = schedule_value.split(" ")
            return f"Monthly on day {day} at {time}"
        elif schedule_type == "cron":
            return f"Cron: {schedule_value}"
        return schedule_value
