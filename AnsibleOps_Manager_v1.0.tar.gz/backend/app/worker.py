from celery import Celery
from app.core.config import settings
from app.services.ansible_runner import AnsibleService
import asyncio
from app.core.db import get_session
from app.models.models import TaskLog

celery_app = Celery(
    "worker",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND
)

ansible_service = AnsibleService()

@celery_app.task(name="run_playbook_task")
def run_playbook_task(playbook_content: str, task_log_id: int):
    # In a real app, we would update the DB with status.
    # Since Celery is sync, we run ansible sync.
    result = ansible_service.run_playbook(playbook_content)
    return result
