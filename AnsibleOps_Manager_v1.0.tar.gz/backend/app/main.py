from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api import metrics, playbooks, system, auth, scheduler, reports
from app.core.db import init_db

app = FastAPI(title="AnsibleOps Manager")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def on_startup():
    await init_db()

app.include_router(auth.router, prefix="/auth", tags=["authentication"])
app.include_router(metrics.router, prefix="/metrics", tags=["metrics"])
app.include_router(playbooks.router, prefix="/playbook", tags=["playbooks"])
app.include_router(system.router, prefix="/system", tags=["system"])
app.include_router(scheduler.router, prefix="/scheduler", tags=["scheduler"])
app.include_router(reports.router, prefix="/reports", tags=["reports"])

@app.get("/")
def read_root():
    return {"message": "AnsibleOps Backend Running"}
