# AnsibleOps Manager

A complete web application for Linux system management with Ansible backend automation.

## Features
- **System Metrics**: Real-time CPU, RAM, Disk, Network monitoring.
- **Maintenance**: Disk cleanup (logs, tmp, cache) via Ansible.
- **Patching**: OS update management.
- **Software Manager**: Install/Remove packages.
- **Ansible Automation**: Upload and run playbooks.
- **AI Integration**: Generate playbooks using OpenAI (requires API Key).

## Tech Stack
- **Backend**: FastAPI, Celery, Ansible, PostgreSQL.
- **Frontend**: React, Vite, TailwindCSS, shadcn/ui.
- **Infrastructure**: Docker, Docker Compose.

## Setup & Run

1. **Prerequisites**: Docker and Docker Compose installed.
2. **Environment**:
   - Edit `backend/.env` and add your `OPENAI_API_KEY` if you want to use the AI features.
3. **Start**:
   ```bash
   docker compose up --build
   ```
4. **Access**:
   - Frontend: http://localhost:5173
   - Backend API: http://localhost:8000/docs
   - PgAdmin: http://localhost:5050 (admin@admin.com / admin)

## Notes
- The default inventory is set to `localhost` inside the container.
- To manage external servers, edit `backend/inventory/hosts` or mount a volume.
