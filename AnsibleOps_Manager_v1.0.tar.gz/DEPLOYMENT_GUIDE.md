# 🚀 AnsibleOps Manager - Deployment Guide

## 📋 **Prerequisites**

Before transferring the application, ensure the target system has:

### **Required Software:**
- ✅ **Docker Desktop** (Windows/Mac) or **Docker Engine** (Linux)
- ✅ **Docker Compose** v2.0+
- ✅ **Git** (optional, for version control)

### **System Requirements:**
- **RAM**: Minimum 4GB, Recommended 8GB
- **Disk Space**: Minimum 5GB free
- **OS**: Windows 10/11, Ubuntu 20.04+, macOS 10.15+
- **Ports**: 5173 (Frontend), 8000 (Backend), 5432 (PostgreSQL), 5050 (PgAdmin)

---

## 📦 **Method 1: Transfer via ZIP/Copy (Recommended for Local Transfer)**

### **Step 1: Prepare the Application on Source System**

```powershell
# Navigate to the project directory
cd c:\Anisble_App

# Stop running containers
docker compose down

# Clean up (optional - removes old images)
docker system prune -a
```

### **Step 2: Create a Portable Package**

**Option A: ZIP the entire folder**
```powershell
# Create a ZIP file (Windows)
Compress-Archive -Path "c:\Anisble_App" -DestinationPath "c:\AnsibleOps_Portable.zip"
```

**Option B: Copy to USB/Network Drive**
```powershell
# Copy entire folder
Copy-Item -Path "c:\Anisble_App" -Destination "D:\Backup\AnsibleOps" -Recurse
```

### **Step 3: Transfer to Target System**

- **USB Drive**: Copy ZIP file to USB, transfer to new system
- **Network**: Use shared folder or cloud storage (Google Drive, OneDrive)
- **Email**: If small enough (< 25MB after compression)

### **Step 4: Extract on Target System**

```powershell
# Extract ZIP (Windows)
Expand-Archive -Path "C:\Downloads\AnsibleOps_Portable.zip" -DestinationPath "C:\AnsibleOps"

# Or on Linux/Mac
unzip AnsibleOps_Portable.zip -d /home/user/AnsibleOps
```

### **Step 5: Run on Target System**

```powershell
# Navigate to extracted folder
cd C:\AnsibleOps

# Start the application
docker compose up --build -d

# Wait 1-2 minutes for containers to start, then access:
# http://localhost:5173
```

---

## 🌐 **Method 2: Transfer via Git (Recommended for Teams)**

### **Step 1: Initialize Git Repository (Source System)**

```bash
cd c:\Anisble_App

# Initialize git
git init

# Create .gitignore
echo "node_modules/" > .gitignore
echo "backend/artifacts/" >> .gitignore
echo "backend/env/" >> .gitignore
echo "__pycache__/" >> .gitignore
echo "*.pyc" >> .gitignore

# Add all files
git add .

# Commit
git commit -m "Initial commit - AnsibleOps Manager"
```

### **Step 2: Push to GitHub/GitLab**

```bash
# Create a new repository on GitHub, then:
git remote add origin https://github.com/YOUR_USERNAME/ansibleops-manager.git
git branch -M main
git push -u origin main
```

### **Step 3: Clone on Target System**

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/ansibleops-manager.git
cd ansibleops-manager

# Start the application
docker compose up --build -d
```

---

## 🐳 **Method 3: Docker Image Export (For Offline Transfer)**

### **Step 1: Build and Save Docker Images**

```powershell
# Build images
docker compose build

# Save images to tar files
docker save anisble_app-frontend:latest -o frontend.tar
docker save anisble_app-backend:latest -o backend.tar
docker save anisble_app-worker:latest -o worker.tar

# Save postgres and redis (if needed)
docker save postgres:15 -o postgres.tar
docker save redis:7-alpine -o redis.tar
```

### **Step 2: Transfer TAR Files**

Transfer all `.tar` files + `docker-compose.yml` + source code to target system

### **Step 3: Load Images on Target System**

```powershell
# Load images
docker load -i frontend.tar
docker load -i backend.tar
docker load -i worker.tar
docker load -i postgres.tar
docker load -i redis.tar

# Start application
docker compose up -d
```

---

## 🔧 **Post-Deployment Configuration**

### **1. Update Environment Variables (if needed)**

Edit `backend/.env`:
```env
DATABASE_URL=postgresql+asyncpg://postgres:postgres@postgres:5432/ansible_db
OPENAI_API_KEY=your-api-key-here  # If using AI features
```

### **2. Configure Ansible Inventory**

Edit `backend/inventory/hosts`:
```ini
[servers]
server1 ansible_host=192.168.1.10 ansible_user=admin
server2 ansible_host=192.168.1.11 ansible_user=admin

[all:vars]
ansible_python_interpreter=/usr/bin/python3
```

### **3. Upload Master Playbook**

1. Login to the application
2. Go to **Ansible** tab
3. Upload your `site.yml` master playbook

---

## ✅ **Verification Checklist**

After deployment on the new system, verify:

- [ ] **Frontend accessible**: http://localhost:5173
- [ ] **Backend API docs**: http://localhost:8000/docs
- [ ] **Login works**: Use `admin / admin123`
- [ ] **Database connected**: Check Dashboard loads
- [ ] **Containers running**: `docker compose ps` shows all UP
- [ ] **Logs clean**: `docker compose logs` shows no errors

---

## 🐛 **Troubleshooting**

### **Issue: Containers won't start**
```powershell
# Check logs
docker compose logs backend
docker compose logs frontend

# Rebuild from scratch
docker compose down -v
docker compose up --build -d
```

### **Issue: Port already in use**
```powershell
# Find process using port 5173
netstat -ano | findstr :5173

# Kill the process (Windows)
taskkill /PID <PID> /F

# Or change port in docker-compose.yml
```

### **Issue: Database connection failed**
```powershell
# Reset database
docker compose down -v  # WARNING: Deletes all data
docker compose up -d
```

### **Issue: Permission denied (Linux)**
```bash
# Fix permissions
sudo chown -R $USER:$USER /path/to/AnsibleOps
chmod -R 755 /path/to/AnsibleOps
```

---

## 🔐 **Security Recommendations for Production**

### **1. Change Default Passwords**

Edit `backend/app/core/auth.py`:
```python
fake_users_db = {
    "admin": {
        "password": "YOUR_STRONG_PASSWORD_HERE"  # Change this!
    }
}
```

### **2. Update Secret Keys**

Edit `backend/app/core/auth.py`:
```python
SECRET_KEY = "your-production-secret-key-min-32-chars"  # Change this!
```

### **3. Configure HTTPS (Production)**

Update `docker-compose.yml` to use nginx with SSL certificates.

### **4. Restrict CORS**

Edit `backend/app/main.py`:
```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://your-domain.com"],  # Specific domain only
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

---

## 📊 **Backup & Restore**

### **Backup Database**
```bash
# Backup
docker compose exec postgres pg_dump -U postgres ansible_db > backup.sql

# Restore
docker compose exec -T postgres psql -U postgres ansible_db < backup.sql
```

### **Backup Entire Application**
```bash
# Stop containers
docker compose down

# Backup everything
tar -czf ansibleops_backup_$(date +%Y%m%d).tar.gz /path/to/AnsibleOps

# Restore
tar -xzf ansibleops_backup_20231202.tar.gz -C /restore/path
```

---

## 🌍 **Remote Access Setup (Optional)**

### **Option 1: Ngrok (Quick Testing)**
```bash
# Install ngrok
# https://ngrok.com/download

# Expose frontend
ngrok http 5173

# Share the generated URL
```

### **Option 2: Cloud Deployment (AWS/Azure/GCP)**

1. **Provision VM** (Ubuntu 22.04, 2 vCPU, 4GB RAM)
2. **Install Docker** on VM
3. **Transfer application** using Method 2 (Git)
4. **Configure firewall** to allow ports 5173, 8000
5. **Set up domain** and SSL certificate
6. **Run** `docker compose up -d`

---

## 📞 **Support**

**Default Login Credentials:**
- Admin: `admin / admin123`
- Operator: `operator / operator123`
- Viewer: `viewer / viewer123`

**Ports:**
- Frontend: 5173
- Backend API: 8000
- PostgreSQL: 5432
- PgAdmin: 5050 (admin@admin.com / admin)

**Useful Commands:**
```bash
# View logs
docker compose logs -f

# Restart services
docker compose restart

# Stop everything
docker compose down

# Remove everything (including data)
docker compose down -v
```

---

## 🎯 **Quick Start Summary**

**For most users, the simplest method is:**

1. **ZIP the folder** on source system
2. **Transfer ZIP** to target system
3. **Extract** the ZIP
4. **Run** `docker compose up --build -d`
5. **Access** http://localhost:5173
6. **Login** with `admin / admin123`

**That's it!** 🚀

---

**Need help?** Check the logs with `docker compose logs` or rebuild with `docker compose up --build -d`
