import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from '@/components/Layout';
import Dashboard from '@/pages/Dashboard';
import Maintenance from '@/pages/Maintenance';
import Patching from '@/pages/Patching';
import Software from '@/pages/Software';
import Ansible from '@/pages/Ansible';
import AIPlaybook from '@/pages/AIPlaybook';
import PredictiveAnalytics from '@/pages/PredictiveAnalytics';
import JobScheduler from '@/pages/JobScheduler';
import Reports from '@/pages/Reports';
import ErrorBoundary from '@/components/ErrorBoundary';
import Login from '@/pages/Login';
import api from '@/lib/api';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if user is already logged in
    const token = localStorage.getItem('token');
    const role = localStorage.getItem('role');

    if (token) {
      // Set auth header for all requests
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      setIsAuthenticated(true);
      setUserRole(role);
    }
    setLoading(false);
  }, []);

  const handleLoginSuccess = (data) => {
    setIsAuthenticated(true);
    setUserRole(data.role);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('username');
    delete api.defaults.headers.common['Authorization'];
    setIsAuthenticated(false);
    setUserRole(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0f172a] flex items-center justify-center">
        <div className="text-slate-400">Loading...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Login onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <ErrorBoundary>
      <Router>
        <Layout userRole={userRole} onLogout={handleLogout}>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/analytics" element={<PredictiveAnalytics />} />
            <Route path="/scheduler" element={<JobScheduler />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/maintenance" element={<Maintenance />} />
            <Route path="/patching" element={<Patching />} />
            <Route path="/software" element={<Software />} />
            <Route path="/ansible" element={<Ansible />} />
            <Route path="/ai" element={<AIPlaybook />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Layout>
      </Router>
    </ErrorBoundary>
  );
}

export default App;
