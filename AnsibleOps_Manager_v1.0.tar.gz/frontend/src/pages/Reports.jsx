import React, { useState, useEffect } from 'react';
import api from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, Download, Calendar, Server, Loader2 } from 'lucide-react';

const Reports = () => {
    const [hosts, setHosts] = useState([]);
    const [selectedHost, setSelectedHost] = useState('localhost');
    const [days, setDays] = useState(7);
    const [loading, setLoading] = useState(false);
    const [summary, setSummary] = useState(null);

    useEffect(() => {
        fetchHosts();
        fetchSummary();
    }, []);

    const fetchHosts = async () => {
        try {
            const res = await api.get('/system/hosts');
            setHosts(res.data);
            if (res.data.length > 0) {
                setSelectedHost(res.data[0].hostname);
            }
        } catch (error) {
            console.error('Failed to fetch hosts', error);
        }
    };

    const fetchSummary = async () => {
        setLoading(true);
        try {
            const res = await api.get(`/reports/summary?days=${days}`);
            setSummary(res.data);
        } catch (error) {
            console.error('Failed to fetch summary', error);
        } finally {
            setLoading(false);
        }
    };

    const downloadPDF = async () => {
        try {
            const response = await api.get(`/reports/export/metrics/pdf?host=${selectedHost}&days=${days}`, {
                responseType: 'blob'
            });

            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', `metrics_report_${selectedHost}_${new Date().toISOString().split('T')[0]}.pdf`);
            document.body.appendChild(link);
            link.click();
            link.remove();
        } catch (error) {
            alert('Failed to generate PDF report');
        }
    };

    const downloadCSV = async () => {
        try {
            const response = await api.get(`/reports/export/metrics/csv?host=${selectedHost}&days=${days}`, {
                responseType: 'blob'
            });

            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', `metrics_${selectedHost}_${new Date().toISOString().split('T')[0]}.csv`);
            document.body.appendChild(link);
            link.click();
            link.remove();
        } catch (error) {
            alert('Failed to generate CSV export');
        }
    };

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold text-slate-100">Reports & Export</h1>
                <p className="text-slate-400 mt-1">Generate professional reports and export data</p>
            </div>

            {/* Export Controls */}
            <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                <CardHeader>
                    <CardTitle>Generate Report</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid grid-cols-3 gap-4">
                        <div>
                            <label className="text-sm font-medium text-slate-300">Select Server</label>
                            <select
                                value={selectedHost}
                                onChange={(e) => setSelectedHost(e.target.value)}
                                className="w-full bg-[#0f172a] border border-slate-600 rounded-md px-3 py-2 text-sm text-slate-200 mt-1"
                            >
                                {hosts.map(host => (
                                    <option key={host.hostname} value={host.hostname}>
                                        {host.hostname} ({host.ip})
                                    </option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label className="text-sm font-medium text-slate-300">Time Period</label>
                            <select
                                value={days}
                                onChange={(e) => setDays(Number(e.target.value))}
                                className="w-full bg-[#0f172a] border border-slate-600 rounded-md px-3 py-2 text-sm text-slate-200 mt-1"
                            >
                                <option value={1}>Last 24 Hours</option>
                                <option value={7}>Last 7 Days</option>
                                <option value={30}>Last 30 Days</option>
                                <option value={90}>Last 90 Days</option>
                            </select>
                        </div>
                        <div className="flex items-end gap-2">
                            <Button onClick={downloadPDF} className="bg-red-600 hover:bg-red-700 flex-1">
                                <FileText className="mr-2 h-4 w-4" />
                                PDF Report
                            </Button>
                            <Button onClick={downloadCSV} className="bg-green-600 hover:bg-green-700 flex-1">
                                <Download className="mr-2 h-4 w-4" />
                                CSV Export
                            </Button>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Summary Report */}
            <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle>Infrastructure Summary Report</CardTitle>
                    <Button onClick={fetchSummary} variant="outline" size="sm" className="border-slate-600 hover:bg-slate-700">
                        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Calendar className="h-4 w-4" />}
                        <span className="ml-2">Refresh</span>
                    </Button>
                </CardHeader>
                <CardContent>
                    {loading ? (
                        <div className="flex items-center justify-center py-12">
                            <Loader2 className="h-8 w-8 animate-spin text-blue-400" />
                        </div>
                    ) : summary ? (
                        <div className="space-y-6">
                            {/* Overview Stats */}
                            <div className="grid grid-cols-3 gap-4">
                                <div className="p-4 bg-[#0f172a] rounded-lg border border-slate-700">
                                    <div className="text-sm text-slate-400">Total Hosts</div>
                                    <div className="text-3xl font-bold text-blue-400 mt-1">{summary.total_hosts}</div>
                                </div>
                                <div className="p-4 bg-[#0f172a] rounded-lg border border-slate-700">
                                    <div className="text-sm text-slate-400">Data Points</div>
                                    <div className="text-3xl font-bold text-green-400 mt-1">{summary.total_data_points}</div>
                                </div>
                                <div className="p-4 bg-[#0f172a] rounded-lg border border-slate-700">
                                    <div className="text-sm text-slate-400">Period</div>
                                    <div className="text-3xl font-bold text-purple-400 mt-1">{summary.period_days}d</div>
                                </div>
                            </div>

                            {/* Host Details */}
                            <div>
                                <h3 className="text-lg font-semibold text-slate-200 mb-3">Host Performance Summary</h3>
                                <div className="overflow-x-auto">
                                    <table className="w-full text-sm">
                                        <thead className="bg-[#0f172a] text-slate-400">
                                            <tr>
                                                <th className="px-4 py-3 text-left">Host</th>
                                                <th className="px-4 py-3 text-center">Avg CPU</th>
                                                <th className="px-4 py-3 text-center">Avg Memory</th>
                                                <th className="px-4 py-3 text-center">Avg Disk</th>
                                                <th className="px-4 py-3 text-center">Max CPU</th>
                                                <th className="px-4 py-3 text-center">Health</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {summary.hosts.map((host, idx) => (
                                                <tr key={idx} className="border-b border-slate-700 hover:bg-[#334155]">
                                                    <td className="px-4 py-3 font-medium text-slate-200">{host.host}</td>
                                                    <td className="px-4 py-3 text-center">{host.avg_cpu}%</td>
                                                    <td className="px-4 py-3 text-center">{host.avg_memory}%</td>
                                                    <td className="px-4 py-3 text-center">{host.avg_disk}%</td>
                                                    <td className="px-4 py-3 text-center">{host.max_cpu}%</td>
                                                    <td className="px-4 py-3 text-center">
                                                        <span className={`px-2 py-1 rounded-full text-xs ${host.avg_cpu < 70 && host.avg_memory < 70 && host.avg_disk < 80
                                                                ? 'bg-green-500/20 text-green-400'
                                                                : host.avg_cpu < 90 && host.avg_memory < 90 && host.avg_disk < 90
                                                                    ? 'bg-yellow-500/20 text-yellow-400'
                                                                    : 'bg-red-500/20 text-red-400'
                                                            }`}>
                                                            {host.avg_cpu < 70 && host.avg_memory < 70 && host.avg_disk < 80
                                                                ? 'Healthy'
                                                                : host.avg_cpu < 90 && host.avg_memory < 90 && host.avg_disk < 90
                                                                    ? 'Warning'
                                                                    : 'Critical'}
                                                        </span>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    ) : (
                        <div className="text-center py-12 text-slate-400">
                            Click refresh to load summary report
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
};

export default Reports;
