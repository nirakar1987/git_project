import React, { useState, useEffect } from 'react';
import api from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Package, Trash, Plus, Loader2 } from 'lucide-react';

const Software = () => {
    const [packages, setPackages] = useState([]);
    const [newPackage, setNewPackage] = useState("");
    const [loading, setLoading] = useState(false);
    const [fetchingPackages, setFetchingPackages] = useState(false);
    const [removingPackage, setRemovingPackage] = useState(null);

    const fetchPackages = async () => {
        setFetchingPackages(true);
        try {
            const res = await api.get('/system/package/list');
            setPackages(res.data);
        } catch (error) {
            console.error(error);
        } finally {
            setFetchingPackages(false);
        }
    };

    useEffect(() => {
        fetchPackages();
    }, []);

    const installPackage = async () => {
        if (!newPackage) return;
        setLoading(true);
        try {
            // Use master playbook with software tag
            await api.post('/system/master/run', {
                tags: 'software',
                extra_vars: {
                    software_action: 'install',
                    package_name: newPackage
                }
            });
            setNewPackage("");
            alert(`Installation of ${newPackage} started via Master Playbook`);
            fetchPackages(); // Refresh list
        } catch (error) {
            alert(`Failed to install: ${error.response?.data?.detail || error.message}`);
        } finally {
            setLoading(false);
        }
    };

    const removePackage = async (name) => {
        if (!confirm(`Remove ${name}?`)) return;
        setRemovingPackage(name);
        try {
            // Use master playbook with software tag
            await api.post('/system/master/run', {
                tags: 'software',
                extra_vars: {
                    software_action: 'remove',
                    package_name: name
                }
            });
            alert(`Removal of ${name} started via Master Playbook`);
            fetchPackages(); // Refresh list
        } catch (error) {
            alert(`Failed to remove: ${error.response?.data?.detail || error.message}`);
        } finally {
            setRemovingPackage(null);
        }
    };

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold text-slate-100">Software Manager</h1>
                <p className="text-slate-400 mt-1">Install and manage packages using Master Playbook</p>
            </div>

            <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                <CardHeader>
                    <CardTitle>Install New Package</CardTitle>
                </CardHeader>
                <CardContent className="flex gap-4">
                    <Input
                        placeholder="Package name (e.g. nginx)"
                        value={newPackage}
                        onChange={(e) => setNewPackage(e.target.value)}
                        className="bg-[#0f172a] border-slate-600 text-slate-200"
                        disabled={loading}
                    />
                    <Button onClick={installPackage} disabled={loading || !newPackage} className="bg-blue-600 hover:bg-blue-700">
                        {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Plus className="mr-2 h-4 w-4" />}
                        Install
                    </Button>
                </CardContent>
            </Card>

            <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                <CardHeader>
                    <CardTitle>Installed Packages</CardTitle>
                </CardHeader>
                <CardContent>
                    {fetchingPackages ? (
                        <div className="flex items-center justify-center py-12">
                            <Loader2 className="h-8 w-8 animate-spin text-blue-400" />
                            <span className="ml-3 text-slate-400">Loading packages...</span>
                        </div>
                    ) : (
                        <div className="space-y-2">
                            {packages.map((pkg, i) => (
                                <div key={i} className="flex justify-between items-center p-3 border border-slate-700 rounded-md bg-[#0f172a] hover:border-slate-600 transition-colors">
                                    <div className="flex items-center gap-3">
                                        <Package className="h-5 w-5 text-slate-400" />
                                        <div>
                                            <div className="font-medium text-slate-200">{pkg.name}</div>
                                            <div className="text-xs text-slate-400">v{pkg.version}</div>
                                        </div>
                                    </div>
                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => removePackage(pkg.name)}
                                        disabled={removingPackage === pkg.name}
                                        className="hover:bg-red-500/10"
                                    >
                                        {removingPackage === pkg.name ? (
                                            <Loader2 className="h-4 w-4 text-red-400 animate-spin" />
                                        ) : (
                                            <Trash className="h-4 w-4 text-red-400" />
                                        )}
                                    </Button>
                                </div>
                            ))}
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
};

export default Software;
