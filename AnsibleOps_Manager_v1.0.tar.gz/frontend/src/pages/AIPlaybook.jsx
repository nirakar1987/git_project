import React, { useState } from 'react';
import api from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Sparkles, Save } from 'lucide-react';

const AIPlaybook = () => {
    const [prompt, setPrompt] = useState("");
    const [generated, setGenerated] = useState("");
    const [loading, setLoading] = useState(false);

    const generate = async () => {
        if (!prompt) return;
        setLoading(true);
        try {
            const res = await api.post('/playbook/generate', { prompt });
            setGenerated(res.data.content);
        } catch (error) {
            alert("Generation failed");
        } finally {
            setLoading(false);
        }
    };

    const save = async () => {
        if (!generated) return;
        const name = prompt.split(' ').slice(0, 3).join('_') + '.yml';
        try {
            await api.post('/playbook/upload', { name, content: generated });
            alert("Saved to library!");
        } catch (error) {
            alert("Failed to save");
        }
    };

    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold flex items-center gap-2">
                <Sparkles className="text-purple-500" />
                AI Playbook Generator
            </h1>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                    <CardHeader>
                        <CardTitle>Describe your task</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <textarea
                            className="flex min-h-[150px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                            placeholder="e.g. Install Docker and configure daemon.json with specific log driver..."
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                        />
                        <Button onClick={generate} disabled={loading} className="w-full bg-purple-600 hover:bg-purple-700">
                            {loading ? "Generating..." : "Generate Playbook"}
                        </Button>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle>Generated YAML</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <textarea
                            className="flex min-h-[400px] w-full rounded-md border border-input bg-muted px-3 py-2 text-sm font-mono"
                            value={generated}
                            onChange={(e) => setGenerated(e.target.value)}
                        />
                        <Button onClick={save} disabled={!generated} variant="outline" className="w-full">
                            <Save className="mr-2 h-4 w-4" />
                            Save to Library
                        </Button>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
};

export default AIPlaybook;
