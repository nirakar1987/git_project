import React, { useState, useEffect } from 'react';
import api from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Trash2, HardDrive, RefreshCw, Loader2 } from 'lucide-react';

const Maintenance = () => {
    const [systems, setSystems] = useState([]);
    const [output, setOutput] = useState("");
    const [loading, setLoading] = useState(false);
    const [cleaningHost, setCleaningHost] = useState(null);

    useEffect(() => {
        const fetchHosts = async () => {
            setLoading(true);
            try {
                const res = await api.get('/system/hosts');
                setSystems(res.data);
            } catch (error) {
                console.error("Failed to fetch hosts", error);
            } finally {
                setLoading(false);
            }
        };
        fetchHosts();
    }, []);

    const handleFetchMaster = async () => {
        setLoading(true);
        try {
            const res = await api.post('/system/discover/master');
            setSystems(res.data);
            alert("Systems discovered from Master Playbook!");
        } catch (error) {
            console.error("Discovery failed", error);
            alert("Failed to discover systems");
        } finally {
            setLoading(false);
        }
    };

    const runCleanup = async (type, host) => {
        setOutput(`Running ${type} cleanup on ${host || 'all hosts'}...`);
        setCleaningHost(host);
        try {
            const res = await api.post('/system/master/run', { tags: 'cleanup' });

            if (res.data && res.data.stdout) {
                setOutput(res.data.stdout);
            } else {
                setOutput(JSON.stringify(res.data, null, 2));
            }
        } catch (error) {
            setOutput(`Error: ${error.message}`);
        } finally {
            setCleaningHost(null);
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-3xl font-bold text-slate-100">System Maintenance</h1>
                <Button onClick={handleFetchMaster} disabled={loading} className="bg-blue-600 hover:bg-blue-700">
                    {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
                    Fetch Data (Master Playbook)
                </Button>
            </div>

            <div className="grid grid-cols-1 gap-6">
                <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                    <CardHeader>
                        <CardTitle>Discovered Systems</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {loading ? (
                            <div className="flex items-center justify-center py-12">
                                <Loader2 className="h-8 w-8 animate-spin text-blue-400" />
                                <span className="ml-3 text-slate-400">Loading systems...</span>
                            </div>
                        ) : (
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm text-left text-slate-300">
                                    <thead className="text-xs text-slate-400 uppercase bg-[#0f172a]">
                                        <tr>
                                            <th className="px-4 py-3">Hostname</th>
                                            <th className="px-4 py-3">IP Address</th>
                                            <th className="px-4 py-3">Disk Usage</th>
                                            <th className="px-4 py-3">Status</th>
                                            <th className="px-4 py-3">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {systems.map((sys, idx) => (
                                            <tr key={idx} className="border-b border-slate-700 hover:bg-[#334155]">
                                                <td className="px-4 py-3 font-medium text-white">{sys.hostname}</td>
                                                <td className="px-4 py-3">{sys.ip}</td>
                                                <td className="px-4 py-3">
                                                    <div className="flex items-center gap-2">
                                                        <HardDrive className="h-4 w-4 text-slate-400" />
                                                        <span>{sys.disk_free} / {sys.disk_total}</span>
                                                    </div>
                                                </td>
                                                <td className="px-4 py-3">
                                                    <span className={`px-2 py-1 rounded-full text-xs ${sys.status === 'online' ? 'bg-green-500/20 text-green-400' :
                                                            sys.status === 'warning' ? 'bg-yellow-500/20 text-yellow-400' :
                                                                'bg-red-500/20 text-red-400'
                                                        }`}>
                                                        {sys.status}
                                                    </span>
                                                </td>
                                                <td className="px-4 py-3">
                                                    <div className="flex gap-2">
                                                        <Button
                                                            size="xs"
                                                            variant="outline"
                                                            className="border-slate-600 hover:bg-slate-700"
                                                            onClick={() => runCleanup('logs', sys.hostname)}
                                                            disabled={cleaningHost === sys.hostname}
                                                        >
                                                            {cleaningHost === sys.hostname ? (
                                                                <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                                                            ) : (
                                                                <Trash2 className="h-3 w-3 mr-1" />
                                                            )}
                                                            Clean Logs
                                                        </Button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </CardContent>
                </Card>
            </div>

            <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                <CardHeader>
                    <CardTitle>Operation Output</CardTitle>
                </CardHeader>
                <CardContent>
                    <pre className="bg-[#0f172a] p-4 rounded-md overflow-auto h-64 text-sm font-mono text-green-400">
                        {output}
                    </pre>
                </CardContent>
            </Card>
        </div>
    );
};

export default Maintenance;
