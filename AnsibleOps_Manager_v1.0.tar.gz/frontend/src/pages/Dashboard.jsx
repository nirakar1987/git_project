import React, { useEffect, useState } from 'react';
import api from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import {
    RefreshCw, Smartphone, HardDrive, Activity, Network, Clock, Server,
    MoreVertical, Maximize2, ExternalLink, Home, ChevronRight
} from 'lucide-react';
import MetricExplorer from '@/components/dashboard/MetricExplorer';
import { ConfiguredPolicies, ActivePolicies } from '@/components/dashboard/Policies';

const Dashboard = () => {
    const [metrics, setMetrics] = useState(null);
    const [history, setHistory] = useState([]);
    const [loading, setLoading] = useState(false);
    const [discovering, setDiscovering] = useState(false);
    const [activeTab, setActiveTab] = useState('overview');
    const [hosts, setHosts] = useState([]);
    const [selectedHost, setSelectedHost] = useState(null);

    useEffect(() => {
        const fetchHosts = async () => {
            try {
                const res = await api.get('/system/hosts');
                setHosts(res.data);
                if (res.data.length > 0) {
                    setSelectedHost(res.data[0]);
                }
            } catch (error) {
                console.error("Failed to fetch hosts", error);
            }
        };
        fetchHosts();
    }, []);

    const fetchMetrics = async () => {
        if (!selectedHost) return;
        setLoading(true);
        try {
            const res = await api.get(`/metrics/latest?host=${selectedHost.hostname}`);
            setMetrics(res.data);
            const histRes = await api.get(`/metrics/history?host=${selectedHost.hostname}`);
            setHistory(histRes.data.reverse());
        } catch (error) {
            console.error("Failed to fetch metrics", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (selectedHost) {
            fetchMetrics();
            const interval = setInterval(fetchMetrics, 30000); // Poll every 30s
            return () => clearInterval(interval);
        }
    }, [selectedHost]);

    const handleFetchMaster = async () => {
        setDiscovering(true);
        try {
            // Use master playbook to fetch metrics
            const res = await api.post('/metrics/fetch/master');

            setMetrics(res.data);
            // Refresh history to include the new point
            const histRes = await api.get(`/metrics/history?host=${selectedHost?.hostname || 'localhost'}`);
            setHistory(histRes.data.reverse());
            alert("Metrics updated from Master Playbook!");
        } catch (error) {
            console.error("Fetch failed", error);
            alert("Failed to fetch metrics from Master Playbook");
        } finally {
            setDiscovering(false);
        }
    };

    // Mock data for charts if history is empty
    const chartData = history.length > 0 ? history : [
        { timestamp: '06:00', memory_percent: 20 },
        { timestamp: '07:00', memory_percent: 25 },
        { timestamp: '08:00', memory_percent: 22 },
        { timestamp: '09:00', memory_percent: 30 },
        { timestamp: '10:00', memory_percent: 28 },
    ];

    const availabilityData = [
        { name: 'Up', value: 89, color: '#4ade80' },
        { name: 'Down', value: 11, color: '#ef4444' },
    ];

    return (
        <div className="min-h-screen bg-[#0f172a] text-slate-300 font-sans p-4">
            {/* Top Navigation Mock */}
            <div className="flex gap-6 text-sm font-medium mb-4 border-b border-slate-700 pb-2">
                <span className="text-blue-400 border-b-2 border-blue-400 pb-2">Server & Apps</span>
                <span className="hover:text-white cursor-pointer">Network</span>
                <span className="hover:text-white cursor-pointer">Cloud</span>
                <span className="hover:text-white cursor-pointer">Service Check</span>
                <span className="hover:text-white cursor-pointer">Virtualization</span>
            </div>

            {/* Breadcrumb & Info Bar */}
            <div className="flex justify-between items-center bg-[#1e293b] p-3 rounded-t-lg border-b border-slate-700">
                <div className="flex items-center gap-2">
                    <ChevronRight className="h-4 w-4 text-slate-500" />
                    <Home className="h-4 w-4 text-blue-400" />
                    <ChevronRight className="h-4 w-4 text-slate-500" />
                    <div className="flex flex-col">
                        <select
                            className="bg-transparent text-white font-bold text-sm border-none focus:ring-0 cursor-pointer outline-none"
                            value={selectedHost?.hostname || ''}
                            onChange={(e) => {
                                const host = hosts.find(h => h.hostname === e.target.value);
                                setSelectedHost(host);
                            }}
                        >
                            {hosts.map(host => (
                                <option key={host.hostname} value={host.hostname} className="bg-[#1e293b] text-white">
                                    {host.hostname}
                                </option>
                            ))}
                        </select>
                        <span className="text-xs text-blue-400">
                            {selectedHost ? `${selectedHost.ip} | ${selectedHost.status}` : 'Select a server'}
                        </span>
                    </div>
                </div>
                <div className="flex items-center gap-3 text-xs text-slate-400">
                    <span>Last Poll : {new Date().toLocaleString()}</span>
                    <RefreshCw className={`h-4 w-4 cursor-pointer hover:text-white ${loading ? 'animate-spin' : ''}`} onClick={fetchMetrics} />
                    <ExternalLink className="h-4 w-4 cursor-pointer hover:text-white" />
                    <Maximize2 className="h-4 w-4 cursor-pointer hover:text-white" />
                </div>
            </div>

            {/* Sub Navigation */}
            <div className="bg-[#1e293b] p-2 flex gap-6 text-sm border-b border-slate-700 mb-4">
                <span
                    className={`cursor-pointer pb-1 ${activeTab === 'overview' ? 'text-white border-b-2 border-blue-500' : 'text-slate-400 hover:text-white'}`}
                    onClick={() => setActiveTab('overview')}
                >
                    Overview
                </span>
                <span
                    className={`cursor-pointer pb-1 ${activeTab === 'explorer' ? 'text-white border-b-2 border-blue-500' : 'text-slate-400 hover:text-white'}`}
                    onClick={() => setActiveTab('explorer')}
                >
                    Metric Explorer
                </span>
                <span
                    className={`cursor-pointer pb-1 ${activeTab === 'configured' ? 'text-white border-b-2 border-blue-500' : 'text-slate-400 hover:text-white'}`}
                    onClick={() => setActiveTab('configured')}
                >
                    Configured Policies
                </span>
                <span
                    className={`cursor-pointer pb-1 ${activeTab === 'active' ? 'text-white border-b-2 border-blue-500' : 'text-slate-400 hover:text-white'}`}
                    onClick={() => setActiveTab('active')}
                >
                    Active Policies
                </span>
            </div>

            {/* Fetch Data Section (Replaces Upload) */}
            <div className="bg-[#1e293b] p-4 mb-4 rounded-md border border-slate-700 flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-white">Update Metrics from Master Playbook:</span>
                </div>
                <Button size="sm" onClick={handleFetchMaster} disabled={discovering}>
                    {discovering ? 'Running Playbook...' : 'Fetch Data'}
                </Button>
            </div>

            {/* Content Area */}
            {activeTab === 'overview' && (
                <>
                    {/* Main Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4 mb-4">
                        {/* CPU */}
                        <MetricCard
                            icon={Smartphone}
                            title="CPU"
                            value={`${metrics?.cpu_percent || 0}%`}
                            subtext="User: 16% Interrupt: 0%"
                            progress={metrics?.cpu_percent || 0}
                            color="bg-blue-500"
                        />
                        {/* Memory */}
                        <MetricCard
                            icon={Server}
                            title="Memory"
                            value={`${metrics?.memory_percent || 0}%`}
                            subtext="Total: 8.4GB Free: 478.6MB"
                            progress={metrics?.memory_percent || 0}
                            color="bg-blue-500"
                        />
                        {/* Disk */}
                        <MetricCard
                            icon={HardDrive}
                            title="Disk"
                            value={`${metrics?.disk_percent || 0}%`}
                            subtext="Total: 146.5GB Free: 75.6GB"
                            progress={metrics?.disk_percent || 0}
                            color="bg-blue-500"
                        />
                        {/* IOPS */}
                        <SimpleMetricCard
                            icon={Activity}
                            title="IOPS"
                            value={metrics?.iops_read || "65.2"}
                            subtext="Disk Queue Length: 0.1"
                            color="text-blue-400"
                        />
                        {/* Network */}
                        <NetworkCard
                            icon={Network}
                            title="Network"
                            inVal="11.7kbps"
                            outVal="2.4kbps"
                        />
                        {/* Response Time */}
                        <SimpleMetricCard
                            icon={Clock}
                            title="Response Time"
                            value="0.7ms"
                            subtext="Lost Packets: 0"
                            color="text-blue-400"
                        />
                    </div>

                    {/* Bottom Row */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                        {/* Device Availability */}
                        <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                            <CardHeader className="pb-2">
                                <CardTitle className="text-sm font-medium">Device Availability</CardTitle>
                            </CardHeader>
                            <CardContent className="flex flex-col items-center justify-center h-[200px] relative">
                                <ResponsiveContainer width="100%" height="100%">
                                    <PieChart>
                                        <Pie
                                            data={availabilityData}
                                            innerRadius={60}
                                            outerRadius={80}
                                            paddingAngle={0}
                                            dataKey="value"
                                            startAngle={90}
                                            endAngle={-270}
                                        >
                                            {availabilityData.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={entry.color} />
                                            ))}
                                        </Pie>
                                    </PieChart>
                                </ResponsiveContainer>
                                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                                    <span className="text-xs text-slate-400">UP</span>
                                    <span className="text-2xl font-bold text-[#4ade80]">89%</span>
                                </div>
                                <div className="mt-2 text-xs text-slate-400">Availability (Today)</div>
                            </CardContent>
                        </Card>

                        {/* Availability Last 30 Days */}
                        <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                            <CardHeader className="pb-2">
                                <CardTitle className="text-sm font-medium">Availability Last 30 Days</CardTitle>
                            </CardHeader>
                            <CardContent className="flex flex-col justify-center h-[200px] space-y-6">
                                <AvailabilityBar label="7 Days" />
                                <AvailabilityBar label="15 Days" />
                                <AvailabilityBar label="30 Days" />
                            </CardContent>
                        </Card>

                        {/* Memory Details Chart */}
                        <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                            <CardHeader className="pb-2">
                                <CardTitle className="text-sm font-medium">Memory Details</CardTitle>
                                <div className="text-xs text-slate-400">13.97 GB</div>
                            </CardHeader>
                            <CardContent className="h-[200px]">
                                <ResponsiveContainer width="100%" height="100%">
                                    <LineChart data={chartData}>
                                        <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                                        <XAxis dataKey="timestamp" hide />
                                        <YAxis hide domain={[0, 100]} />
                                        <Tooltip
                                            contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155' }}
                                            itemStyle={{ color: '#cbd5e1' }}
                                        />
                                        <Line type="monotone" dataKey="memory_percent" stroke="#facc15" strokeWidth={2} dot={false} />
                                        <Line type="monotone" dataKey="cpu_percent" stroke="#4ade80" strokeWidth={2} dot={false} />
                                        <Line type="monotone" dataKey="disk_percent" stroke="#f97316" strokeWidth={2} dot={false} />
                                    </LineChart>
                                </ResponsiveContainer>
                                <div className="flex flex-wrap gap-2 mt-2 text-[10px] text-slate-400">
                                    <div className="flex items-center gap-1"><div className="w-2 h-2 bg-yellow-400 rounded-full"></div> system.memory.committed</div>
                                    <div className="flex items-center gap-1"><div className="w-2 h-2 bg-green-400 rounded-full"></div> system.cache.memory</div>
                                    <div className="flex items-center gap-1"><div className="w-2 h-2 bg-orange-400 rounded-full"></div> system.memory.used</div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </>
            )}

            {activeTab === 'explorer' && <MetricExplorer history={history} />}
            {activeTab === 'configured' && <ConfiguredPolicies />}
            {activeTab === 'active' && <ActivePolicies />}

        </div>
    );
};

// Components
const MetricCard = ({ icon: Icon, title, value, subtext, progress, color }) => (
    <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
        <CardContent className="p-4 flex flex-col h-full justify-between">
            <div className="flex justify-between items-start mb-2">
                <div className="p-2 bg-blue-900/30 rounded-lg">
                    <Icon className="h-6 w-6 text-blue-400" />
                </div>
            </div>
            <div>
                <div className="text-lg font-bold mb-1">{title}</div>
                <div className="text-[10px] text-slate-400 mb-2 whitespace-pre-wrap">{subtext}</div>
                <div className="h-1.5 w-full bg-slate-700 rounded-full overflow-hidden mb-2">
                    <div className={`h-full ${color}`} style={{ width: `${progress}%` }}></div>
                </div>
                <div className="text-2xl font-bold text-blue-400">{value}</div>
            </div>
        </CardContent>
    </Card>
);

const SimpleMetricCard = ({ icon: Icon, title, value, subtext, color }) => (
    <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
        <CardContent className="p-4 flex flex-col h-full justify-between">
            <div className="flex justify-between items-start mb-2">
                <div className="p-2 bg-blue-900/30 rounded-lg">
                    <Icon className="h-6 w-6 text-blue-400" />
                </div>
            </div>
            <div>
                <div className="text-lg font-bold mb-1">{title}</div>
                <div className="text-[10px] text-slate-400 mb-4">{subtext}</div>
                <div className={`text-2xl font-bold ${color}`}>{value}</div>
            </div>
        </CardContent>
    </Card>
);

const NetworkCard = ({ icon: Icon, title, inVal, outVal }) => (
    <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
        <CardContent className="p-4 flex flex-col h-full justify-between">
            <div className="flex justify-between items-start mb-2">
                <div className="p-2 bg-blue-900/30 rounded-lg">
                    <Icon className="h-6 w-6 text-blue-400" />
                </div>
            </div>
            <div>
                <div className="text-lg font-bold mb-1">{title}</div>
                <div className="text-[10px] text-slate-400 mb-2">Retransmissions: 29.7M</div>
                <div className="flex justify-between items-end">
                    <div>
                        <div className="text-[10px] text-slate-500">IN</div>
                        <div className="text-lg font-bold text-blue-400">{inVal}</div>
                    </div>
                    <div>
                        <div className="text-[10px] text-slate-500">OUT</div>
                        <div className="text-lg font-bold text-blue-400">{outVal}</div>
                    </div>
                </div>
            </div>
        </CardContent>
    </Card>
);

const AvailabilityBar = ({ label }) => (
    <div className="flex items-center gap-4">
        <span className="text-xs text-slate-400 w-12">{label}</span>
        <div className="flex-1 h-4 bg-slate-700 rounded-full overflow-hidden flex">
            <div className="h-full bg-[#4ade80] w-[90%]"></div>
            <div className="h-full bg-[#ef4444] w-[10%]"></div>
        </div>
    </div>
);

export default Dashboard;
