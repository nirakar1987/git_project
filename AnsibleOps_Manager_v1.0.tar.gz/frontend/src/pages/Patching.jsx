import React, { useState, useEffect } from 'react';
import api from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ShieldCheck, Download, Loader2, CheckSquare, Square } from 'lucide-react';

const Patching = () => {
    const [status, setStatus] = useState(null);
    const [output, setOutput] = useState("");
    const [loading, setLoading] = useState(false);
    const [hosts, setHosts] = useState([]);
    const [selectedHosts, setSelectedHosts] = useState([]);
    const [fetchingHosts, setFetchingHosts] = useState(false);

    useEffect(() => {
        fetchHosts();
    }, []);

    const fetchHosts = async () => {
        setFetchingHosts(true);
        try {
            const res = await api.get('/system/hosts');
            setHosts(res.data);
        } catch (error) {
            console.error("Failed to fetch hosts", error);
        } finally {
            setFetchingHosts(false);
        }
    };

    const toggleHost = (hostname) => {
        setSelectedHosts(prev =>
            prev.includes(hostname)
                ? prev.filter(h => h !== hostname)
                : [...prev, hostname]
        );
    };

    const toggleAll = () => {
        if (selectedHosts.length === hosts.length) {
            setSelectedHosts([]);
        } else {
            setSelectedHosts(hosts.map(h => h.hostname));
        }
    };

    const checkUpdates = async () => {
        if (selectedHosts.length === 0) {
            alert("Please select at least one server");
            return;
        }

        setLoading(true);
        setOutput(`Checking updates on ${selectedHosts.length} server(s)...\n`);

        try {
            // Run master playbook with patch tag and check action
            const res = await api.post('/system/master/run', {
                tags: 'patch',
                extra_vars: {
                    patch_action: 'check',
                    target_hosts: selectedHosts.join(',')
                }
            });

            setOutput(res.data.stdout || JSON.stringify(res.data, null, 2));
            setStatus({
                status: "Check Complete",
                count: `${selectedHosts.length} servers checked`
            });
        } catch (error) {
            setOutput(`Error: ${error.response?.data?.detail || error.message}`);
        } finally {
            setLoading(false);
        }
    };

    const applyUpdates = async () => {
        if (selectedHosts.length === 0) {
            alert("Please select at least one server");
            return;
        }

        if (!confirm(`Apply patches to ${selectedHosts.length} server(s)? This may take several minutes.`)) {
            return;
        }

        setLoading(true);
        setOutput(`Applying updates to ${selectedHosts.length} server(s)... This may take a while.\n`);

        try {
            const res = await api.post('/system/master/run', {
                tags: 'patch',
                extra_vars: {
                    patch_action: 'apply',
                    target_hosts: selectedHosts.join(',')
                }
            });
            setOutput(res.data.stdout || JSON.stringify(res.data, null, 2));
            setStatus({
                status: "Patching Complete",
                count: `${selectedHosts.length} servers updated`
            });
        } catch (error) {
            setOutput(`Error: ${error.response?.data?.detail || error.message}`);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-slate-100">OS Patching</h1>
                    <p className="text-slate-400 mt-1">Bulk patch management for multiple servers</p>
                </div>
                <div className="flex gap-2">
                    <Button onClick={checkUpdates} disabled={loading || selectedHosts.length === 0} variant="outline" className="border-slate-600 hover:bg-slate-700">
                        {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ShieldCheck className="mr-2 h-4 w-4" />}
                        Check for Updates
                    </Button>
                    <Button onClick={applyUpdates} disabled={loading || selectedHosts.length === 0} className="bg-blue-600 hover:bg-blue-700">
                        {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Download className="mr-2 h-4 w-4" />}
                        Apply Patches
                    </Button>
                </div>
            </div>

            {/* Server Selection */}
            <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                        <span>Select Servers ({selectedHosts.length} of {hosts.length} selected)</span>
                        <Button
                            size="sm"
                            variant="outline"
                            onClick={toggleAll}
                            className="border-slate-600 hover:bg-slate-700"
                        >
                            {selectedHosts.length === hosts.length ? 'Deselect All' : 'Select All'}
                        </Button>
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    {fetchingHosts ? (
                        <div className="flex items-center justify-center py-8">
                            <Loader2 className="h-6 w-6 animate-spin text-blue-400" />
                            <span className="ml-2 text-slate-400">Loading servers...</span>
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                            {hosts.map((host) => (
                                <div
                                    key={host.hostname}
                                    onClick={() => toggleHost(host.hostname)}
                                    className={`
                                        p-4 rounded-lg border-2 cursor-pointer transition-all
                                        ${selectedHosts.includes(host.hostname)
                                            ? 'border-blue-500 bg-blue-500/10'
                                            : 'border-slate-700 bg-[#0f172a] hover:border-slate-600'
                                        }
                                    `}
                                >
                                    <div className="flex items-start justify-between">
                                        <div className="flex-1">
                                            <div className="font-medium text-slate-200">{host.hostname}</div>
                                            <div className="text-xs text-slate-400 mt-1">{host.ip}</div>
                                            <div className={`text-xs mt-2 px-2 py-1 rounded-full inline-block ${host.status === 'online' ? 'bg-green-500/20 text-green-400' :
                                                    host.status === 'warning' ? 'bg-yellow-500/20 text-yellow-400' :
                                                        'bg-red-500/20 text-red-400'
                                                }`}>
                                                {host.status}
                                            </div>
                                        </div>
                                        <div>
                                            {selectedHosts.includes(host.hostname) ? (
                                                <CheckSquare className="h-5 w-5 text-blue-400" />
                                            ) : (
                                                <Square className="h-5 w-5 text-slate-600" />
                                            )}
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </CardContent>
            </Card>

            {status && (
                <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                    <CardHeader>
                        <CardTitle>Update Status</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-lg font-medium text-slate-200">{status.status}</div>
                        <div className="text-sm text-slate-400 mt-1">{status.count}</div>
                    </CardContent>
                </Card>
            )}

            <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                <CardHeader>
                    <CardTitle>Console Output</CardTitle>
                </CardHeader>
                <CardContent>
                    <pre className="bg-[#0f172a] p-4 rounded-md overflow-auto h-96 text-sm font-mono text-green-400">
                        {output || "Ready to patch. Select servers and click 'Check for Updates' or 'Apply Patches'."}
                    </pre>
                </CardContent>
            </Card>
        </div>
    );
};

export default Patching;
