import React, { useState, useEffect } from 'react';
import api from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { TrendingUp, TrendingDown, Minus, AlertTriangle, CheckCircle2, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';

const PredictiveAnalytics = () => {
    const [hosts, setHosts] = useState([]);
    const [selectedHost, setSelectedHost] = useState(null);
    const [predictions, setPredictions] = useState(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        fetchHosts();
    }, []);

    const fetchHosts = async () => {
        try {
            const res = await api.get('/system/hosts');
            setHosts(res.data);
            if (res.data.length > 0) {
                setSelectedHost(res.data[0].hostname);
            }
        } catch (error) {
            console.error("Failed to fetch hosts", error);
        }
    };

    const fetchPredictions = async () => {
        if (!selectedHost) return;

        setLoading(true);
        try {
            const res = await api.get(`/metrics/predictions/${selectedHost}`);
            setPredictions(res.data);
        } catch (error) {
            console.error("Failed to fetch predictions", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (selectedHost) {
            fetchPredictions();
        }
    }, [selectedHost]);

    const getTrendIcon = (trend) => {
        if (trend === 'increasing') return <TrendingUp className="h-5 w-5 text-red-400" />;
        if (trend === 'decreasing') return <TrendingDown className="h-5 w-5 text-green-400" />;
        return <Minus className="h-5 w-5 text-slate-400" />;
    };

    const getStatusColor = (daysUntilFull) => {
        if (!daysUntilFull) return 'text-green-400';
        if (daysUntilFull < 7) return 'text-red-400';
        if (daysUntilFull < 30) return 'text-yellow-400';
        return 'text-green-400';
    };

    const renderPredictionCard = (title, data, color) => {
        if (!data || data.status === 'insufficient_data') {
            return (
                <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                    <CardHeader>
                        <CardTitle className="text-lg">{title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-slate-400 text-sm">Insufficient data for prediction. Collect more metrics.</p>
                    </CardContent>
                </Card>
            );
        }

        const chartData = data.predicted_usage.map(p => ({
            hours: p.hours_from_now,
            value: p.predicted_value,
            label: `${Math.floor(p.hours_from_now / 24)}d ${p.hours_from_now % 24}h`
        }));

        return (
            <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                        <span className="text-lg">{title}</span>
                        {getTrendIcon(data.trend)}
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <div className="text-xs text-slate-400">Current Usage</div>
                            <div className="text-2xl font-bold" style={{ color }}>{data.current_usage}%</div>
                        </div>
                        <div>
                            <div className="text-xs text-slate-400">Days Until Critical</div>
                            <div className={`text-2xl font-bold ${getStatusColor(data.days_until_full)}`}>
                                {data.days_until_full ? `${data.days_until_full}d` : '∞'}
                            </div>
                        </div>
                    </div>

                    <div className="h-48">
                        <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={chartData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                <XAxis
                                    dataKey="hours"
                                    tickFormatter={(value) => `${Math.floor(value / 24)}d`}
                                    stroke="#94a3b8"
                                    style={{ fontSize: '12px' }}
                                />
                                <YAxis
                                    domain={[0, 100]}
                                    stroke="#94a3b8"
                                    style={{ fontSize: '12px' }}
                                />
                                <Tooltip
                                    contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155' }}
                                    labelStyle={{ color: '#cbd5e1' }}
                                    itemStyle={{ color: color }}
                                />
                                <ReferenceLine y={95} stroke="#ef4444" strokeDasharray="3 3" label={{ value: 'Critical', fill: '#ef4444', fontSize: 10 }} />
                                <Line
                                    type="monotone"
                                    dataKey="value"
                                    stroke={color}
                                    strokeWidth={2}
                                    dot={false}
                                    name="Predicted Usage"
                                />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>

                    <div className={`p-3 rounded-md ${data.days_until_full && data.days_until_full < 7
                            ? 'bg-red-500/10 border border-red-500/30'
                            : data.days_until_full && data.days_until_full < 30
                                ? 'bg-yellow-500/10 border border-yellow-500/30'
                                : 'bg-green-500/10 border border-green-500/30'
                        }`}>
                        <div className="flex items-start gap-2">
                            {data.days_until_full && data.days_until_full < 7 ? (
                                <AlertTriangle className="h-5 w-5 text-red-400 flex-shrink-0 mt-0.5" />
                            ) : (
                                <CheckCircle2 className="h-5 w-5 text-green-400 flex-shrink-0 mt-0.5" />
                            )}
                            <p className="text-sm text-slate-200">{data.recommendation}</p>
                        </div>
                    </div>

                    <div className="text-xs text-slate-500">
                        Growth Rate: {data.growth_rate_per_day > 0 ? '+' : ''}{data.growth_rate_per_day}% per day
                    </div>
                </CardContent>
            </Card>
        );
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-slate-100">Predictive Analytics</h1>
                    <p className="text-slate-400 mt-1">AI-powered resource forecasting and trend analysis</p>
                </div>
                <Button onClick={fetchPredictions} disabled={loading} className="bg-blue-600 hover:bg-blue-700">
                    <RefreshCw className={`mr-2 h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
                    Refresh Predictions
                </Button>
            </div>

            <div className="flex items-center gap-4 bg-[#1e293b] p-4 rounded-lg border border-slate-700">
                <label className="text-sm font-medium text-slate-200">Select Server:</label>
                <select
                    className="bg-[#0f172a] text-slate-200 border border-slate-600 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={selectedHost || ''}
                    onChange={(e) => setSelectedHost(e.target.value)}
                >
                    {hosts.map(host => (
                        <option key={host.hostname} value={host.hostname}>
                            {host.hostname} ({host.ip})
                        </option>
                    ))}
                </select>
            </div>

            {predictions && (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {renderPredictionCard('Disk Usage Forecast', predictions.disk, '#3b82f6')}
                    {renderPredictionCard('Memory Usage Forecast', predictions.memory, '#8b5cf6')}
                    {renderPredictionCard('CPU Usage Forecast', predictions.cpu, '#10b981')}
                </div>
            )}

            {!predictions && !loading && (
                <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                    <CardContent className="p-12 text-center">
                        <p className="text-slate-400">Select a server to view predictive analytics</p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
};

export default PredictiveAnalytics;
