import React, { useState, useEffect } from 'react';
import api from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Play, Upload } from 'lucide-react';

const Ansible = () => {
    const [content, setContent] = useState("");
    const [file, setFile] = useState(null);

    const handleFileChange = (e) => {
        if (e.target.files) {
            const selectedFile = e.target.files[0];
            setFile(selectedFile);
            // Preview content
            const reader = new FileReader();
            reader.onload = (e) => setContent(e.target.result);
            reader.readAsText(selectedFile);
        }
    };

    const handleUpload = async () => {
        if (!file && !content) {
            alert("Please select a file or paste content");
            return;
        }

        try {
            const formData = new FormData();
            if (file) {
                // Use the selected file directly
                formData.append('file', file);
            } else {
                // Create file from text content
                const blob = new Blob([content], { type: 'text/yaml' });
                const f = new File([blob], "site.yml", { type: "text/yaml" });
                formData.append('file', f);
            }

            await api.post('/system/master/upload', formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });

            alert("Master Playbook uploaded successfully!");
            // setContent(""); // Keep content for visibility
        } catch (error) {
            alert("Upload failed");
            console.error(error);
        }
    };

    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold text-slate-100">Ansible Automation</h1>
            <p className="text-slate-400">Upload your Master Playbook (site.yml) here. This playbook will be used across the Dashboard, Maintenance, and other tabs to fetch data and perform tasks.</p>

            <div className="grid grid-cols-1 gap-6">
                <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                    <CardHeader>
                        <CardTitle>Upload Master Playbook (site.yml)</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="flex items-center gap-4 p-4 border border-slate-600 rounded-md bg-[#0f172a]">
                            <Upload className="h-5 w-5 text-blue-400" />
                            <input
                                type="file"
                                accept=".yml,.yaml"
                                onChange={handleFileChange}
                                className="text-sm text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-500/10 file:text-blue-400 hover:file:bg-blue-500/20"
                            />
                        </div>

                        <div className="text-xs text-slate-500 uppercase font-bold text-center">OR Paste Content Below</div>

                        <textarea
                            className="flex min-h-[400px] w-full rounded-md border border-slate-600 bg-[#0f172a] px-3 py-2 text-sm font-mono text-slate-200 placeholder:text-slate-500"
                            placeholder="Paste your Master Playbook YAML content here..."
                            value={content}
                            onChange={(e) => {
                                setContent(e.target.value);
                                setFile(null); // Clear file if manually editing
                            }}
                        />
                        <Button onClick={handleUpload} className="w-full bg-blue-600 hover:bg-blue-700">
                            <Upload className="mr-2 h-4 w-4" />
                            Save Master Playbook
                        </Button>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
};

export default Ansible;
