import React, { useState, useEffect } from 'react';
import api from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Clock, Play, Pause, Trash2, Plus, Loader2, Calendar, CheckCircle2, XCircle } from 'lucide-react';

const JobScheduler = () => {
    const [jobs, setJobs] = useState([]);
    const [executions, setExecutions] = useState([]);
    const [loading, setLoading] = useState(false);
    const [showCreateForm, setShowCreateForm] = useState(false);
    const [newJob, setNewJob] = useState({
        name: '',
        description: '',
        playbook_tags: 'cleanup',
        schedule_type: 'daily',
        schedule_value: '02:00',
        target_hosts: 'all',
        extra_vars: '{}',
        enabled: true
    });

    useEffect(() => {
        fetchJobs();
        fetchRecentExecutions();
    }, []);

    const fetchJobs = async () => {
        setLoading(true);
        try {
            const res = await api.get('/scheduler/jobs');
            setJobs(res.data);
        } catch (error) {
            console.error('Failed to fetch jobs', error);
        } finally {
            setLoading(false);
        }
    };

    const fetchRecentExecutions = async () => {
        try {
            const res = await api.get('/scheduler/executions/recent?limit=10');
            setExecutions(res.data);
        } catch (error) {
            console.error('Failed to fetch executions', error);
        }
    };

    const createJob = async () => {
        try {
            await api.post('/scheduler/jobs', newJob);
            setShowCreateForm(false);
            setNewJob({
                name: '',
                description: '',
                playbook_tags: 'cleanup',
                schedule_type: 'daily',
                schedule_value: '02:00',
                target_hosts: 'all',
                extra_vars: '{}',
                enabled: true
            });
            fetchJobs();
            alert('Job created successfully!');
        } catch (error) {
            alert(`Failed to create job: ${error.response?.data?.detail || error.message}`);
        }
    };

    const toggleJob = async (jobId, currentStatus) => {
        try {
            await api.put(`/scheduler/jobs/${jobId}`, { enabled: !currentStatus });
            fetchJobs();
        } catch (error) {
            alert('Failed to toggle job');
        }
    };

    const deleteJob = async (jobId) => {
        if (!confirm('Delete this scheduled job?')) return;
        try {
            await api.delete(`/scheduler/jobs/${jobId}`);
            fetchJobs();
        } catch (error) {
            alert('Failed to delete job');
        }
    };

    const runJobNow = async (jobId) => {
        try {
            await api.post(`/scheduler/jobs/${jobId}/run`);
            alert('Job started! Check execution history below.');
            fetchRecentExecutions();
        } catch (error) {
            alert(`Failed to run job: ${error.response?.data?.detail || error.message}`);
        }
    };

    const formatSchedule = (type, value) => {
        if (type === 'daily') return `Daily at ${value}`;
        if (type === 'weekly') return `Every ${value}`;
        if (type === 'monthly') {
            const [day, time] = value.split(' ');
            return `Monthly on day ${day} at ${time}`;
        }
        return value;
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-slate-100">Job Scheduler</h1>
                    <p className="text-slate-400 mt-1">Automate recurring tasks with scheduled jobs</p>
                </div>
                <Button onClick={() => setShowCreateForm(!showCreateForm)} className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="mr-2 h-4 w-4" />
                    Create Job
                </Button>
            </div>

            {/* Create Job Form */}
            {showCreateForm && (
                <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                    <CardHeader>
                        <CardTitle>Create New Scheduled Job</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="text-sm font-medium text-slate-300">Job Name</label>
                                <Input
                                    value={newJob.name}
                                    onChange={(e) => setNewJob({ ...newJob, name: e.target.value })}
                                    placeholder="e.g., Daily Cleanup"
                                    className="bg-[#0f172a] border-slate-600 text-slate-200"
                                />
                            </div>
                            <div>
                                <label className="text-sm font-medium text-slate-300">Playbook Tag</label>
                                <select
                                    value={newJob.playbook_tags}
                                    onChange={(e) => setNewJob({ ...newJob, playbook_tags: e.target.value })}
                                    className="w-full bg-[#0f172a] border border-slate-600 rounded-md px-3 py-2 text-sm text-slate-200"
                                >
                                    <option value="cleanup">Cleanup</option>
                                    <option value="patch">Patching</option>
                                    <option value="metrics">Metrics Collection</option>
                                    <option value="discovery">Host Discovery</option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <label className="text-sm font-medium text-slate-300">Description</label>
                            <Input
                                value={newJob.description}
                                onChange={(e) => setNewJob({ ...newJob, description: e.target.value })}
                                placeholder="What does this job do?"
                                className="bg-[#0f172a] border-slate-600 text-slate-200"
                            />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="text-sm font-medium text-slate-300">Schedule Type</label>
                                <select
                                    value={newJob.schedule_type}
                                    onChange={(e) => setNewJob({ ...newJob, schedule_type: e.target.value })}
                                    className="w-full bg-[#0f172a] border border-slate-600 rounded-md px-3 py-2 text-sm text-slate-200"
                                >
                                    <option value="daily">Daily</option>
                                    <option value="weekly">Weekly</option>
                                    <option value="monthly">Monthly</option>
                                </select>
                            </div>
                            <div>
                                <label className="text-sm font-medium text-slate-300">Schedule Value</label>
                                <Input
                                    value={newJob.schedule_value}
                                    onChange={(e) => setNewJob({ ...newJob, schedule_value: e.target.value })}
                                    placeholder={
                                        newJob.schedule_type === 'daily' ? 'HH:MM (e.g., 02:00)' :
                                            newJob.schedule_type === 'weekly' ? 'Monday 02:00' :
                                                '1 02:00 (day time)'
                                    }
                                    className="bg-[#0f172a] border-slate-600 text-slate-200"
                                />
                            </div>
                        </div>

                        <div className="flex gap-2">
                            <Button onClick={createJob} className="bg-blue-600 hover:bg-blue-700">
                                Create Job
                            </Button>
                            <Button onClick={() => setShowCreateForm(false)} variant="outline" className="border-slate-600 hover:bg-slate-700">
                                Cancel
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Jobs List */}
            <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                <CardHeader>
                    <CardTitle>Scheduled Jobs ({jobs.length})</CardTitle>
                </CardHeader>
                <CardContent>
                    {loading ? (
                        <div className="flex items-center justify-center py-12">
                            <Loader2 className="h-8 w-8 animate-spin text-blue-400" />
                        </div>
                    ) : jobs.length === 0 ? (
                        <div className="text-center py-12 text-slate-400">
                            No scheduled jobs. Create one to get started!
                        </div>
                    ) : (
                        <div className="space-y-3">
                            {jobs.map((job) => (
                                <div key={job.id} className="p-4 bg-[#0f172a] rounded-lg border border-slate-700 hover:border-slate-600 transition-colors">
                                    <div className="flex items-start justify-between">
                                        <div className="flex-1">
                                            <div className="flex items-center gap-3">
                                                <h3 className="font-semibold text-slate-100">{job.name}</h3>
                                                <span className={`px-2 py-1 rounded-full text-xs ${job.enabled ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'
                                                    }`}>
                                                    {job.enabled ? 'Active' : 'Paused'}
                                                </span>
                                                <span className="px-2 py-1 rounded-full text-xs bg-blue-500/20 text-blue-400">
                                                    {job.playbook_tags}
                                                </span>
                                            </div>
                                            <p className="text-sm text-slate-400 mt-1">{job.description}</p>
                                            <div className="flex items-center gap-4 mt-2 text-xs text-slate-500">
                                                <div className="flex items-center gap-1">
                                                    <Calendar className="h-3 w-3" />
                                                    {formatSchedule(job.schedule_type, job.schedule_value)}
                                                </div>
                                                {job.next_run && (
                                                    <div className="flex items-center gap-1">
                                                        <Clock className="h-3 w-3" />
                                                        Next: {new Date(job.next_run).toLocaleString()}
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                        <div className="flex gap-2">
                                            <Button
                                                size="sm"
                                                variant="outline"
                                                onClick={() => runJobNow(job.id)}
                                                className="border-slate-600 hover:bg-slate-700"
                                            >
                                                <Play className="h-3 w-3 mr-1" />
                                                Run Now
                                            </Button>
                                            <Button
                                                size="sm"
                                                variant="outline"
                                                onClick={() => toggleJob(job.id, job.enabled)}
                                                className="border-slate-600 hover:bg-slate-700"
                                            >
                                                {job.enabled ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
                                            </Button>
                                            <Button
                                                size="sm"
                                                variant="outline"
                                                onClick={() => deleteJob(job.id)}
                                                className="border-red-600 hover:bg-red-500/10 text-red-400"
                                            >
                                                <Trash2 className="h-3 w-3" />
                                            </Button>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* Recent Executions */}
            <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                <CardHeader>
                    <CardTitle>Recent Executions</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-2">
                        {executions.map((exec) => (
                            <div key={exec.id} className="flex items-center justify-between p-3 bg-[#0f172a] rounded-md border border-slate-700">
                                <div className="flex items-center gap-3">
                                    {exec.status === 'success' ? (
                                        <CheckCircle2 className="h-5 w-5 text-green-400" />
                                    ) : exec.status === 'failed' ? (
                                        <XCircle className="h-5 w-5 text-red-400" />
                                    ) : (
                                        <Loader2 className="h-5 w-5 text-blue-400 animate-spin" />
                                    )}
                                    <div>
                                        <div className="font-medium text-slate-200">{exec.job_name}</div>
                                        <div className="text-xs text-slate-500">
                                            {new Date(exec.started_at).toLocaleString()}
                                        </div>
                                    </div>
                                </div>
                                <span className={`px-2 py-1 rounded-full text-xs ${exec.status === 'success' ? 'bg-green-500/20 text-green-400' :
                                        exec.status === 'failed' ? 'bg-red-500/20 text-red-400' :
                                            'bg-blue-500/20 text-blue-400'
                                    }`}>
                                    {exec.status}
                                </span>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
};

export default JobScheduler;
