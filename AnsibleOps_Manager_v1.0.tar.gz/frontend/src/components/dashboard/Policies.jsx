import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge'; // Assuming you might have a badge, or use div
import { AlertTriangle, CheckCircle, Bell } from 'lucide-react';

export const ConfiguredPolicies = () => {
    const policies = [
        { id: 1, name: 'High CPU Usage', condition: 'CPU > 90% for 5m', severity: 'Critical', action: 'Email Admin' },
        { id: 2, name: 'Low Disk Space', condition: 'Free Space < 10%', severity: 'Warning', action: 'Slack Alert' },
        { id: 3, name: 'Memory Leak Suspected', condition: 'RAM > 95% for 1h', severity: 'Critical', action: 'Restart Service' },
        { id: 4, name: 'SSH Login Failure', condition: '5 failed attempts / 1m', severity: 'High', action: 'Block IP' },
    ];

    return (
        <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
            <CardHeader>
                <CardTitle>Configured Alert Policies</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="text-xs text-slate-400 uppercase bg-slate-800/50">
                            <tr>
                                <th className="px-6 py-3">Policy Name</th>
                                <th className="px-6 py-3">Condition</th>
                                <th className="px-6 py-3">Severity</th>
                                <th className="px-6 py-3">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {policies.map((policy) => (
                                <tr key={policy.id} className="border-b border-slate-700 hover:bg-slate-800/30">
                                    <td className="px-6 py-4 font-medium">{policy.name}</td>
                                    <td className="px-6 py-4 font-mono text-xs text-blue-400">{policy.condition}</td>
                                    <td className="px-6 py-4">
                                        <span className={`px-2 py-1 rounded-full text-xs font-bold 
                      ${policy.severity === 'Critical' ? 'bg-red-500/20 text-red-400' :
                                                policy.severity === 'Warning' ? 'bg-yellow-500/20 text-yellow-400' :
                                                    'bg-orange-500/20 text-orange-400'}`}>
                                            {policy.severity}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 flex items-center gap-2">
                                        <Bell className="h-3 w-3" /> {policy.action}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </CardContent>
        </Card>
    );
};

export const ActivePolicies = () => {
    const alerts = [
        { id: 1, name: 'Low Disk Space', triggeredAt: '2025-12-02 10:45:00', duration: '15m', severity: 'Warning' },
    ];

    return (
        <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-400">
                    <AlertTriangle className="h-5 w-5" /> Active Alerts
                </CardTitle>
            </CardHeader>
            <CardContent>
                {alerts.length > 0 ? (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left">
                            <thead className="text-xs text-slate-400 uppercase bg-slate-800/50">
                                <tr>
                                    <th className="px-6 py-3">Policy Name</th>
                                    <th className="px-6 py-3">Triggered At</th>
                                    <th className="px-6 py-3">Duration</th>
                                    <th className="px-6 py-3">Severity</th>
                                </tr>
                            </thead>
                            <tbody>
                                {alerts.map((alert) => (
                                    <tr key={alert.id} className="border-b border-slate-700 bg-red-500/5 hover:bg-red-500/10">
                                        <td className="px-6 py-4 font-medium">{alert.name}</td>
                                        <td className="px-6 py-4">{alert.triggeredAt}</td>
                                        <td className="px-6 py-4">{alert.duration}</td>
                                        <td className="px-6 py-4">
                                            <span className="px-2 py-1 rounded-full text-xs font-bold bg-yellow-500/20 text-yellow-400">
                                                {alert.severity}
                                            </span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                ) : (
                    <div className="flex flex-col items-center justify-center py-10 text-slate-500">
                        <CheckCircle className="h-12 w-12 mb-2 text-green-500/50" />
                        <p>No active alerts. All systems operational.</p>
                    </div>
                )}
            </CardContent>
        </Card>
    );
};
