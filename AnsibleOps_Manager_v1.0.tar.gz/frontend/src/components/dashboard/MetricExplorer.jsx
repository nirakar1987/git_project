import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Activity, Server, HardDrive, Network } from 'lucide-react';

const MetricExplorer = ({ history }) => {
    const [selectedMetric, setSelectedMetric] = useState('cpu_percent');

    const metricsOptions = [
        { id: 'cpu_percent', label: 'CPU Usage', color: '#3b82f6', icon: Activity },
        { id: 'memory_percent', label: 'Memory Usage', color: '#facc15', icon: Server },
        { id: 'disk_percent', label: 'Disk Usage', color: '#f97316', icon: HardDrive },
        { id: 'network_sent', label: 'Network Sent', color: '#4ade80', icon: Network },
    ];

    // Format data for the chart
    const chartData = history.map(h => ({
        ...h,
        timestamp: new Date(h.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }));

    return (
        <div className="space-y-4">
            <Card className="bg-[#1e293b] border-slate-700 text-slate-200">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-lg font-medium">Metric Explorer</CardTitle>
                    <div className="flex gap-2">
                        {metricsOptions.map((option) => (
                            <Button
                                key={option.id}
                                size="sm"
                                variant={selectedMetric === option.id ? "default" : "outline"}
                                onClick={() => setSelectedMetric(option.id)}
                                className={`gap-2 ${selectedMetric === option.id ? 'bg-blue-600 hover:bg-blue-700' : 'bg-transparent border-slate-600 hover:bg-slate-800'}`}
                            >
                                <option.icon className="h-4 w-4" />
                                {option.label}
                            </Button>
                        ))}
                    </div>
                </CardHeader>
                <CardContent className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                            <XAxis dataKey="timestamp" stroke="#94a3b8" />
                            <YAxis stroke="#94a3b8" />
                            <Tooltip
                                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f1f5f9' }}
                            />
                            <Legend />
                            <Line
                                type="monotone"
                                dataKey={selectedMetric}
                                name={metricsOptions.find(m => m.id === selectedMetric)?.label}
                                stroke={metricsOptions.find(m => m.id === selectedMetric)?.color}
                                strokeWidth={3}
                                dot={false}
                                activeDot={{ r: 8 }}
                            />
                        </LineChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>
        </div>
    );
};

export default MetricExplorer;
