import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

class ErrorBoundary extends React.Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false, error: null, errorInfo: null };
    }

    static getDerivedStateFromError(error) {
        return { hasError: true };
    }

    componentDidCatch(error, errorInfo) {
        console.error('Error caught by boundary:', error, errorInfo);
        this.setState({
            error,
            errorInfo
        });
    }

    handleReset = () => {
        this.setState({ hasError: false, error: null, errorInfo: null });
        window.location.href = '/';
    };

    render() {
        if (this.state.hasError) {
            return (
                <div className="min-h-screen bg-[#0f172a] flex items-center justify-center p-4">
                    <Card className="max-w-2xl w-full bg-[#1e293b] border-slate-700 text-slate-200">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2 text-red-400">
                                <AlertTriangle className="h-6 w-6" />
                                Application Error
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <p className="text-slate-300">
                                Something went wrong. The application encountered an unexpected error.
                            </p>

                            {this.state.error && (
                                <div className="bg-[#0f172a] p-4 rounded-md border border-slate-700">
                                    <p className="text-sm font-mono text-red-400">
                                        {this.state.error.toString()}
                                    </p>
                                </div>
                            )}

                            <div className="flex gap-3">
                                <Button
                                    onClick={this.handleReset}
                                    className="bg-blue-600 hover:bg-blue-700"
                                >
                                    <RefreshCw className="mr-2 h-4 w-4" />
                                    Return to Dashboard
                                </Button>
                                <Button
                                    onClick={() => window.location.reload()}
                                    variant="outline"
                                    className="border-slate-600 hover:bg-slate-700"
                                >
                                    Reload Page
                                </Button>
                            </div>

                            {process.env.NODE_ENV === 'development' && this.state.errorInfo && (
                                <details className="mt-4">
                                    <summary className="cursor-pointer text-sm text-slate-400 hover:text-slate-300">
                                        View Error Details (Development Only)
                                    </summary>
                                    <pre className="mt-2 text-xs bg-[#0f172a] p-3 rounded overflow-auto max-h-64 text-slate-400">
                                        {this.state.errorInfo.componentStack}
                                    </pre>
                                </details>
                            )}
                        </CardContent>
                    </Card>
                </div>
            );
        }

        return this.props.children;
    }
}

export default ErrorBoundary;
