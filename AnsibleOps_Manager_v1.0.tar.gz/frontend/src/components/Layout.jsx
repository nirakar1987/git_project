import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { LayoutDashboard, Wrench, Shield, Package, Terminal, Bot, TrendingUp, LogOut, User, Clock, FileText } from 'lucide-react';

const Layout = ({ children, userRole, onLogout }) => {
    const location = useLocation();

    const navItems = [
        { name: 'Dashboard', path: '/', icon: LayoutDashboard },
        { name: 'Predictive Analytics', path: '/analytics', icon: TrendingUp },
        { name: 'Job Scheduler', path: '/scheduler', icon: Clock },
        { name: 'Reports', path: '/reports', icon: FileText },
        { name: 'Maintenance', path: '/maintenance', icon: Wrench },
        { name: 'Patching', path: '/patching', icon: Shield },
        { name: 'Software', path: '/software', icon: Package },
        { name: 'Ansible', path: '/ansible', icon: Terminal },
        { name: 'AI Builder', path: '/ai', icon: Bot },
    ];

    return (
        <div className="min-h-screen bg-background flex">
            {/* Sidebar */}
            <div className="w-64 border-r bg-card p-4 flex flex-col">
                <div className="text-2xl font-bold mb-8 text-primary">AnsibleOps</div>
                <nav className="space-y-2 flex-1">
                    {navItems.map((item) => {
                        const Icon = item.icon;
                        const isActive = location.pathname === item.path;
                        return (
                            <Link
                                key={item.path}
                                to={item.path}
                                className={cn(
                                    "flex items-center gap-3 px-3 py-2 rounded-md transition-colors",
                                    isActive
                                        ? "bg-primary text-primary-foreground"
                                        : "hover:bg-accent hover:text-accent-foreground text-muted-foreground"
                                )}
                            >
                                <Icon size={20} />
                                <span>{item.name}</span>
                            </Link>
                        );
                    })}
                </nav>

                {/* User Info & Logout */}
                <div className="mt-auto space-y-3 pt-4 border-t border-slate-700">
                    <div className="flex items-center gap-2 px-3 py-2 bg-slate-800 rounded-md">
                        <User size={16} className="text-slate-400" />
                        <div className="flex-1">
                            <div className="text-xs text-slate-400">Logged in as</div>
                            <div className="text-sm font-medium text-slate-200 capitalize">{userRole || 'User'}</div>
                        </div>
                    </div>
                    <button
                        onClick={onLogout}
                        className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-400 hover:bg-red-500/10 rounded-md transition-colors"
                    >
                        <LogOut size={16} />
                        <span>Logout</span>
                    </button>
                    <div className="text-xs text-muted-foreground">
                        v1.0.0 Production Ready
                    </div>
                </div>
            </div>

            {/* Main Content */}
            <main className="flex-1 p-8 overflow-auto">
                {children}
            </main>
        </div>
    );
};

export default Layout;
