# Multiple Users and Concurrent Login — Ideas (Not Implementation)

This document describes **how multiple users can work and log in at the same time** in ITSM Analytics. It is for reference only; no code changes are required for basic concurrent login.

---

## Is it possible? **Yes**

- **Concurrent login** is already supported. The app uses **JWT (stateless) authentication**: each user gets their own token when they log in. There is no “single session” limit. Many users can be logged in at once from different browsers or devices.
- **User management** is now in the app: admins can create/update/delete users and set the admin role. The first admin user can be created with:
  ```bash
  docker compose exec backend python create_user.py admin admin --force --admin
  ```

---

## How it works today

1. **Login**  
   Each user signs in with username/password and receives a **JWT**. The token is stored in the browser (e.g. localStorage) and sent in the `Authorization` header on every API request.

2. **No server-side session list**  
   The backend does not keep a list of “who is logged in”. It only checks whether the JWT in each request is valid. So there is no built-in limit on how many users can be logged in at once.

3. **Sessions (uploaded data)**  
   Uploaded “sessions” (chart data, AI insights) are stored by **session_id**. Right now they are **not** tied to a user_id. So in a shared deployment, any authenticated user could in principle see or reuse session IDs if they knew them. To make multi-user behaviour clear and safe, you’d add **user scoping** (see below).

---

## Ideas to make multi-user behaviour explicit (optional)

If you want each user to see only their own data (or to share it in a controlled way), you could do the following **in a future implementation**:

1. **Store which user owns each session**  
   - Add a `user_id` (or `username`) column to the table that stores sessions (e.g. `analytics_sessions`).  
   - When a user uploads a file and a new session is created, set `user_id` to the current user.

2. **Filter sessions by current user**  
   - When listing “saved sessions” (e.g. in the sidebar), query only sessions where `user_id` = current user.  
   - When loading a session by ID, check that the session belongs to the current user (or that the user is admin) before returning data.

3. **Optional: sharing**  
   - Add a “shared with” or “visibility” field (e.g. private / team / org).  
   - List and load sessions according to “owned by me” or “shared with me” or “visible to my team”.

4. **Optional: rate limits and quotas**  
   - To avoid one user overloading the app, add per-user rate limits (e.g. on upload or AI calls) and/or quotas (e.g. max number of sessions or max storage per user).

5. **Optional: audit**  
   - Log who created/accessed which session and when, for compliance or debugging.

---

## Summary

- **Multiple users can log in at the same time** — JWTs are stateless and per-user; there is no single-session restriction.  
- **User management** is implemented: admins can create/update/delete users and set admin.  
- To make “my data” vs “others’ data” clear, you would **associate sessions with a user** and **filter by current user** (and optionally add sharing and quotas). The ideas above describe that direction without implementing it.
