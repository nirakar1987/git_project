"""
Create or reset a user in the database (when DATABASE_URL is set).
Usage: python create_user.py [username] [password] [--force] [--admin]
Example: python create_user.py admin mypassword
         python create_user.py admin admin --force   (reset password)
         python create_user.py admin admin --admin   (create as admin)
"""
import os
import sys

os.environ.setdefault("DATABASE_URL", "")

if not os.getenv("DATABASE_URL"):
    print("DATABASE_URL is not set. Users are in-memory (see AUTH_DEFAULT_USER / AUTH_DEFAULT_PASSWORD).")
    sys.exit(0)

from database import init_db, get_user_by_username, create_user, update_user_password, update_user_admin
from auth import get_password_hash

init_db()
args = [a for a in sys.argv[1:] if a not in ("--force", "--admin")]
force = "--force" in sys.argv
admin_flag = "--admin" in sys.argv
username = args[0] if len(args) > 0 else "admin"
password = args[1] if len(args) > 1 else "admin"

hashed = get_password_hash(password)
if get_user_by_username(username):
    if force:
        if update_user_password(username, hashed):
            if admin_flag:
                update_user_admin(username, True)
            print(f"User '{username}' password updated." + (" Set as admin." if admin_flag else ""))
        else:
            print(f"Failed to update user '{username}'.")
            sys.exit(1)
    else:
        print(f"User '{username}' already exists. Use --force to reset password.")
        sys.exit(0)
else:
    if create_user(username, hashed, is_admin=admin_flag):
        print(f"User '{username}' created." + (" (admin)" if admin_flag else ""))
    else:
        print(f"Failed to create user '{username}'.")
        sys.exit(1)
