import pandas as pd
import google.generativeai as genai
import os
import json
import re
from dotenv import load_dotenv

load_dotenv()


def _safe_parse_dates(series):
    """Parse date column trying US, EU, ISO, hyphen formats; never raise. Returns series of datetime/NaT."""
    series = series.astype(str).str.strip().replace('', pd.NA)
    out = pd.Series([pd.NaT] * len(series), index=series.index)
    # Try explicit formats so all variants are counted (slash US/EU, hyphen DD-MM and MM-DD, ISO)
    formats = [
        '%m/%d/%Y %H:%M', '%m/%d/%Y', '%m/%d/%y %H:%M', '%m/%d/%y',   # US slash
        '%d-%m-%Y %H:%M', '%d-%m-%Y', '%d-%m-%y %H:%M', '%d-%m-%y',   # EU hyphen
        '%m-%d-%Y %H:%M', '%m-%d-%Y', '%m-%d-%y %H:%M', '%m-%d-%y',   # US hyphen
        '%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%Y-%m-%d',            # ISO
        '%d/%m/%Y %H:%M', '%d/%m/%Y', '%d/%m/%y %H:%M', '%d/%m/%y',   # EU slash
        '%d-%b-%Y %H:%M', '%d-%b-%Y', '%b-%d-%Y', '%Y-%b-%d',         # 01-Aug-2025 style
        '%d.%m.%Y %H:%M', '%d.%m.%Y', '%Y.%m.%d',                      # Dot separators
        '%Y/%m/%d %H:%M:%S', '%Y/%m/%d %H:%M',                        # ISO with slash
    ]
    for fmt in formats:
        try:
            parsed = pd.to_datetime(series, format=fmt, errors='coerce')
            if parsed.notna().any():
                out = out.fillna(parsed)
            if out.notna().all():
                break
        except Exception:
            continue
    still_na = out.isna() & series.notna() & (series.astype(str).str.strip() != '')
    if still_na.any():
        flexible = pd.to_datetime(series[still_na], errors='coerce', dayfirst=True)
        out = out.fillna(flexible)
    return out


class ITSMProcessor:
    def __init__(self, api_key):
        if api_key:
            genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-2.0-flash')
        self.last_verification_report = None

    def process_file(self, file_path, file_type, data_type=None):
        try:
            print(f"Processing file: {file_path} (data_type={data_type})")
            df = None
            
            # 1. READ RAW DATA (Handle Encodings + HPSM UTF-16 tab-delimited)
            if file_type == 'csv':
                # Try UTF-16 first (HPSM/Excel exports often use this); then common encodings
                encodings = ['utf-16', 'utf-16-sig', 'utf-8', 'latin1', 'cp1252']
                delimiters = ['\t', ',', ';', '|']  # tab first for HPSM/TSV exports
                
                for enc in encodings:
                    for sep in delimiters:
                        try:
                            # engine='python' handles quoted multi-line fields (e.g. HPSM Description)
                            df_raw = pd.read_csv(
                                file_path, encoding=enc, sep=sep, header=None, dtype=str,
                                keep_default_na=False, nrows=500, engine='python'
                            )
                            if df_raw.shape[1] > 1 and df_raw.shape[0] > 0:
                                df = pd.read_csv(
                                    file_path, encoding=enc, sep=sep, header=None, dtype=str,
                                    keep_default_na=False, engine='python'
                                )
                                break
                        except Exception:
                            continue
                    if df is not None:
                        break
            else:
                df = pd.read_excel(file_path, header=None, dtype=str)

            if df is None:
                raise ValueError("Could not read file. Unknown format or encoding.")

            # 2. LOCATE HEADER ROW (Scoring System)
            # We look for a row that contains keyword like 'Status', 'ID', 'Category'
            best_header_idx = -1
            best_score = 0
            
            keywords = {
                'ticket_id': ['id', 'ticket', 'incident', 'number', 'ref', 'change id', 'request id'],
                'status': ['status', 'state', 'phase', 'current phase', 'sys internal'],
                'priority': ['priority', 'urgency', 'sev', 'severity'],
                'category': ['category', 'service', 'group', 'assignment', 'workflow', 'support group', 'fulfillment'],
                'summary': ['summary', 'title', 'desc', 'subject', 'description', 'brief description'],
                'created_at': ['created', 'opened', 'open date', 'open time', 'submitted', 'registration', 'log date', 'creation', 'start', 'submit', 'reported', 'entry', 'request date', 'planned start', 'schedule start'],
                'resolved_at': ['resolved', 'closed', 'close date', 'close time', 'completed', 'updated', 'finish', 'end', 'actual finish', 'delivery date', 'planned end', 'actual end', 'schedule end'],
                'sla_status': ['sla', 'slt', 'breach', 'breached', 'slm', 'target', 'escalation'],
                'approval_status': ['approval', 'approval status', 'approval status name', 'approval status id', 'approval status code', 'approval phase']
            }
            
            # Scan first 50 rows
            for i in range(min(50, len(df))):
                row_values = [str(x).lower() for x in df.iloc[i].values]
                score = 0
                for cat, keys in keywords.items():
                    if any(key in " ".join(row_values) for key in keys):
                        score += 1
                
                if score > best_score:
                    best_score = score
                    best_header_idx = i

            # If we found a likely header, use it. Otherwise assume row 0.
            if best_header_idx >= 0 and best_score >= 2:
                print(f"Header found at row {best_header_idx} with score {best_score}")
                df.columns = df.iloc[best_header_idx].astype(str).str.strip().str.replace('\ufeff', '', regex=False)
                df = df.iloc[best_header_idx + 1:].reset_index(drop=True)
            else:
                print("No clear header found. Using first row as header.")
                df.columns = df.iloc[0].astype(str).str.strip().str.replace('\ufeff', '', regex=False)
                df = df.iloc[1:].reset_index(drop=True)

            # Auto-detect data type from column names if not provided
            if data_type is None:
                raw_cols = [str(c).lower() for c in df.columns]
                raw_joined = " ".join(raw_cols)
                if any(('incident' in c and 'id' in c) or 'open time' in c for c in raw_cols):
                    data_type = 'Incident'
                elif (
                    any('change id' in c or ('change' in c and 'id' in c) for c in raw_cols)
                    and any(
                        'planned start' in c or 'planned end' in c or 'scheduled start' in c or 'approval' in c
                        for c in raw_cols
                    )
                ):
                    data_type = 'Change Task'
                elif 'change' in raw_joined and any(
                    'planned' in c or 'start' in c or 'end' in c or 'approval' in c for c in raw_cols
                ):
                    data_type = 'Change Task'
                elif any('brief description' in c for c in raw_cols) and any('service' in c for c in raw_cols):
                    data_type = 'Service Request'
                else:
                    data_type = 'Unknown'

            # 3. NORMALIZE COLUMNS
            # Rename columns to standard names
            final_cols = {}
            for col in df.columns:
                col_name = str(col).lower()
                for target, keys in keywords.items():
                    if any(k in col_name for k in keys):
                        if target not in final_cols.values(): # assign only if not already assigned
                            final_cols[col] = target
                            break
            
            df = df.rename(columns=final_cols)

            # 4. FALLBACK COLUMN ASSIGNMENT (If mapping failed)
            # If we missed 'ticket_id' or 'priority', try to map by content or position
            if 'ticket_id' not in df.columns and len(df.columns) > 0:
                df.rename(columns={df.columns[0]: 'ticket_id'}, inplace=True)
            
            if 'status' not in df.columns:
                # Look for a column with 'Open/closed' values
                for col in df.columns:
                    sample = " ".join(df[col].astype(str).head(10).tolist()).lower()
                    if 'open' in sample or 'closed' in sample or 'resolved' in sample:
                        df.rename(columns={col: 'status'}, inplace=True)
                        break
            
            required_defaults = {'ticket_id': 'Unknown', 'priority': 'Normal', 'status': 'Open', 'category': 'General', 'summary': 'No Content', 'sla_status': 'N/A', 'approval_status': 'N/A'}
            for col, default in required_defaults.items():
                if col not in df.columns:
                    df[col] = default

            # Normalize HPSM "SLT Breached" true/false -> Met/Breached; SR "Escalation" -> sla_status; Yes/No
            if 'sla_status' in df.columns:
                s = df['sla_status'].astype(str).str.strip().str.lower()
                df.loc[s.str.contains('true', na=False), 'sla_status'] = 'Breached'
                df.loc[s.str.contains('false', na=False), 'sla_status'] = 'Met'
                df.loc[s.str.contains('sla-breach', na=False), 'sla_status'] = 'Breached'
                df.loc[s.str.contains('sla breach', na=False), 'sla_status'] = 'Breached'
                df.loc[s.str.contains('sla-warning', na=False), 'sla_status'] = 'Warning'
                df.loc[s.str.contains('sla warning', na=False), 'sla_status'] = 'Warning'
                df.loc[s.isin(['yes', 'y', '1']), 'sla_status'] = 'Met'
                df.loc[s.isin(['no', 'n', '0']), 'sla_status'] = 'Breached'

            # Add record_type for Incident / Service Request / Change Task
            df['record_type'] = data_type if data_type else 'Unknown'

            # 5. VERIFY AND CORRECT COLUMNS
            report = {"columns_verified": 0, "rows_before": len(df), "rows_after": 0, "columns_detected": [], "date_columns_corrected": [], "invalid_dates_coerced": 0, "formats_corrected": [], "message": ""}
            df.columns = df.columns.astype(str).str.strip().str.replace('\ufeff', '', regex=False)
            seen = {}
            new_cols = []
            for c in df.columns:
                name = c or "Unnamed"
                if name in seen:
                    seen[name] += 1
                    name = f"{name}_{seen[name]}"
                else:
                    seen[name] = 0
                new_cols.append(name)
            df.columns = new_cols
            report["columns_verified"] = len(df.columns)
            report["columns_detected"] = list(df.columns)

            # 6. VERIFY AND CORRECT ROWS (trim whitespace, empty -> N/A)
            for col in df.columns:
                df[col] = df[col].astype(str).str.strip()
                df.loc[df[col].isin(['', 'nan', 'NaN', 'None']), col] = 'N/A'
            df = df.fillna('N/A')
            # Drop rows that are entirely N/A or empty (optional; keeps at least header-like data)
            all_na = (df.astype(str).replace('N/A', pd.NA).replace('nan', pd.NA) == '').all(axis=1) | (df == 'N/A').all(axis=1)
            rows_dropped = all_na.sum()
            if rows_dropped > 0:
                df = df[~all_na].reset_index(drop=True)
            report["rows_after"] = len(df)
            if rows_dropped > 0:
                report["formats_corrected"].append(f"Dropped {int(rows_dropped)} fully empty rows")

            # 7. VERIFY AND CORRECT DATE COLUMNS (wrong format -> correct parse; invalid -> NaT/Unknown)
            date_cols = [c for c in df.columns if c in ('created_at', 'resolved_at') or ('date' in c.lower() or 'time' in c.lower())]
            for col in date_cols:
                try:
                    before_na = df[col].astype(str).str.strip().isin(['', 'N/A', 'nan']).sum()
                    parsed = _safe_parse_dates(df[col])
                    df[col] = parsed
                    after_na = parsed.isna().sum()
                    report["date_columns_corrected"].append(col)
                    report["invalid_dates_coerced"] += max(0, int(after_na) - int(before_na))
                except Exception as e:
                    report["formats_corrected"].append(f"Date column '{col}' partial parse: {str(e)[:50]}")

            if 'created_at' in df.columns:
                df['month_name'] = df['created_at'].dt.strftime('%b').fillna('Unknown')
                df['month_year'] = df['created_at'].dt.strftime('%b %Y').fillna('Unknown')
                # Correct empty/bad open date using close date when available
                if 'resolved_at' in df.columns:
                    bad_open = df['created_at'].isna()
                    good_close = df['resolved_at'].notna()
                    fill_mask = bad_open & good_close
                    if fill_mask.any():
                        df.loc[fill_mask, 'created_at'] = df.loc[fill_mask, 'resolved_at']
                        df.loc[fill_mask, 'month_name'] = df.loc[fill_mask, 'created_at'].dt.strftime('%b')
                        df.loc[fill_mask, 'month_year'] = df.loc[fill_mask, 'created_at'].dt.strftime('%b %Y')
                        report["formats_corrected"].append(f"Filled {int(fill_mask.sum())} missing open dates from close date")
            else:
                # If no 'created_at' mapped, search for ANY column that was successfully parsed as datetime
                for col in df.columns:
                    if pd.api.types.is_datetime64_any_dtype(df[col]):
                        df['created_at'] = df[col]
                        df['month_name'] = df['created_at'].dt.strftime('%b').fillna('Unknown')
                        df['month_year'] = df['created_at'].dt.strftime('%b %Y').fillna('Unknown')
                        report["formats_corrected"].append(f"Used '{col}' as default date column")
                        break
                
            # Fallback for resolved_at: if missing, use another date column
            if 'resolved_at' not in df.columns:
                potential_dates = [c for c in df.columns if c != 'created_at' and pd.api.types.is_datetime64_any_dtype(df[col])]
                # Prefer columns with 'closed' or 'end' or 'update' in name if multiple
                best_candidate = None
                for candidate in potential_dates:
                    c_lower = candidate.lower()
                    if 'close' in c_lower or 'end' in c_lower or 'resolve' in c_lower or 'finish' in c_lower:
                        best_candidate = candidate
                        break
                if not best_candidate and potential_dates:
                    best_candidate = potential_dates[0]
                
                if best_candidate:
                    df['resolved_at'] = df[best_candidate]
                    report["formats_corrected"].append(f"Used '{best_candidate}' as implied resolved_at column")

            # Final fallback if still nothing
            if 'month_year' not in df.columns:
                df['month_name'] = 'Unknown'
                df['month_year'] = 'Unknown'

            # 8. VERIFY AND CORRECT OTHER FORMATS (priority, category, summary)
            if 'priority' in df.columns:
                p = df['priority'].astype(str).str.strip()
                p_map = {'p1': 'High', 'p2': 'Medium', 'p3': 'Low', '1': 'High', '2': 'Medium', '3': 'Low', 'critical': 'Critical', 'high': 'High', 'medium': 'Medium', 'low': 'Low'}
                df['priority'] = p.str.lower().map(lambda x: p_map.get(x, x.title() if x and x != 'N/A' else 'Normal'))
            if 'category' in df.columns:
                df['category'] = df['category'].astype(str).str.strip().replace('', 'N/A')
            if 'summary' in df.columns:
                df['summary'] = df['summary'].astype(str).str.strip().replace('', 'No Content')

            report["message"] = f"Verified {report['columns_verified']} columns, {report['rows_after']} rows. Dates corrected where needed; invalid values coerced to N/A or Unknown."
            self.last_verification_report = report

            print(f"File processed. Columns: {df.columns.tolist()}. Verification: {report['message']}")
            return df

        except Exception as e:
            print(f"PROCESSOR ERROR: {e}")
            raise e

    def get_ai_insights(self, df):
        try:
            # STEP 1: Deterministic Python Processing (No LLM here)
            # Calculate metrics immediately to handle 50k+ rows easily
            total_tickets = len(df)
            priority_split = df['priority'].value_counts().head(3).to_dict()
            category_split = df['category'].value_counts().head(3).to_dict()
            sla_breach = len(df[df['sla_status'].astype(str).str.contains('Breached', case=False)])
            
            # Simple keyword extraction for "Top Issues"
            # We join headlines and find most common non-stopword terms
            from collections import Counter
            import re
            
            text_blob = " ".join(df['summary'].astype(str).tolist()).lower()
            words = re.findall(r'\b[a-z]{4,}\b', text_blob) # Only words 4+ chars
            ignore = {'ticket', 'issue', 'incident', 'please', 'regarding', 'status', 'update', 'service', 'request'}
            common_words = [w for w in words if w not in ignore]
            top_issues = Counter(common_words).most_common(5)

            # STEP 2: Send AGGREGATED Stats to LLM (Very small payload, huge insight)
            # This ensures we analyze 100% of the data without token limits
            stats_context = f"""
            Total Volume: {total_tickets}
            High Priority Volume: {priority_split}
            Top Problem Areas (Categories): {category_split}
            Total SLA Breaches: {sla_breach}
            Most frequent keywords in ticket descriptions: {top_issues}
            """
            
            prompt = f"""
            You are an IT Operations Director. Based on these calculated statistics, write a 3-sentence executive summary.
            
            Stats:
            {stats_context}
            
            Output JSON: {{
                "summary": "Focus on the keyword patterns and volume.", 
                "sentiment": "Infer from SLA and Priority.", 
                "recommendation": "Specific action based on the Top Priority/Category." 
            }}
            """
            response = self.model.generate_content(prompt)
            text = response.text
            start, end = text.find('{'), text.rfind('}') + 1
            return json.loads(text[start:end])
        except Exception as e:
            print(f"AI Error: {e}")
            # Dynamic fallback when AI fails
            fb_summary = f"Total volume is {total_tickets} tickets with {sla_breach} SLA breaches. "
            if priority_split:
                top_p = list(priority_split.keys())[0]
                fb_summary += f"Priority {top_p} is currently the most frequent. "
            if common_words:
                fb_summary += f"Frequent themes include: {', '.join([w[0] for w in top_issues[:3]])}."
                
            return {
                "summary": fb_summary or "Data processed successfully.",
                "sentiment": "Neutral",
                "recommendation": "Manual review of High Priority categories is advised."
            }

    def get_chart_data(self, df):
        month_map = {name: i for i, name in enumerate(['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])}
        # Sort key for "Jan 2025" / "Jan 2026" / "Unknown" so columns are chronological across years
        def _month_year_sort_key(x):
            if str(x) == 'Unknown':
                return (9999, 99)
            parts = str(x).strip().split()
            if len(parts) >= 2 and parts[-1].isdigit():
                yr, mo = int(parts[-1]), month_map.get(parts[0], 99)
                return (yr, mo)
            return (9999, month_map.get(str(x), 99))
        # Data period for display (e.g. "Jan 2024 – Dec 2026")
        data_period = None
        if 'created_at' in df.columns:
            created = pd.to_datetime(df['created_at'], errors='coerce')
            valid = created.notna()
            if valid.any():
                mn, mx = created[valid].min(), created[valid].max()
                data_period = f"{mn.strftime('%b %Y')} – {mx.strftime('%b %Y')}" if mn != mx else mn.strftime('%b %Y')
        use_month_col = 'month_year' if 'month_year' in df.columns else 'month_name'
        # 1. Monthly Workload (Stacked Bar Data) - use month_year so chart shows year (e.g. Jan 2025, Jan 2026)
        TOP_CATEGORIES = 8
        if use_month_col in df.columns:
            workload_pivot = df.groupby([use_month_col, 'category']).size().unstack(fill_value=0)
            all_months = sorted(workload_pivot.index.tolist(), key=_month_year_sort_key)
            # ALLOW UNKNOWN: if we only have unknown, show it. Otherwise prefer showing real months.
            months = [m for m in all_months if str(m) != 'Unknown']
            if not months and len(all_months) > 0:
                months = all_months # Fallback: show 'Unknown' bar instead of blank chart
            # Top categories by total volume across all months
            cat_totals = workload_pivot.sum().sort_values(ascending=False)
            top_cats = [c for c in cat_totals.index.tolist() if str(c) != 'N/A'][:TOP_CATEGORIES]
            other_cats = [c for c in workload_pivot.columns if c not in top_cats and str(c) != 'N/A']
            keep_cols = top_cats
            workload_chart = []
            for m in months:
                row = {"name": m}
                month_total = 0
                for cat in keep_cols:
                    val = int(workload_pivot.loc[m, cat])
                    row[str(cat)] = val
                    month_total += val
                if other_cats:
                    other_val = int(workload_pivot.loc[m, other_cats].sum())
                    row["Other"] = other_val
                    month_total += other_val
                row["total"] = month_total
                workload_chart.append(row)
            categories_for_workload = keep_cols + (["Other"] if other_cats else [])
        else:
            workload_chart = []
            categories_for_workload = []


        # 2. SLA Metrics
        sla_data = df['sla_status'].value_counts()
        sla_chart = [{"name": str(k), "value": int(v)} for k, v in sla_data.items() if k != 'N/A']

        # 3. Priority Distribution
        priority_chart = [{"name": str(k), "value": int(v)} for k, v in df['priority'].value_counts().items() if k != 'N/A']

        # 4. Top Services Breakdown
        service_chart = [{"name": str(k), "value": int(v)} for k, v in df['category'].value_counts().head(8).items() if k != 'N/A']

        # 5. Real SLA met % (for KPIs)
        total = len(df)
        sla_met_count = len(df[df['sla_status'].astype(str).str.lower().str.contains('met', na=False)])
        sla_met_pct = round(100 * sla_met_count / total, 1) if total else 0

        # 6. Avg resolve time (hours) if we have created_at + resolved_at
        avg_resolve_hours = None
        if 'created_at' in df.columns and 'resolved_at' in df.columns:
            df_valid = df.dropna(subset=['created_at', 'resolved_at']).copy()
            if len(df_valid) > 0:
                df_valid['_delta'] = pd.to_datetime(df_valid['resolved_at'], errors='coerce') - pd.to_datetime(df_valid['created_at'], errors='coerce')
                df_valid = df_valid[df_valid['_delta'].notna() & (df_valid['_delta'].dt.total_seconds() >= 0)]
                if len(df_valid) > 0:
                    avg_seconds = df_valid['_delta'].dt.total_seconds().mean()
                    avg_resolve_hours = round(avg_seconds / 3600, 1)

        # 7. Excel-style: Workload table (Service x Month) - column headers show year (Jan 2025, Jan 2026) so everyone can recognize
        workload_table = {"months": [], "rows": [], "grand_total_row": None}
        if use_month_col in df.columns:
            wt_pivot = df.groupby([use_month_col, 'category']).size().unstack(fill_value=0)
            all_months_wt = sorted(wt_pivot.index.tolist(), key=lambda x: (1 if str(x) == 'Unknown' else 0, *_month_year_sort_key(x)))
            wt_months = [m for m in all_months_wt if str(m) != 'Unknown']
            wt_months_with_unknown = wt_months + (['Unknown'] if 'Unknown' in wt_pivot.index else [])
            workload_table["months"] = wt_months_with_unknown
            top_services = df['category'].value_counts().head(20).index.tolist()
            for svc in top_services:
                if str(svc) == 'N/A':
                    continue
                row = {"name": str(svc)}
                for m in wt_months_with_unknown:
                    try:
                        row[m] = int(wt_pivot.loc[m, svc]) if m in wt_pivot.index and svc in wt_pivot.columns else 0
                    except (KeyError, TypeError):
                        row[m] = 0
                row["total"] = sum(row.get(m, 0) for m in wt_months_with_unknown)
                workload_table["rows"].append(row)
            # Grand Total row (like Excel row 31)
            if workload_table["rows"] and wt_months_with_unknown:
                gt = {"name": "Grand Total"}
                for m in wt_months_with_unknown:
                    gt[m] = sum(r.get(m, 0) for r in workload_table["rows"])
                gt["total"] = sum(r.get("total", 0) for r in workload_table["rows"])
                workload_table["grand_total_row"] = gt

        # 7b. Excel-style: Workload by 5 categories (Infrastructure, Applications, Processes, Converged Network, Software)
        workload_by_group = {"months": [], "rows": [], "grand_total_row": None}
        def _service_to_group(svc):
            s = (str(svc) or "").upper()
            if any(x in s for x in ["SERVER", "OS UNIX", "WINDOWS OPERATING", "WAN", "LAN", "RMM", "AWS-", "INFRASTRUCTURE"]):
                return "Infrastructure"
            if any(x in s for x in ["MASS CLOSURE", "PROCESS"]):
                return "Processes"
            if any(x in s for x in ["CONVERGED", "NETWORK"]):
                return "Converged Network"
            if any(x in s for x in ["SOFTWARE", "END-USER-SOFTWARE"]):
                return "Software"
            return "Applications"

        workload_by_group = {"months": [], "rows": [], "grand_total_row": None}
        if use_month_col in df.columns:
            df_work = df.copy()
            df_work["_group"] = df_work["category"].apply(_service_to_group)
            grp_pivot = df_work.groupby([use_month_col, '_group']).size().unstack(fill_value=0)
            all_grp_months = sorted(grp_pivot.index.tolist(), key=lambda x: (1 if str(x) == 'Unknown' else 0, *_month_year_sort_key(x)))
            grp_months = [m for m in all_grp_months if str(m) != 'Unknown']
            grp_months_with_unknown = grp_months + (['Unknown'] if 'Unknown' in grp_pivot.index else [])
            workload_by_group["months"] = grp_months_with_unknown
            group_order = ["Infrastructure", "Applications", "Processes", "Converged Network", "Software"]
            for g in group_order:
                row = {"name": g}
                for m in grp_months_with_unknown:
                    row[m] = int(grp_pivot.loc[m, g]) if g in grp_pivot.columns and m in grp_pivot.index else 0
                row["total"] = sum(row.get(m, 0) for m in grp_months_with_unknown)
                workload_by_group["rows"].append(row)
            if workload_by_group["rows"] and grp_months_with_unknown:
                gt = {"name": "Grand Total"}
                for m in grp_months_with_unknown:
                    gt[m] = sum(r.get(m, 0) for r in workload_by_group["rows"])
                gt["total"] = sum(r.get("total", 0) for r in workload_by_group["rows"])
                workload_by_group["grand_total_row"] = gt

        # 8. Excel-style: Priority by month - use month_year so labels show year
        priority_by_month = []
        if use_month_col in df.columns:
            pm_df = df[df[use_month_col] != 'Unknown']
            pm_pivot = pm_df.groupby([use_month_col, 'priority']).size().unstack(fill_value=0)
            pm_months = [m for m in sorted(pm_pivot.index.tolist(), key=_month_year_sort_key) if str(m) != 'Unknown']
            for m in pm_months:
                row = {"name": m}
                for p in pm_pivot.columns:
                    if str(p) != 'N/A':
                        row[str(p)] = int(pm_pivot.loc[m, p])
                priority_by_month.append(row)

        # 9. Excel-style: SLA by category - use full dataset; all categories for report appendix/full table
        sla_by_category = []
        df_sla = df
        for cat in df_sla['category'].value_counts().index.tolist():
            if str(cat) == 'N/A':
                continue
            sub = df_sla[df_sla['category'] == cat]
            breached = len(sub[sub['sla_status'].astype(str).str.lower().str.contains('breach', na=False)])
            met = len(sub[sub['sla_status'].astype(str).str.lower().str.contains('met', na=False)])
            warning = len(sub[sub['sla_status'].astype(str).str.lower().str.contains('warn', na=False)])
            total = len(sub)
            sla_pct = round(100 * met / total, 0) if total else 0
            sla_by_category.append({
                "category": str(cat),
                "breached": breached,
                "met": met,
                "warning": warning,
                "total": total,
                "sla_pct": sla_pct
            })

        # 10. SAL Certificate related tickets (single count like Excel)
        sal_cert_mask = (df['category'].astype(str).str.upper().str.contains('SAL', na=False) & df['category'].astype(str).str.upper().str.contains('CERT', na=False)) | (df['summary'].astype(str).str.upper().str.contains('SAL', na=False) & df['summary'].astype(str).str.upper().str.contains('CERT', na=False))
        sal_certificate_count = int(sal_cert_mask.sum())

        # 11. SLA breach list – actionable list of breached tickets for follow-up
        breach_list = []
        breach_mask = df['sla_status'].astype(str).str.lower().str.contains('breach', na=False)
        if breach_mask.any():
            df_breach = df[breach_mask].copy()
            if 'created_at' in df_breach.columns and 'resolved_at' in df_breach.columns:
                df_breach['_res_delta'] = pd.to_datetime(df_breach['resolved_at'], errors='coerce') - pd.to_datetime(df_breach['created_at'], errors='coerce')
                df_breach['_resolution_days'] = df_breach['_res_delta'].dt.days
            else:
                df_breach['_resolution_days'] = None
            for _, row in df_breach.iterrows():
                summary_str = str(row.get('summary', ''))[:100]
                breach_list.append({
                    "ticket_id": str(row.get('ticket_id', '')),
                    "category": str(row.get('category', '')),
                    "priority": str(row.get('priority', '')),
                    "summary": summary_str,
                    "sla_status": str(row.get('sla_status', '')),
                    "resolution_days": int(row['_resolution_days']) if pd.notna(row.get('_resolution_days')) and row.get('_resolution_days') is not None else None
                })

        record_type_counts = {}
        if 'record_type' in df.columns:
            record_type_counts = {str(k): int(v) for k, v in df['record_type'].value_counts().items()}

        # Approval status report (for Change Ticket / Change Task data)
        approval_status_report = []
        if 'approval_status' in df.columns:
            approval_counts = df['approval_status'].astype(str).replace('', 'N/A').value_counts()
            approval_status_report = [{"name": str(k), "value": int(v)} for k, v in approval_counts.items() if str(k) != 'N/A' or v > 0]

        return {
            "workload": workload_chart,
            "sla": sla_chart,
            "priority": priority_chart,
            "services": service_chart,
            "categories": [str(c) for c in categories_for_workload] if use_month_col in df.columns else [],
            "data_period": data_period,
            "total_tickets": int(len(df)),
            "raw_sample": df[['ticket_id', 'category', 'priority', 'status', 'summary']].head(5).to_dict(orient='records'),
            "sla_met_pct": sla_met_pct,
            "avg_resolve_hours": avg_resolve_hours,
            "workload_table": workload_table,
            "workload_by_group": workload_by_group,
            "priority_by_month": priority_by_month,
            "sla_by_category": sla_by_category,
            "sal_certificate_count": sal_certificate_count,
            "breach_list": breach_list,
            "record_type_counts": record_type_counts,
            "approval_status_report": approval_status_report,
            "forecast": self.get_forecast(df)
        }

    def get_forecast(self, df):
        """Generate 3-month volume forecast using linear trend (numpy)."""
        try:
            import numpy as np
            if 'created_at' not in df.columns:
                return None
            
            # Group by month (YYYY-MM)
            # Create a localized copy to avoid setting on copy warnings
            df_ts = df.copy()
            df_ts['created_dt'] = pd.to_datetime(df_ts['created_at'], errors='coerce')
            df_ts = df_ts.dropna(subset=['created_dt'])
            
            if len(df_ts) < 10: # Not enough data
                return None
                
            monthly_counts = df_ts.groupby(df_ts['created_dt'].dt.to_period('M')).size()
            monthly_counts.index = monthly_counts.index.to_timestamp()
            monthly_counts = monthly_counts.sort_index()
            
            if len(monthly_counts) < 2:
                return None
            
            # Prepare X (ordinal) and Y (counts)
            x = np.arange(len(monthly_counts))
            y = monthly_counts.values
            
            # Linear Regression (Degree 1)
            slope, intercept = np.polyfit(x, y, 1)
            
            # Forecast next 3 months
            future_x = np.arange(len(monthly_counts), len(monthly_counts) + 3)
            future_y = slope * future_x + intercept
            future_y = np.maximum(future_y, 0) # No negative tickets
            
            # Build Chart Data
            chart_data = []
            
            # History
            for i, (date, count) in enumerate(monthly_counts.items()):
                chart_data.append({
                    "name": date.strftime('%b %Y'),
                    "actual": int(count),
                    "trend": int(slope * i + intercept),
                    "forecast": None
                })
                
            # Future
            last_date = monthly_counts.index[-1]
            for i in range(3):
                next_date = last_date + pd.DateOffset(months=i+1)
                chart_data.append({
                    "name": next_date.strftime('%b %Y'),
                    "actual": None,
                    "trend": None,
                    "forecast": int(future_y[i])
                })
                
            return {
                "chart_data": chart_data,
                "trend_direction": "Up" if slope > 0.5 else "Down" if slope < -0.5 else "Stable",
                "slope": round(slope, 2),
                "next_month_pred": int(future_y[0])
            }
        except Exception as e:
            print(f"Forecast Error: {e}")
            return None

    def chat_with_data(self, df, query):
        """Safer chat: timeout + restricted globals (no open, os, eval)."""
        import threading
        safe_builtins = {
            'len': len, 'str': str, 'int': int, 'float': float, 'bool': bool, 'list': list, 'dict': dict,
            'sum': sum, 'min': min, 'max': max, 'round': round, 'abs': abs, 'True': True, 'False': False,
            'None': None, 'zip': zip, 'map': map, 'filter': filter, 'range': range, 'sorted': sorted,
            'isinstance': isinstance, 'getattr': getattr, 'hasattr': hasattr, 'set': set,
        }
        result_holder = []
        exc_holder = []

        def run_code():
            try:
                # Build schema and identify text columns for search (summary, description, title, etc.)
                text_cols = [c for c in df.columns if str(c).lower() in (
                    'summary', 'description', 'title', 'brief description', 'desc', 'subject', 'text'
                )]
                if not text_cols and len(df.columns) > 0:
                    # Heuristic: column with longest sample string is likely description
                    def max_str_len(col):
                        s = df[col].astype(str).str.len()
                        return s.max() if len(s) > 0 else 0
                    candidates = [(c, max_str_len(c)) for c in df.columns]
                    candidates.sort(key=lambda x: -x[1])
                    if candidates and candidates[0][1] > 50:
                        text_cols = [candidates[0][0]]
                schema_info = []
                for col in df.columns:
                    sample = df[col].dropna().astype(str).unique()[:3].tolist()
                    sample_str = str(sample)[:80] + ('...' if len(str(sample)) > 80 else '')
                    if col in text_cols:
                        schema_info.append(f"- {col} (TEXT column - search with .str.contains(..., case=False, na=False); e.g. {sample_str})")
                    else:
                        schema_info.append(f"- {col} (e.g. {sample_str})")
                schema_str = "\n".join(schema_info)
                text_hint = ""
                if text_cols:
                    text_hint = f"""
                TEXT SEARCH (description/summary): {text_cols}
                - Single keyword: mask = df['{text_cols[0]}'].astype(str).str.contains('keyword', case=False, na=False)
                - Multiple (OR): mask = df['{text_cols[0]}'].astype(str).str.contains('certificate|renew|SAL', case=False, na=False, regex=True)
                - Multiple text columns: mask = df[col1].astype(str).str.contains(pat, case=False, na=False) | df[col2].astype(str).str.contains(pat, case=False, na=False)
                - Count: result = len(df[mask]); list: result = df[mask][relevant_cols].head(50)
                """
                prompt = f"""You are a Data Analyst. Answer ANY question about this dataset. You have full access to the raw DataFrame 'df' ({len(df)} rows). Use actual column names from the schema below.

                SCHEMA (use these column names in your code):
                {schema_str}
                {text_hint}

                You can answer: counts, breakdowns by category/priority/status, date ranges, text search in descriptions, top N, filters, aggregations. Use df and pandas only (no imports). Always set a variable 'result'.
                - Count: result = len(df) or result = len(df[mask]) or result = df['col'].value_counts()
                - Table: result = df[mask][list_of_cols].head(100) or result = df.groupby('col').size().reset_index(name='count')
                - Single number or text: result = 42 or result = "Answer: ..."

                User question: "{query}"
                Generate ONLY Python code that sets 'result'. No print, no imports.
                """
                response = self.model.generate_content(prompt)
                code = response.text.replace('```python', '').replace('```', '').strip()
                local_vars = {'df': df, 'result': None, 'pd': pd}
                exec(code, {"__builtins__": safe_builtins, "pd": pd}, local_vars)
                result_holder.append(local_vars.get('result'))
            except Exception as e:
                exc_holder.append(e)

        t = threading.Thread(target=run_code)
        t.daemon = True
        t.start()
        t.join(timeout=15)
        if t.is_alive():
            return {"type": "text", "data": "Query timed out (15s). Try a simpler question."}
        if exc_holder:
            return {"type": "text", "data": f"Error: {exc_holder[0]}"}
        if not result_holder:
            return {"type": "text", "data": "No result."}
        result = result_holder[0]
        if isinstance(result, pd.DataFrame):
            return {
                "type": "table",
                "data": result.head(20).to_dict(orient='records'),
                "count": len(result),
                "columns": result.columns.tolist()
            }
        elif isinstance(result, pd.Series):
            df_res = result.reset_index()
            df_res.columns = ["Key", "Value"]
            return {
                "type": "table",
                "data": df_res.to_dict(orient='records'),
                "count": len(df_res),
                "columns": ["Key", "Value"]
            }
        else:
            return {"type": "text", "data": str(result)}
