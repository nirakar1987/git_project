"""PostgreSQL session storage for ITSM Analytics."""
import os
import json
from contextlib import contextmanager
from datetime import datetime

from sqlalchemy import create_engine, Column, String, DateTime, Text, Boolean, text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import declarative_base, sessionmaker, Session

Base = declarative_base()
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://itsm:itsm_secret@localhost:5432/itsm_analytics")


class User(Base):
    __tablename__ = "users"

    id = Column(String(36), primary_key=True)
    username = Column(String(128), unique=True, nullable=False, index=True)
    hashed_password = Column(String(256), nullable=False)
    is_admin = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class AnalyticsSession(Base):
    __tablename__ = "analytics_sessions"

    session_id = Column(String(36), primary_key=True)
    filename = Column(String(512), nullable=False)
    chart_data = Column(JSONB, nullable=True)  # full chart_data dict
    ai_insights = Column(JSONB, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "session_id": self.session_id,
            "filename": self.filename,
            "chart_data": self.chart_data,
            "ai_insights": self.ai_insights,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def init_db():
    """Create tables if they don't exist. Add is_admin to users if missing (migration)."""
    Base.metadata.create_all(bind=engine)
    # Migration: add is_admin column if it doesn't exist (e.g. existing DBs before user management)
    try:
        with engine.connect() as conn:
            conn.execute(text(
                "ALTER TABLE users ADD COLUMN IF NOT EXISTS is_admin BOOLEAN DEFAULT FALSE NOT NULL"
            ))
            conn.commit()
    except Exception as e:
        # Ignore if column already exists or DB doesn't support IF NOT EXISTS
        if "already exists" not in str(e).lower() and "duplicate" not in str(e).lower():
            pass  # non-fatal


@contextmanager
def get_db_session():
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def save_session(session_id: str, filename: str, chart_data: dict, ai_insights: dict = None):
    """Persist session to PostgreSQL."""
    with get_db_session() as db:
        row = db.query(AnalyticsSession).filter(AnalyticsSession.session_id == session_id).first()
        if row:
            row.filename = filename
            row.chart_data = chart_data
            row.ai_insights = ai_insights
        else:
            db.add(AnalyticsSession(
                session_id=session_id,
                filename=filename,
                chart_data=chart_data,
                ai_insights=ai_insights,
            ))


def get_session_from_db(session_id: str):
    """Load session metadata from PostgreSQL. Returns dict with filename, chart_data, ai_insights or None."""
    db = SessionLocal()
    try:
        row = db.query(AnalyticsSession).filter(AnalyticsSession.session_id == session_id).first()
        if not row:
            return None
        return {
            "filename": row.filename,
            "chart_data": row.chart_data,
            "ai_insights": row.ai_insights,
        }
    finally:
        db.close()


def update_session_ai_insights(session_id: str, ai_insights: dict):
    """Update only ai_insights for a session."""
    with get_db_session() as db:
        row = db.query(AnalyticsSession).filter(AnalyticsSession.session_id == session_id).first()
        if row:
            row.ai_insights = ai_insights


def list_sessions(limit: int = 50):
    """List saved sessions (session_id, filename, created_at) ordered by created_at desc."""
    db = SessionLocal()
    try:
        rows = (
            db.query(AnalyticsSession.session_id, AnalyticsSession.filename, AnalyticsSession.created_at)
            .order_by(AnalyticsSession.created_at.desc())
            .limit(limit)
            .all()
        )
        return [
            {"session_id": r.session_id, "filename": r.filename, "created_at": r.created_at.isoformat() if r.created_at else None}
            for r in rows
        ]
    finally:
        db.close()

def delete_session(session_id: str) -> bool:
    """Delete a single session by ID. Returns True if deleted, False if not found."""
    with get_db_session() as db:
        row = db.query(AnalyticsSession).filter(AnalyticsSession.session_id == session_id).first()
        if row:
            db.delete(row)
            return True
        return False


def delete_all_sessions():
    """Delete ALL sessions."""
    with get_db_session() as db:
        db.query(AnalyticsSession).delete()


# --- Auth: user lookup by username ---
def get_user_by_username(username: str):
    """Return dict with username, hashed_password, is_admin or None."""
    db = SessionLocal()
    try:
        row = db.query(User).filter(User.username == username).first()
        if not row:
            return None
        return {
            "username": row.username,
            "hashed_password": row.hashed_password,
            "is_admin": getattr(row, "is_admin", False),
        }
    finally:
        db.close()


def create_user(username: str, hashed_password: str, is_admin: bool = False) -> bool:
    """Create a user. Returns True if created, False if username exists."""
    import uuid
    with get_db_session() as db:
        if db.query(User).filter(User.username == username).first():
            return False
        db.add(User(
            id=str(uuid.uuid4()),
            username=username,
            hashed_password=hashed_password,
            is_admin=is_admin,
        ))
        return True


def update_user_password(username: str, hashed_password: str) -> bool:
    """Update password for existing user. Returns True if updated."""
    with get_db_session() as db:
        row = db.query(User).filter(User.username == username).first()
        if not row:
            return False
        row.hashed_password = hashed_password
        return True


def update_user_admin(username: str, is_admin: bool) -> bool:
    """Set is_admin for a user. Returns True if updated."""
    with get_db_session() as db:
        row = db.query(User).filter(User.username == username).first()
        if not row:
            return False
        row.is_admin = is_admin
        return True


def list_users():
    """List all users (username, is_admin, created_at)."""
    db = SessionLocal()
    try:
        rows = db.query(User.username, User.is_admin, User.created_at).order_by(User.created_at).all()
        return [
            {"username": r.username, "is_admin": bool(r.is_admin), "created_at": r.created_at.isoformat() if r.created_at else None}
            for r in rows
        ]
    finally:
        db.close()


def delete_user(username: str) -> bool:
    """Delete a user by username. Returns True if deleted."""
    with get_db_session() as db:
        row = db.query(User).filter(User.username == username).first()
        if not row:
            return False
        db.delete(row)
        return True

