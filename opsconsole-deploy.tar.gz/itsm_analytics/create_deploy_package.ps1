# Create OpsConsole deployment package for transfer to another server.
# Excludes: node_modules, __pycache__, .git, frontend/dist, .env, existing *.tar.gz
# Run from project root: .\create_deploy_package.ps1

$ErrorActionPreference = "Stop"
$projectRoot = $PSScriptRoot
$outName = "opsconsole-deploy.tar.gz"
$outPath = Join-Path $projectRoot $outName

# Remove previous package if exists
if (Test-Path $outPath) { Remove-Item $outPath -Force }

Write-Host "Creating deployment package: $outName" -ForegroundColor Cyan
Write-Host "Project root: $projectRoot" -ForegroundColor Gray

Push-Location (Split-Path $projectRoot -Parent)
$folderName = Split-Path $projectRoot -Leaf

# Use tar (Windows 10+). Exclude by pattern so node_modules/__pycache__ are not included.
& tar -czvf $outPath `
  --exclude=node_modules `
  --exclude=__pycache__ `
  --exclude=.git `
  --exclude=frontend/dist `
  --exclude=.env `
  --exclude="*.tar.gz" `
  --exclude="*.zip" `
  $folderName

Pop-Location

$size = (Get-Item $outPath).Length / 1MB
Write-Host "Done. Package: $outPath ($([math]::Round($size, 2)) MB)" -ForegroundColor Green
Write-Host "Copy this file to the new server, then see DEPLOY_PACKAGE_README.md for deployment steps." -ForegroundColor Yellow
