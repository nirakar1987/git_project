import React from 'react';
import { LayoutDashboard, BarChart3, BrainCircuit, Trash2, LogOut, Users } from 'lucide-react';

export default function Sidebar({
    activeTab,
    setActiveTab,
    savedSessions,
    currentSessionId,
    onLoadSession,
    onDeleteSession,
    onClearAllSessions,
    onLogout,
    currentUser,
}) {
    return (
        <div className="sidebar">
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '40px' }}>
                <img src="/logo.png" alt="OpsConsole" style={{ width: 40, height: 40, objectFit: 'contain' }} />
                <h2 style={{ fontSize: '20px', fontWeight: 'bold' }}>OpsConsole</h2>
            </div>

            <nav>
                <button type="button" onClick={() => setActiveTab('dashboard')} className={`nav-link ${activeTab === 'dashboard' ? 'active' : ''}`}>
                    <LayoutDashboard size={20} /> Dashboard
                </button>
                <button type="button" onClick={() => setActiveTab('overview')} className={`nav-link ${activeTab === 'overview' ? 'active' : ''}`}>
                    <LayoutDashboard size={20} /> Overview
                </button>
                <button type="button" onClick={() => setActiveTab('workload')} className={`nav-link ${activeTab === 'workload' ? 'active' : ''}`}>
                    <BarChart3 size={20} /> Workload
                </button>
                <button type="button" onClick={() => setActiveTab('sla')} className={`nav-link ${activeTab === 'sla' ? 'active' : ''}`}>
                    <BrainCircuit size={20} /> SLA analysis
                </button>
                {currentUser?.is_admin && (
                    <button type="button" onClick={() => setActiveTab('users')} className={`nav-link ${activeTab === 'users' ? 'active' : ''}`}>
                        <Users size={20} /> User management
                    </button>
                )}
                <div style={{ padding: '24px 12px 12px', fontSize: '11px', fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Data Source</div>
                {savedSessions.length > 0 && (
                    <div style={{ marginTop: '8px', paddingLeft: '12px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                            <div style={{ fontSize: '11px', fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Saved data</div>
                            <button
                                onClick={onClearAllSessions}
                                style={{ background: 'transparent', border: 'none', color: 'var(--danger)', fontSize: '10px', cursor: 'pointer', padding: '2px 6px', borderRadius: '4px' }}
                            >CLEAR ALL</button>
                        </div>
                        <div className="session-list">
                            {savedSessions.map((s) => (
                                <div key={s.session_id} style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
                                    <button
                                        type="button"
                                        onClick={() => onLoadSession(s.session_id)}
                                        className={`session-btn ${currentSessionId === s.session_id ? 'active' : ''}`}
                                        title={s.filename}
                                        style={{ paddingRight: '30px' }}
                                    >
                                        {s.filename || 'Untitled Session'}
                                    </button>
                                    <button
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            onDeleteSession(s.session_id);
                                        }}
                                        className="delete-session-btn"
                                        title="Delete"
                                    >
                                        <Trash2 size={13} />
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </nav>
            {onLogout && (
                <div style={{ position: 'absolute', bottom: '24px', left: '24px', right: '24px' }}>
                    <button
                        type="button"
                        onClick={onLogout}
                        className="nav-link"
                        style={{ width: '100%', justifyContent: 'center', color: 'var(--text-muted)' }}
                    >
                        <LogOut size={20} /> Sign out
                    </button>
                </div>
            )}
        </div>
    );
}
