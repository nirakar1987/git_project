import React, { useState } from 'react';
import axios from 'axios';
import { motion } from 'framer-motion';
import { LogIn } from 'lucide-react';
import { setAuth } from '../auth';

// Login uses path relative to axios baseURL (set in main.jsx) to avoid /api/api/...

const APP_NAME = 'OpsConsole';
const APP_TAGLINE = 'Service desk analytics at a glance';

export default function Login({ onLogin }) {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setLoading(true);
        try {
            const formData = new URLSearchParams();
            formData.append('username', username.trim());
            formData.append('password', password);
            const res = await axios.post('/auth/login', formData, {
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            });
            const { access_token, username: uname } = res.data;
            setAuth(access_token, { username: uname });
            onLogin?.();
        } catch (err) {
            const msg = err.response?.data?.detail ?? err.response?.status === 401
                ? 'Invalid username or password'
                : 'Login failed. Try again.';
            setError(typeof msg === 'string' ? msg : 'Login failed.');
        } finally {
            setLoading(false);
        }
    };

    const container = {
        hidden: { opacity: 0 },
        show: {
            opacity: 1,
            transition: { staggerChildren: 0.08, delayChildren: 0.2 },
        },
    };
    const item = {
        hidden: { opacity: 0, y: 16 },
        show: { opacity: 1, y: 0 },
    };

    return (
        <div className="login-page">
            <motion.div
                className="login-bg-glow"
                animate={{
                    opacity: [0.8, 1.2, 0.8],
                    scale: [1, 1.05, 1],
                }}
                transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
            />
            <motion.div
                className="login-card"
                initial={{ opacity: 0, y: 32 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, ease: [0.25, 0.46, 0.45, 0.94] }}
            >
                <div className="login-header">
                    <motion.div
                        className="login-logo-wrap"
                        initial={{ scale: 0.5, opacity: 0, rotate: -10 }}
                        animate={{
                            scale: 1,
                            opacity: 1,
                            rotate: 0,
                            y: [0, -6, 0],
                        }}
                        transition={{
                            scale: { duration: 0.5, delay: 0.1 },
                            opacity: { duration: 0.4 },
                            rotate: { duration: 0.4 },
                            y: { duration: 3.5, repeat: Infinity, ease: 'easeInOut' },
                        }}
                    >
                        <img src="/logo.png" alt="OpsConsole" className="login-logo" />
                    </motion.div>
                    <motion.h1
                        className="login-title"
                        initial={{ opacity: 0, y: 12 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.25, duration: 0.4 }}
                    >
                        {APP_NAME}
                    </motion.h1>
                    <motion.p
                        className="login-subtitle"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.35, duration: 0.4 }}
                    >
                        {APP_TAGLINE}
                    </motion.p>
                    <motion.p
                        className="login-signin-label"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.45, duration: 0.4 }}
                    >
                        Sign in to continue
                    </motion.p>
                </div>
                <form onSubmit={handleSubmit} className="login-form">
                    <motion.div variants={container} initial="hidden" animate="show">
                        <motion.label variants={item}>
                            <span>Username</span>
                            <input
                                type="text"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                placeholder="Enter your username"
                                autoComplete="username"
                                autoFocus
                                disabled={loading}
                            />
                        </motion.label>
                        <motion.label variants={item}>
                            <span>Password</span>
                            <input
                                type="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                placeholder="Enter your password"
                                autoComplete="current-password"
                                disabled={loading}
                            />
                        </motion.label>
                        {error && (
                            <motion.div
                                className="login-error"
                                role="alert"
                                initial={{ opacity: 0, x: -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ type: 'spring', stiffness: 400, damping: 25 }}
                            >
                                {error}
                            </motion.div>
                        )}
                        <motion.div variants={item}>
                            <motion.button
                                type="submit"
                                className="login-btn"
                                disabled={loading}
                                whileHover={loading ? {} : { scale: 1.02, boxShadow: '0 8px 24px rgba(129, 140, 248, 0.5)' }}
                                whileTap={loading ? {} : { scale: 0.98 }}
                                transition={{ type: 'spring', stiffness: 400, damping: 17 }}
                            >
                                {loading ? (
                                    <span className="login-spinner" />
                                ) : (
                                    <>
                                        <LogIn size={20} strokeWidth={2.5} />
                                        Sign in
                                    </>
                                )}
                            </motion.button>
                        </motion.div>
                    </motion.div>
                </form>
            </motion.div>
            <style>{`
                .login-page {
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 24px;
                    position: relative;
                    overflow: hidden;
                    background: linear-gradient(160deg, #0a0812 0%, #12101a 35%, #0d0b14 70%, #08060e 100%);
                }
                .login-page::before {
                    content: '';
                    position: absolute;
                    inset: 0;
                    background: radial-gradient(circle at 30% 20%, rgba(129, 140, 248, 0.04) 0%, transparent 40%),
                                radial-gradient(circle at 70% 80%, rgba(167, 139, 250, 0.03) 0%, transparent 40%);
                    animation: login-bg-shift 12s ease-in-out infinite alternate;
                    pointer-events: none;
                }
                @keyframes login-bg-shift {
                    0% { opacity: 0.6; transform: scale(1) translate(0, 0); }
                    100% { opacity: 1; transform: scale(1.1) translate(2%, 1%); }
                }
                .login-bg-glow {
                    position: absolute;
                    width: 140%;
                    height: 140%;
                    top: -20%;
                    left: -20%;
                    background: radial-gradient(ellipse 55% 45% at 50% 35%, rgba(129, 140, 248, 0.15) 0%, transparent 50%),
                                radial-gradient(ellipse 45% 45% at 75% 75%, rgba(167, 139, 250, 0.1) 0%, transparent 50%),
                                radial-gradient(ellipse 35% 35% at 20% 60%, rgba(129, 140, 248, 0.06) 0%, transparent 45%);
                    pointer-events: none;
                    will-change: opacity, transform;
                }
                .login-card {
                    width: 100%;
                    max-width: 420px;
                    position: relative;
                    background: linear-gradient(180deg, rgba(22, 20, 36, 0.95) 0%, rgba(18, 16, 28, 0.98) 100%);
                    border: 1px solid rgba(129, 140, 248, 0.2);
                    border-radius: 24px;
                    padding: 48px 44px;
                    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5),
                                0 0 0 1px rgba(255,255,255,0.03) inset,
                                0 0 80px -20px rgba(129, 140, 248, 0.15);
                    animation: login-card-glow 6s ease-in-out infinite alternate;
                }
                @keyframes login-card-glow {
                    0% { box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.03) inset, 0 0 60px -20px rgba(129, 140, 248, 0.12); }
                    100% { box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.04) inset, 0 0 100px -15px rgba(129, 140, 248, 0.2); }
                }
                .login-header {
                    text-align: center;
                    margin-bottom: 36px;
                }
                .login-logo-wrap {
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                }
                .login-logo {
                    width: 72px;
                    height: 72px;
                    display: block;
                    object-fit: contain;
                }
                .login-title {
                    font-size: 1.85rem;
                    font-weight: 700;
                    margin-top: 20px;
                    margin-bottom: 4px;
                    letter-spacing: -0.02em;
                    background: linear-gradient(135deg, #f8fafc 0%, #c7d2fe 100%);
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                    background-clip: text;
                }
                .login-subtitle {
                    color: rgba(148, 163, 184, 0.9);
                    font-size: 0.9rem;
                    margin-bottom: 8px;
                    font-weight: 500;
                }
                .login-signin-label {
                    color: var(--text-muted);
                    font-size: 0.85rem;
                    margin-top: 0;
                }
                .login-form label {
                    display: block;
                    margin-bottom: 18px;
                }
                .login-form label span {
                    display: block;
                    font-size: 0.8rem;
                    font-weight: 600;
                    color: var(--text-muted);
                    margin-bottom: 8px;
                    text-transform: uppercase;
                    letter-spacing: 0.04em;
                }
                .login-form input {
                    width: 100%;
                    padding: 14px 16px;
                    background: rgba(15, 13, 24, 0.8);
                    border: 1px solid rgba(148, 163, 184, 0.15);
                    border-radius: 12px;
                    color: var(--text-main);
                    font-size: 1rem;
                    transition: border-color 0.2s, box-shadow 0.2s;
                }
                .login-form input:focus {
                    outline: none;
                    border-color: rgba(129, 140, 248, 0.5);
                    box-shadow: 0 0 0 3px rgba(129, 140, 248, 0.15);
                }
                .login-form input::placeholder {
                    color: var(--text-muted);
                    opacity: 0.6;
                }
                .login-error {
                    background: rgba(248, 113, 113, 0.12);
                    border: 1px solid rgba(248, 113, 113, 0.35);
                    color: #fca5a5;
                    padding: 12px 14px;
                    border-radius: 12px;
                    font-size: 0.9rem;
                    margin-bottom: 18px;
                }
                .login-btn {
                    width: 100%;
                    padding: 16px;
                    background: linear-gradient(135deg, #818cf8 0%, #a78bfa 100%);
                    color: #fff;
                    border: none;
                    border-radius: 12px;
                    font-size: 1rem;
                    font-weight: 600;
                    cursor: pointer;
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    gap: 10px;
                    box-shadow: 0 4px 14px rgba(129, 140, 248, 0.4);
                    transition: transform 0.2s, box-shadow 0.2s;
                }
                .login-btn:hover:not(:disabled) {
                    transform: translateY(-1px);
                    box-shadow: 0 6px 20px rgba(129, 140, 248, 0.45);
                }
                .login-btn:disabled {
                    opacity: 0.8;
                    cursor: not-allowed;
                    transform: none;
                }
                .login-spinner {
                    width: 20px;
                    height: 20px;
                    border: 2px solid rgba(255,255,255,0.3);
                    border-top-color: #fff;
                    border-radius: 50%;
                    animation: spin 0.8s linear infinite;
                }
                @keyframes spin { to { transform: rotate(360deg); } }
            `}</style>
        </div>
    );
}
