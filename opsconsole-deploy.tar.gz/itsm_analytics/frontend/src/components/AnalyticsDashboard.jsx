import React, { useState, useEffect } from 'react';
import {
    BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
    PieChart, Pie, Cell, Legend, LineChart, Line, AreaChart, Area, LabelList
} from 'recharts';
import { Download, BrainCircuit, Filter, Database, Ticket, CheckCircle, AlertTriangle, Clock, Palette } from 'lucide-react';
import { motion } from 'framer-motion';
import axios from 'axios';

// Path relative to axios baseURL (set in main.jsx)

/* Theme palette: purple, green, blue, pink (reference dashboard) */
const COLORS = ['#818cf8', '#34d399', '#38bdf8', '#f472b6', '#c084fc', '#22d3ee', '#fb7185', '#fbbf24', '#a78bfa'];
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/* Animation Variants */
const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
        opacity: 1,
        transition: {
            staggerChildren: 0.15,
            delayChildren: 0.1
        }
    }
};

const itemVariants = {
    hidden: { y: 30, opacity: 0, scale: 0.95 },
    visible: {
        y: 0,
        opacity: 1,
        scale: 1,
        transition: { type: "spring", stiffness: 50, damping: 15 }
    }
};

/* Special Variants for Leaderboard */
const listContainerVariants = {
    hidden: { opacity: 0 },
    visible: {
        opacity: 1,
        transition: {
            staggerChildren: 0.1,
            delayChildren: 0.3
        }
    }
};

const listItemVariants = {
    hidden: { x: -20, opacity: 0 },
    visible: {
        x: 0,
        opacity: 1,
        transition: { type: "spring", stiffness: 100, damping: 12 }
    }
};

/* Pie chart tooltip: light text so hover data shows clearly; wrapper avoids black box */
const PIE_TOOLTIP_STYLE = {
    backgroundColor: '#1e1b35',
    border: '1px solid rgba(129, 140, 248, 0.4)',
    borderRadius: '10px',
    color: '#f8fafc',
    fontSize: 13,
    fontWeight: 600,
    padding: '10px 14px',
};
const PIE_TOOLTIP_WRAPPER_STYLE = {
    outline: 'none',
    backgroundColor: '#1e1b35',
    border: '1px solid rgba(129, 140, 248, 0.4)',
    borderRadius: '10px',
    padding: 0,
    boxShadow: '0 4px 12px rgba(0,0,0,0.4)',
};

/* 3D-style: volumetric bars (light blue, green, pink, orange) + beveled pie/donut */
const BAR_3D_COLORS = ['#7dd3fc', '#6ee7b7', '#f9a8d4', '#fbbf24', '#a78bfa', '#67e8f9', '#fb7185', '#fcd34d', '#c4b5fd'];
function get3dDefs(prefix = 'default') {
    const p = prefix;
    return (
        <defs>
            <linearGradient id={`bar3dVertical_${p}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#c4b5fd" stopOpacity={1} />
                <stop offset="35%" stopColor="#818cf8" stopOpacity={1} />
                <stop offset="100%" stopColor="#4f46e5" stopOpacity={0.95} />
            </linearGradient>
            <linearGradient id={`bar3dHorizontal_${p}`} x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#4f46e5" stopOpacity={0.9} />
                <stop offset="50%" stopColor="#818cf8" stopOpacity={1} />
                <stop offset="100%" stopColor="#a78bfa" stopOpacity={1} />
            </linearGradient>
            {BAR_3D_COLORS.map((c, i) => (
                <linearGradient key={`v${i}`} id={`bar3dV_${p}_${i}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={c} stopOpacity={1} />
                    <stop offset="100%" stopColor={c} stopOpacity={0.6} />
                </linearGradient>
            ))}
            {BAR_3D_COLORS.map((c, i) => (
                <linearGradient key={`h${i}`} id={`bar3dH_${p}_${i}`} x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor={c} stopOpacity={0.7} />
                    <stop offset="100%" stopColor={c} stopOpacity={1} />
                </linearGradient>
            ))}
            {COLORS.map((c, i) => (
                <radialGradient key={`pie${i}`} id={`pie3d_${p}_${i}`} cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stopColor="#fff" stopOpacity={0.35} />
                    <stop offset="50%" stopColor={c} stopOpacity={0.95} />
                    <stop offset="100%" stopColor={c} stopOpacity={0.8} />
                </radialGradient>
            ))}
            <filter id={`pieShadow_${p}`} x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="0" dy="2" stdDeviation="2" floodOpacity="0.25" />
            </filter>
        </defs>
    );
}

/* Color Themes */
const THEMES = {
    cosmic: {
        name: 'Cosmic Deep',
        icon: '🌌',
        colors: {
            '--background': '#0c0a14',
            '--background-subtle': '#12101a',
            '--card': '#16132a',
            '--card-hover': '#1e1b35',
            '--text-main': '#f8fafc',
            '--text-muted': '#94a3b8',
            '--border': '#2d2a42',
            '--accent': '#818cf8',
            '--accent-soft': 'rgba(129, 140, 248, 0.15)',
            '--sidebar-bg': 'linear-gradient(180deg, #12101f 0%, #0e0c18 100%)',
            '--radius': '16px',
            '--card-shadow': '0 4px 20px rgba(0, 0, 0, 0.2)'
        }
    },
    light: {
        name: 'Executive Light',
        icon: '🏙️',
        colors: {
            '--background': '#f8fafc',
            '--background-subtle': '#f1f5f9',
            '--card': '#ffffff',
            '--card-hover': '#f8fafc',
            '--text-main': '#0f172a',
            '--text-muted': '#64748b',
            '--border': '#e2e8f0',
            '--accent': '#4f46e5',
            '--accent-soft': 'rgba(79, 70, 229, 0.08)',
            '--sidebar-bg': '#ffffff',
            '--radius': '8px',
            '--card-shadow': '0 1px 3px rgba(0, 0, 0, 0.1)'
        }
    },
    midnight: {
        name: 'Midnight Pro',
        icon: '🌙',
        colors: {
            '--background': '#020617',
            '--background-subtle': '#0f172a',
            '--card': '#1e293b',
            '--card-hover': '#334155',
            '--text-main': '#f8fafc',
            '--text-muted': '#94a3b8',
            '--border': '#1e293b',
            '--accent': '#38bdf8',
            '--accent-soft': 'rgba(56, 189, 248, 0.15)',
            '--sidebar-bg': '#0f172a',
            '--radius': '24px',
            '--card-shadow': 'none'
        }
    },
    emerald: {
        name: 'Emerald Forest',
        icon: '🌲',
        colors: {
            '--background': '#022c22',
            '--background-subtle': '#064e3b',
            '--card': '#065f46',
            '--card-hover': '#047857',
            '--text-main': '#ecfdf5',
            '--text-muted': '#a7f3d0',
            '--border': '#064e3b',
            '--accent': '#34d399',
            '--accent-soft': 'rgba(52, 211, 153, 0.2)',
            '--sidebar-bg': '#022c22',
            '--radius': '16px',
            '--card-shadow': '0 10px 30px rgba(0, 0, 0, 0.25)'
        }
    },
    sunset: {
        name: 'Sunset Horizon',
        icon: '🌅',
        colors: {
            '--background': '#2a0a18',
            '--background-subtle': '#4a0e26',
            '--card': '#5e132e',
            '--card-hover': '#831843',
            '--text-main': '#fff1f2',
            '--text-muted': '#fda4af',
            '--border': '#831843',
            '--accent': '#fb7185',
            '--accent-soft': 'rgba(251, 113, 133, 0.2)',
            '--sidebar-bg': '#2a0a18',
            '--radius': '12px',
            '--card-shadow': '0 4px 15px rgba(251, 113, 133, 0.15)'
        }
    },
    oceanic: {
        name: 'Oceanic Depth',
        icon: '🌊',
        colors: {
            '--background': '#082f49',
            '--background-subtle': '#0c4a6e',
            '--card': '#075985',
            '--card-hover': '#0369a1',
            '--text-main': '#f0f9ff',
            '--text-muted': '#bae6fd',
            '--border': '#0c4a6e',
            '--accent': '#38bdf8',
            '--accent-soft': 'rgba(56, 189, 248, 0.2)',
            '--sidebar-bg': '#082f49',
            '--radius': '20px',
            '--card-shadow': '0 8px 32px rgba(8, 47, 73, 0.4)'
        }
    },
    royal: {
        name: 'Royal Amethyst',
        icon: '👑',
        colors: {
            '--background': '#2e1065',
            '--background-subtle': '#4c1d95',
            '--card': '#5b21b6',
            '--card-hover': '#6d28d9',
            '--text-main': '#faf5ff',
            '--text-muted': '#ddd6fe',
            '--border': '#4c1d95',
            '--accent': '#a78bfa',
            '--accent-soft': 'rgba(167, 139, 250, 0.2)',
            '--sidebar-bg': '#2e1065',
            '--radius': '8px',
            '--card-shadow': '0 0 20px rgba(167, 139, 250, 0.2)'
        }
    },
    cyber: {
        name: 'Cyber Punk',
        icon: '🦾',
        colors: {
            '--background': '#000000',
            '--background-subtle': '#111111',
            '--card': '#18181b',
            '--card-hover': '#27272a',
            '--text-main': '#e4e4e7',
            '--text-muted': '#a1a1aa',
            '--border': '#facc15',
            '--accent': '#d946ef',
            '--accent-soft': 'rgba(217, 70, 239, 0.15)',
            '--sidebar-bg': '#000000',
            '--radius': '0px',
            '--card-shadow': '4px 4px 0px rgba(217, 70, 239, 0.4)'
        }
    }
};

export default function Dashboard({
    data,
    chartData,
    activeTab,
    setActiveTab,
    recordTypeFilter,
    setRecordTypeFilter,
    setMonthDetailModal,
    setWorkloadTicketsModal,
    exportBreachListCSV,
    aiLoading,
    sessionId,
    slicerMonth,
    setSlicerMonth,
    slicerCategory,
    setSlicerCategory,
    slicerPriority,
    setSlicerPriority,
    clearSlicers,
    slicersLoading,
    baseChartData,
}) {
    const [theme, setTheme] = useState('cosmic');
    const [showThemeMenu, setShowThemeMenu] = useState(false);
    const [rawData, setRawData] = useState({ columns: [], rows: [], total: 0, offset: 0, limit: 50 });
    const [rawDataLoading, setRawDataLoading] = useState(false);

    /* Apply Theme */
    useEffect(() => {
        const root = document.documentElement;
        const themeConfig = THEMES[theme].colors;
        Object.entries(themeConfig).forEach(([key, value]) => {
            root.style.setProperty(key, value);
        });
    }, [theme]);

    useEffect(() => {
        if (activeTab !== 'dashboard' || !sessionId) return;
        setRawDataLoading(true);
        axios.get('/raw-data', { params: { session_id: sessionId, limit: rawData.limit, offset: rawData.offset } })
            .then((res) => setRawData({ columns: res.data.columns || [], rows: res.data.rows || [], total: res.data.total || 0, offset: res.data.offset || 0, limit: res.data.limit || 50 }))
            .catch(() => setRawData((prev) => ({ ...prev, rows: [] })))
            .finally(() => setRawDataLoading(false));
    }, [activeTab, sessionId, rawData.offset, rawData.limit]);
    if (!data) return null;

    return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <div className="top-bar" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
                <div>
                    <h2 className="top-bar-title" style={{ fontSize: '24px', fontWeight: 'bold' }}>{activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Overview</h2>
                    <p className="top-bar-subtitle" style={{ color: 'var(--text-muted)', fontSize: '14px' }}>Real-time metrics & performance indicators</p>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                    <div style={{ position: 'relative' }}>
                        <button
                            className="header-btn"
                            onClick={() => setShowThemeMenu(!showThemeMenu)}
                            title="Change Theme"
                            style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 12px', background: 'var(--card)', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--text-muted)', cursor: 'pointer' }}
                        >
                            <Palette size={16} /> Theme
                        </button>
                        {showThemeMenu && (
                            <div className="dropdown-menu show" style={{ position: 'absolute', top: '100%', right: 0, marginTop: '8px', minWidth: '180px', background: 'var(--card)', border: '1px solid var(--border)', borderRadius: '12px', padding: '8px', zIndex: 100, boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.3)' }}>
                                {Object.entries(THEMES).map(([key, config]) => (
                                    <div
                                        key={key}
                                        onClick={() => { setTheme(key); setShowThemeMenu(false); }}
                                        style={{
                                            display: 'flex', alignItems: 'center', gap: '8px',
                                            padding: '8px 12px', borderRadius: '6px', cursor: 'pointer',
                                            background: theme === key ? 'var(--accent-soft)' : 'transparent',
                                            color: theme === key ? 'var(--accent)' : 'var(--text-main)',
                                            fontSize: '13px'
                                        }}
                                    >
                                        <span>{config.icon}</span>
                                        <span>{config.name}</span>
                                        {theme === key && <CheckCircle size={14} style={{ marginLeft: 'auto', color: 'var(--success)' }} />}
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                    <div className="date-display" style={{ fontSize: '14px', fontWeight: 500, color: 'var(--text-muted)' }}>
                        {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                    </div>
                </div>
            </div>
            {!chartData && (
                <div style={{ padding: '24px', background: 'rgba(251, 113, 133, 0.1)', borderRadius: '8px', marginBottom: '24px', color: '#fb7185' }}>
                    No chart data received. Try uploading a CSV or Excel file again.
                </div>
            )}
            {chartData && (
                <>
                    {/* Verification & Period Info */}
                    {data.verification?.message && (
                        <p style={{ fontSize: '13px', color: 'var(--accent)', marginBottom: '12px' }} title={data.verification.date_columns_corrected?.length ? `Dates corrected: ${data.verification.date_columns_corrected.join(', ')}` : ''}>
                            ✓ {data.verification.message}
                        </p>
                    )}
                    {chartData?.data_period && (
                        <p style={{ fontSize: '12px', color: 'var(--text-muted)', marginBottom: '16px' }}>
                            System Status: <span style={{ color: 'var(--success)' }}>Active</span> · Reporting Period: <strong>{chartData.data_period}</strong>
                        </p>
                    )}

                    {/* Filters / Slicers – top of page */}
                    <div className="slicers-row slicers-row-top slicers-row-animated">
                        <div className="slicer-box">
                            <span className="slicer-label">Monthly Slicer</span>
                            <div className="slicer-months">
                                {(chartData?.workload ?? []).map((r) => r.name).filter((n) => n && String(n) !== 'Unknown').length > 0
                                    ? (chartData.workload || []).map((r) => r.name).filter((n) => n && String(n) !== 'Unknown').map((m) => (
                                        <button key={m} type="button" className={`slicer-month-btn ${slicerMonth === m ? 'active slicer-active-pulse' : ''}`} onClick={() => setSlicerMonth(slicerMonth === m ? '' : m)}>{m}</button>
                                    ))
                                    : MONTHS.map((m) => (
                                        <button key={m} type="button" className={`slicer-month-btn ${slicerMonth === m ? 'active slicer-active-pulse' : ''}`} onClick={() => setSlicerMonth(slicerMonth === m ? '' : m)}>{m}</button>
                                    ))}
                            </div>
                        </div>
                        <div className="slicer-box">
                            <span className="slicer-label">Category</span>
                            <select value={slicerCategory} onChange={(e) => setSlicerCategory(e.target.value)} className="slicer-select">
                                <option value="">All</option>
                                {(baseChartData?.services ?? chartData?.services ?? []).slice(0, 20).map((s) => (
                                    <option key={s.name || s} value={s.name || s}>{s.name || s} ({s.value ?? 0})</option>
                                ))}
                            </select>
                        </div>
                        <div className="slicer-box">
                            <span className="slicer-label">Priority</span>
                            <select value={slicerPriority} onChange={(e) => setSlicerPriority(e.target.value)} className="slicer-select">
                                <option value="">All</option>
                                {(baseChartData?.priority ?? chartData?.priority ?? []).map((p) => (
                                    <option key={p.name} value={p.name}>{p.name} ({p.value})</option>
                                ))}
                            </select>
                        </div>
                        <button type="button" className="header-btn header-btn-ghost slicer-clear-btn" onClick={clearSlicers} disabled={slicersLoading}>Clear filters</button>
                    </div>

                    {/* Record Type Filter & Pie */}
                    {data?.chart_data?.record_type_counts && Object.keys(data.chart_data.record_type_counts).length > 0 && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '16px', flexWrap: 'wrap', marginBottom: '16px', padding: '12px 16px', background: 'rgba(129, 140, 248, 0.06)', borderRadius: '12px', border: '1px solid rgba(129, 140, 248, 0.2)' }}>
                            <span style={{ fontSize: '13px', color: 'var(--text-muted)', fontWeight: 600 }}>Show:</span>
                            <select value={recordTypeFilter} onChange={(e) => setRecordTypeFilter(e.target.value)} style={{ padding: '6px 12px', borderRadius: '6px', border: '1px solid var(--border)', background: 'var(--card)', color: 'inherit', fontSize: '13px' }}>
                                <option value="All">All</option>
                                {Object.keys(data.chart_data.record_type_counts).map((t) => (
                                    <option key={t} value={t}>{t} ({data.chart_data.record_type_counts[t]})</option>
                                ))}
                            </select>
                            {Object.keys(data.chart_data.record_type_counts).length > 1 && (
                                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginLeft: '8px' }}>
                                    <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Volume by type:</span>
                                    <div style={{ width: '120px', height: '48px' }}>
                                        <ResponsiveContainer width="100%" height="100%">
                                            <PieChart>
                                                {get3dDefs('recType')}
                                                <Pie data={Object.entries(data.chart_data.record_type_counts).map(([name, value], i) => ({ name, value }))} cx="50%" cy="50%" innerRadius={14} outerRadius={22} paddingAngle={2} dataKey="value">
                                                    <LabelList dataKey="value" position="inside" fill="#f8fafc" fontSize={9} fontWeight={600} />
                                                    {Object.keys(data.chart_data.record_type_counts).map((_, i) => <Cell key={i} fill={`url(#pie3d_recType_${i % COLORS.length})`} />)}
                                                </Pie>
                                                <Tooltip contentStyle={PIE_TOOLTIP_STYLE} itemStyle={{ color: '#f8fafc' }} wrapperStyle={PIE_TOOLTIP_WRAPPER_STYLE} formatter={(v, name) => [v, name ?? '']} />
                                            </PieChart>
                                        </ResponsiveContainer>
                                    </div>
                                </div>
                            )}
                        </div>
                    )}

                    {/* Tab Navigation */}
                    <div className="tab-container">
                        <button className={`tab-btn ${activeTab === 'dashboard' ? 'active' : ''}`} onClick={() => setActiveTab('dashboard')}>Dashboard</button>
                        <button className={`tab-btn ${activeTab === 'overview' ? 'active' : ''}`} onClick={() => setActiveTab('overview')}>Overview</button>
                        <button className={`tab-btn ${activeTab === 'workload' ? 'active' : ''}`} onClick={() => setActiveTab('workload')}>Workload Analysis</button>
                        <button className={`tab-btn ${activeTab === 'sla' ? 'active' : ''}`} onClick={() => setActiveTab('sla')}>SLA Analysis</button>
                    </div>

                    {/* Dashboard Tab - Reference-style grid */}
                    {activeTab === 'dashboard' && (
                        <motion.div
                            className="dashboard-grid-wrap"
                            variants={containerVariants}
                            initial="hidden"
                            animate="visible"
                        >
                            {/* KPIs */}
                            <div className="kpi-grid">
                                <motion.div variants={itemVariants} className="kpi-card kpi-card-vibrant blue kpi-card-animated">

                                    <div className="kpi-header">
                                        <div className="kpi-icon kpi-icon-pulse"><Ticket size={24} /></div>
                                        <span className="kpi-label">Total Tickets</span>
                                    </div>
                                    <div>
                                        <span className="kpi-value">{chartData?.total_tickets ?? '—'}</span>
                                    </div>
                                </motion.div>
                                <motion.div variants={itemVariants} className="kpi-card kpi-card-vibrant green kpi-card-animated">
                                    <div className="kpi-header">
                                        <div className="kpi-icon kpi-icon-pulse"><CheckCircle size={24} /></div>
                                        <span className="kpi-label">SLA Met</span>
                                    </div>
                                    <div>
                                        <span className="kpi-value">{chartData?.sla_met_pct != null ? `${chartData.sla_met_pct}%` : 'N/A'}</span>
                                    </div>
                                </motion.div>
                                <motion.div variants={itemVariants} className="kpi-card kpi-card-vibrant red kpi-card-animated">
                                    <div className="kpi-header">
                                        <div className="kpi-icon kpi-icon-pulse"><AlertTriangle size={24} /></div>
                                        <span className="kpi-label">Breached</span>
                                    </div>
                                    <div>
                                        <span className="kpi-value">{chartData?.breach_list?.length ?? 0}</span>
                                    </div>
                                </motion.div>
                                <motion.div variants={itemVariants} className="kpi-card kpi-card-vibrant purple kpi-card-animated">
                                    <div className="kpi-header">
                                        <div className="kpi-icon kpi-icon-pulse"><Clock size={24} /></div>
                                        <span className="kpi-label">Avg Resolution</span>
                                    </div>
                                    <div>
                                        <span className="kpi-value">{chartData?.avg_resolve_hours != null ? `${chartData.avg_resolve_hours}h` : 'N/A'}</span>
                                    </div>
                                </motion.div>
                            </div>

                            {/* Row 1: Top 5 + Workload line + SLA donut */}
                            <div className="dashboard-grid dashboard-grid-row1">
                                <motion.div variants={itemVariants} className="chart-card chart-card-animated dashboard-widget">
                                    <h4 style={{ fontSize: '13px', marginBottom: '16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                        <span>Top 5 Categories</span>
                                        <span style={{ fontSize: '10px', color: 'var(--text-muted)' }}>VOLUME</span>
                                    </h4>
                                    <motion.div
                                        className="leaderboard-list"
                                        variants={listContainerVariants}
                                        initial="hidden"
                                        animate="visible"
                                    >
                                        {(chartData?.services ?? []).slice(0, 5).map((s, i) => {
                                            const maxVal = (chartData?.services ?? [])[0]?.value || 1;
                                            const pct = Math.round((s.value / maxVal) * 100);
                                            return (
                                                <motion.div
                                                    key={s.name || i}
                                                    className="leaderboard-item"
                                                    variants={listItemVariants}
                                                    whileHover={{ scale: 1.02, x: 4, backgroundColor: 'rgba(255, 255, 255, 0.03)' }}
                                                    transition={{ type: 'spring', stiffness: 300 }}
                                                >
                                                    <div className="leaderboard-header">
                                                        <span style={{ color: i === 0 ? 'var(--text-main)' : 'var(--text-muted)' }}>{s.name}</span>
                                                        <span style={{ fontWeight: 700 }}>{s.value}</span>
                                                    </div>
                                                    <div className="progress-bar-bg">
                                                        <motion.div
                                                            className="progress-bar-fill progress-shimmer-slow"
                                                            initial={{ width: 0 }}
                                                            animate={{ width: `${pct}%` }}
                                                            transition={{ duration: 1.2, ease: "circOut", delay: 0.5 + (i * 0.1) }}
                                                            style={{
                                                                background: i === 0 ? 'linear-gradient(90deg, #818cf8 0%, #c084fc 100%)' :
                                                                    i === 1 ? 'linear-gradient(90deg, #38bdf8 0%, #818cf8 100%)' :
                                                                        'rgba(255, 255, 255, 0.2)'
                                                            }}
                                                        />
                                                    </div>
                                                </motion.div>
                                            );
                                        })}
                                    </motion.div>
                                </motion.div>
                                <motion.div variants={itemVariants} className="chart-card chart-card-animated dashboard-widget">
                                    <h4 style={{ fontSize: '13px', marginBottom: '12px' }}>SLA Status</h4>
                                    <div style={{ height: '160px' }}>
                                        <ResponsiveContainer width="100%" height="100%">
                                            <PieChart animationDuration={1500}>
                                                {get3dDefs('dashSla')}
                                                <Pie
                                                    data={chartData?.sla ?? []}
                                                    cx="50%" cy="50%"
                                                    innerRadius={40} outerRadius={60}
                                                    paddingAngle={4} dataKey="value"
                                                    animationDuration={1500}
                                                >
                                                    <LabelList dataKey="value" position="inside" fill="#f8fafc" fontSize={11} fontWeight={600} />
                                                    {(chartData?.sla ?? []).map((_, i) => <Cell key={i} fill={`url(#pie3d_dashSla_${i % COLORS.length})`} />)}
                                                </Pie>
                                                <Tooltip contentStyle={PIE_TOOLTIP_STYLE} itemStyle={{ color: '#f8fafc' }} wrapperStyle={PIE_TOOLTIP_WRAPPER_STYLE} formatter={(value, name) => [value, name ?? '']} />
                                            </PieChart>
                                        </ResponsiveContainer>
                                    </div>
                                </motion.div>
                                <motion.div
                                    variants={itemVariants}
                                    className="chart-card chart-card-animated dashboard-widget"
                                    whileHover={{
                                        y: -5,
                                        boxShadow: '0 20px 40px -10px rgba(129, 140, 248, 0.4)',
                                        borderColor: 'rgba(129, 140, 248, 0.5)'
                                    }}
                                    transition={{ type: "spring", stiffness: 300, damping: 20 }}
                                >
                                    <h4 style={{ fontSize: '13px', marginBottom: '12px' }}>Tickets by Month (3D Bar)</h4>
                                    <div style={{ height: '180px' }}>
                                        <ResponsiveContainer width="100%" height="100%">
                                            <BarChart data={chartData?.workload ?? []} margin={{ top: 24, right: 8, bottom: 8, left: 8 }}>
                                                {get3dDefs('dashW')}
                                                <CartesianGrid strokeDasharray="3 3" stroke="#2d2a42" vertical={false} />
                                                <XAxis dataKey="name" stroke="#94a3b8" tick={{ fontSize: 10 }} />
                                                <YAxis stroke="#94a3b8" tick={{ fontSize: 10 }} />
                                                <Tooltip
                                                    cursor={{ fill: 'rgba(129, 140, 248, 0.1)' }}
                                                    contentStyle={PIE_TOOLTIP_STYLE}
                                                    itemStyle={{ color: '#f8fafc' }}
                                                />
                                                <Bar
                                                    dataKey="total"
                                                    name="Tickets"
                                                    fill={`url(#bar3dVertical_dashW)`}
                                                    radius={[6, 6, 0, 0]}
                                                    maxBarSize={36}
                                                    fillOpacity={0.85}
                                                    activeBar={{
                                                        fill: `url(#bar3dVertical_dashW)`,
                                                        stroke: '#c084fc',
                                                        strokeWidth: 2,
                                                        fillOpacity: 1
                                                    }}
                                                    animationDuration={2500}
                                                    animationEasing="ease-out"
                                                >
                                                    <LabelList dataKey="total" position="top" fill="#f8fafc" fontSize={11} fontWeight={600} />
                                                </Bar>
                                            </BarChart>
                                        </ResponsiveContainer>
                                    </div>
                                </motion.div>
                            </div>

                            {/* Row 2: Priority donut, Month Breakdown (separate chart when month selected), Services bar, Approval donut if present */}
                            <div className="dashboard-grid dashboard-grid-row2">
                                <motion.div variants={itemVariants} className="chart-card chart-card-animated dashboard-widget">
                                    <h4 style={{ fontSize: '13px', marginBottom: '12px' }}>Priority</h4>
                                    <div style={{ height: '200px' }}>
                                        <ResponsiveContainer width="100%" height="100%">
                                            <PieChart>
                                                {get3dDefs('dashPri')}
                                                <Pie data={chartData?.priority ?? []} cx="50%" cy="50%" innerRadius={50} outerRadius={75} paddingAngle={4} dataKey="value">
                                                    <LabelList dataKey="value" position="inside" fill="#f8fafc" fontSize={12} fontWeight={600} />
                                                    {(chartData?.priority ?? []).map((_, i) => <Cell key={i} fill={`url(#pie3d_dashPri_${i % COLORS.length})`} />)}
                                                </Pie>
                                                <Tooltip contentStyle={PIE_TOOLTIP_STYLE} itemStyle={{ color: '#f8fafc' }} wrapperStyle={PIE_TOOLTIP_WRAPPER_STYLE} formatter={(value, name) => [value, name ?? '']} />
                                            </PieChart>
                                        </ResponsiveContainer>
                                    </div>
                                </motion.div>
                                {slicerMonth && (() => {
                                    const monthRow = (chartData?.workload ?? []).find((w) => String(w.name) === String(slicerMonth));
                                    const categories = chartData?.categories ?? [];
                                    const monthBreakdownData = monthRow && categories.length ? categories.filter((c) => (monthRow[c] ?? 0) > 0).map((c) => ({ name: c.length > 20 ? c.slice(0, 18) + '…' : c, value: monthRow[c] ?? 0 })) : [];
                                    return monthBreakdownData.length > 0 ? (
                                        <motion.div variants={itemVariants} className="chart-card chart-card-animated dashboard-widget">
                                            <h4 style={{ fontSize: '13px', marginBottom: '12px' }}>Month Breakdown – {slicerMonth}</h4>
                                            <div style={{ height: '200px' }}>
                                                <ResponsiveContainer width="100%" height="100%">
                                                    <BarChart data={monthBreakdownData} layout="vertical" margin={{ left: 8, right: 8 }}>
                                                        {get3dDefs('dashMB')}
                                                        <XAxis type="number" stroke="#94a3b8" tick={{ fontSize: 10 }} />
                                                        <YAxis type="category" dataKey="name" width={90} stroke="#94a3b8" tick={{ fontSize: 10 }} />
                                                        <Tooltip contentStyle={PIE_TOOLTIP_STYLE} itemStyle={{ color: '#f8fafc' }} />
                                                        <Bar dataKey="value" radius={[0, 6, 6, 0]} maxBarSize={28} animationDuration={1500}>
                                                            {(monthBreakdownData || []).map((_, i) => <Cell key={i} fill={`url(#bar3dH_dashMB_${i % BAR_3D_COLORS.length})`} />)}
                                                            <LabelList dataKey="value" position="right" fill="#f8fafc" fontSize={10} fontWeight={600} />
                                                        </Bar>
                                                    </BarChart>
                                                </ResponsiveContainer>
                                            </div>
                                        </motion.div>
                                    ) : null;
                                })()}
                                <motion.div variants={itemVariants} className="chart-card chart-card-animated dashboard-widget" style={{ gridColumn: slicerMonth ? 'span 1' : 'span 2' }}>
                                    <h4 style={{ fontSize: '13px', marginBottom: '12px' }}>Top Services by Volume</h4>
                                    <div style={{ height: '200px' }}>
                                        <ResponsiveContainer width="100%" height="100%">
                                            <BarChart data={(chartData?.services ?? []).slice(0, 8)} layout="vertical" margin={{ left: 8, right: 8 }} animationDuration={1500}>
                                                {get3dDefs('dashSvc')}
                                                <XAxis type="number" stroke="#94a3b8" tick={{ fontSize: 10 }} />
                                                <YAxis type="category" dataKey="name" width={100} stroke="#94a3b8" tick={{ fontSize: 10 }} />
                                                <Tooltip contentStyle={PIE_TOOLTIP_STYLE} itemStyle={{ color: '#f8fafc' }} />
                                                <Bar dataKey="value" radius={[0, 6, 6, 0]} maxBarSize={28} animationDuration={1500}>
                                                    {((chartData?.services ?? []).slice(0, 8)).map((_, i) => <Cell key={i} fill={`url(#bar3dH_dashSvc_${i % BAR_3D_COLORS.length})`} />)}
                                                    <LabelList dataKey="value" position="right" fill="#f8fafc" fontSize={10} fontWeight={600} />
                                                </Bar>
                                            </BarChart>
                                        </ResponsiveContainer>
                                    </div>
                                </motion.div>
                                {chartData?.approval_status_report?.length > 0 && (
                                    <motion.div variants={itemVariants} className="chart-card chart-card-animated dashboard-widget">
                                        <h4 style={{ fontSize: '13px', marginBottom: '12px' }}>Approval Status</h4>
                                        <div style={{ height: '200px' }}>
                                            <ResponsiveContainer width="100%" height="100%">
                                                <PieChart animationDuration={1500}>
                                                    {get3dDefs('dashApp')}
                                                    <Pie data={chartData.approval_status_report} cx="50%" cy="50%" innerRadius={50} outerRadius={75} paddingAngle={4} dataKey="value" animationDuration={1500}>
                                                        <LabelList dataKey="value" position="inside" fill="#f8fafc" fontSize={12} fontWeight={600} />
                                                        {chartData.approval_status_report.map((_, i) => <Cell key={i} fill={`url(#pie3d_dashApp_${i % COLORS.length})`} />)}
                                                    </Pie>
                                                    <Tooltip contentStyle={PIE_TOOLTIP_STYLE} itemStyle={{ color: '#f8fafc' }} wrapperStyle={PIE_TOOLTIP_WRAPPER_STYLE} formatter={(value, name) => [value, name ?? '']} />
                                                </PieChart>
                                            </ResponsiveContainer>
                                        </div>
                                    </motion.div>
                                )}
                            </div>

                            {/* Row 3: Detailed Service Workload table + Raw Data table */}
                            <div className="dashboard-grid dashboard-grid-row3">
                                {chartData?.workload_table?.months?.length > 0 && (
                                    <motion.div variants={itemVariants} className="chart-card chart-card-animated dashboard-widget" style={{ gridColumn: 'span 2', overflowX: 'auto' }}>
                                        <h4 style={{ fontSize: '13px', marginBottom: '12px' }}>Detailed Service Workload</h4>
                                        <table className="excel-table">
                                            <thead>
                                                <tr>
                                                    <th style={{ textAlign: 'left', padding: '8px' }}>Service</th>
                                                    {chartData.workload_table.months.slice(0, 12).map((m) => <th key={m} style={{ padding: '8px' }}>{m}</th>)}
                                                    <th style={{ padding: '8px' }}>Total</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {(chartData.workload_table.rows ?? []).slice(0, 10).map((row, i) => (
                                                    <motion.tr key={i} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.25, delay: i * 0.04 }}>
                                                        <td style={{ padding: '8px', fontWeight: 500 }}>{row.name}</td>
                                                        {chartData.workload_table.months.slice(0, 12).map((m) => (
                                                            <td
                                                                key={m}
                                                                role="button"
                                                                tabIndex={0}
                                                                onClick={() => setWorkloadTicketsModal?.({ category: row.name, month: m })}
                                                                onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setWorkloadTicketsModal?.({ category: row.name, month: m }); } }}
                                                                style={{ padding: '8px', textAlign: 'right', cursor: setWorkloadTicketsModal ? 'pointer' : 'default', color: 'var(--accent)', textDecoration: 'underline', textUnderlineOffset: 2 }}
                                                                title="Click to view tickets"
                                                            >
                                                                {row[m] ?? 0}
                                                            </td>
                                                        ))}
                                                        <td
                                                            role="button"
                                                            tabIndex={0}
                                                            onClick={() => setWorkloadTicketsModal?.({ category: row.name, month: null })}
                                                            onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setWorkloadTicketsModal?.({ category: row.name, month: null }); } }}
                                                            style={{ padding: '8px', textAlign: 'right', fontWeight: 'bold', cursor: setWorkloadTicketsModal ? 'pointer' : 'default', color: 'var(--accent)', textDecoration: 'underline', textUnderlineOffset: 2 }}
                                                            title="Click to view all tickets for this service"
                                                        >
                                                            {row.total ?? 0}
                                                        </td>
                                                    </motion.tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </motion.div>
                                )}
                                <motion.div variants={itemVariants} className="chart-card chart-card-animated dashboard-widget raw-data-widget" style={{ gridColumn: 'span 2', overflow: 'auto' }}>
                                    <h4 style={{ fontSize: '13px', marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                                        <Database size={16} /> Raw Data (Excel sheet)
                                    </h4>
                                    {rawDataLoading ? (
                                        <p style={{ color: 'var(--text-muted)' }}>Loading...</p>
                                    ) : (
                                        <>
                                            <div style={{ overflowX: 'auto', maxHeight: '320px' }}>
                                                <table className="excel-table">
                                                    <thead>
                                                        <tr>
                                                            {rawData.columns.slice(0, 10).map((c) => <th key={c} style={{ padding: '8px' }}>{c}</th>)}
                                                            {rawData.columns.length > 10 && <th style={{ padding: '8px' }}>…</th>}
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {rawData.rows.map((row, i) => (
                                                            <motion.tr key={i} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.2, delay: Math.min(i * 0.03, 0.5) }}>
                                                                {rawData.columns.slice(0, 10).map((c) => <td key={c} style={{ padding: '8px', fontSize: '11px' }}>{(row[c] ?? '').toString().slice(0, 30)}</td>)}
                                                                {rawData.columns.length > 10 && <td style={{ padding: '8px' }}>…</td>}
                                                            </motion.tr>
                                                        ))}
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '12px', flexWrap: 'wrap', gap: '8px' }}>
                                                <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Total rows: {rawData.total}</span>
                                                <div style={{ display: 'flex', gap: '8px' }}>
                                                    <button type="button" className="header-btn header-btn-ghost" style={{ padding: '4px 10px', fontSize: '12px' }} disabled={rawData.offset === 0} onClick={() => setRawData((p) => ({ ...p, offset: Math.max(0, p.offset - p.limit) }))}>Prev</button>
                                                    <button type="button" className="header-btn header-btn-ghost" style={{ padding: '4px 10px', fontSize: '12px' }} disabled={rawData.offset + rawData.rows.length >= rawData.total} onClick={() => setRawData((p) => ({ ...p, offset: p.offset + p.limit }))}>Next</button>
                                                </div>
                                            </div>
                                        </>
                                    )}
                                </motion.div>
                            </div>
                        </motion.div>
                    )}

                    {/* Overview Tab */}
                    {activeTab === 'overview' && (
                        <>
                            <div className="kpi-grid">
                                <div className="kpi-card kpi-card-vibrant blue kpi-card-animated">
                                    <div className="kpi-header">
                                        <div className="kpi-icon kpi-icon-pulse"><Ticket size={24} /></div>
                                        <span className="kpi-label">Total Tickets</span>
                                    </div>
                                    <div>
                                        <span className="kpi-value">{chartData?.total_tickets ?? '—'}</span>
                                        <div className="kpi-trend" style={{ color: 'var(--success)' }}>
                                            {data.comparison?.total_tickets_delta != null ? (
                                                <><span>{data.comparison.total_tickets_delta >= 0 ? '+' : ''}{data.comparison.total_tickets_delta}</span> vs prev</>
                                            ) : 'Stable Volume'}
                                        </div>
                                    </div>
                                </div>
                                <div className="kpi-card kpi-card-vibrant green kpi-card-animated">
                                    <div className="kpi-header">
                                        <div className="kpi-icon kpi-icon-pulse"><CheckCircle size={24} /></div>
                                        <span className="kpi-label">SLA Met</span>
                                    </div>
                                    <div>
                                        <span className="kpi-value">{chartData?.sla_met_pct != null ? `${chartData.sla_met_pct}%` : 'N/A'}</span>
                                        <div className="kpi-trend" style={{ color: (data.comparison?.sla_met_pct_delta ?? 0) >= 0 ? 'var(--success)' : 'var(--danger)' }}>
                                            {data.comparison?.sla_met_pct_delta != null ? (
                                                <><span>{data.comparison.sla_met_pct_delta >= 0 ? '+' : ''}{data.comparison.sla_met_pct_delta}%</span> delta</>
                                            ) : 'On Target'}
                                        </div>
                                    </div>
                                </div>
                                <div className="kpi-card kpi-card-vibrant red kpi-card-animated">
                                    <div className="kpi-header">
                                        <div className="kpi-icon kpi-icon-pulse"><AlertTriangle size={24} /></div>
                                        <span className="kpi-label">High Priority</span>
                                    </div>
                                    <div>
                                        <span className="kpi-value">{(chartData?.priority ?? []).find(p => p.name === '1' || p.name === 'Critical')?.value ?? 0}</span>
                                        <div className="kpi-trend">Action Required</div>
                                    </div>
                                </div>
                                <div className="kpi-card kpi-card-vibrant purple kpi-card-animated">
                                    <div className="kpi-header">
                                        <div className="kpi-icon kpi-icon-pulse"><Clock size={24} /></div>
                                        <span className="kpi-label">Avg Resolution</span>
                                    </div>
                                    <div>
                                        <span className="kpi-value">{chartData?.avg_resolve_hours != null ? `${chartData.avg_resolve_hours}h` : 'N/A'}</span>
                                        <div className="kpi-trend">Efficiency Match</div>
                                    </div>
                                </div>
                            </div>

                            <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: '24px', marginBottom: '24px' }}>
                                {/* Executive Decision Support Card */}
                                <div className="ai-insight-card ai-insight-card-animated" style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                            <div style={{ background: 'var(--accent-soft)', padding: '10px', borderRadius: '12px' }}>
                                                <BrainCircuit size={24} color="var(--accent)" />
                                            </div>
                                            <div>
                                                <h3 style={{ margin: 0, fontSize: '18px', fontWeight: 600 }}>Executive Decision Support</h3>
                                                <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>AI-Assisted Operational Intelligence</span>
                                            </div>
                                        </div>
                                        <div style={{ textAlign: 'right' }}>
                                            <div style={{ fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '1px' }}>System Status</div>
                                            <div style={{ fontSize: '13px', color: 'var(--success)', fontWeight: 600 }}>{data.ai_insights ? 'Insights Ready' : 'Processing...'}</div>
                                        </div>
                                    </div>

                                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                                        <div style={{ padding: '16px', background: 'rgba(255,255,255,0.02)', borderRadius: '12px', border: '1px solid var(--border)' }}>
                                            <div style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: '12px', fontWeight: 600 }}>Bottleneck Analysis</div>
                                            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                                    <span style={{ fontSize: '13px' }}>Breach Rate</span>
                                                    <span style={{ fontSize: '13px', fontWeight: 600, color: (chartData?.sla_met_pct || 100) < 90 ? 'var(--danger)' : 'var(--success)' }}>
                                                        {chartData?.sla_met_pct ? `${(100 - chartData.sla_met_pct).toFixed(1)}%` : '0%'}
                                                    </span>
                                                </div>
                                                <div style={{ height: '4px', background: 'var(--border)', borderRadius: '2px', overflow: 'hidden' }}>
                                                    <div style={{ height: '100%', background: 'var(--danger)', width: `${100 - (chartData?.sla_met_pct || 100)}%` }}></div>
                                                </div>
                                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '4px' }}>
                                                    <span style={{ fontSize: '13px' }}>P1/P2 Load</span>
                                                    <span style={{ fontSize: '13px', fontWeight: 600 }}>
                                                        {Math.round(((chartData?.priority?.find(p => p.name === 'High' || p.name === '1')?.value || 0) / (chartData?.total_tickets || 1)) * 100)}%
                                                    </span>
                                                </div>
                                            </div>
                                        </div>

                                        <div style={{ padding: '16px', background: 'var(--accent-soft)', borderRadius: '12px', border: '1px solid rgba(129, 140, 248, 0.2)' }}>
                                            <div style={{ fontSize: '11px', color: 'var(--accent)', textTransform: 'uppercase', marginBottom: '12px', fontWeight: 600 }}>Top Service Risk</div>
                                            <div style={{ fontSize: '15px', fontWeight: 700, color: 'var(--text-main)', marginBottom: '4px' }}>
                                                {chartData?.services?.length > 0 ? chartData.services[0].name : 'Calculating...'}
                                            </div>
                                            <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
                                                High volume alert: {chartData?.services?.length > 0 ? chartData.services[0].value : 0} active tickets
                                            </div>
                                        </div>
                                    </div>

                                    <div className="insight-text-area" style={{ flex: 1 }}>
                                        <p style={{ lineHeight: '1.7', fontSize: '14px', color: 'var(--text-main)', margin: 0 }}>
                                            {data.ai_insights?.summary || (aiLoading ? 'Synthesizing metadata and trends...' : 'Initial data scan complete. Re-upload for deep AI analysis.')}
                                        </p>
                                    </div>

                                    <div style={{ background: 'var(--accent-soft)', padding: '12px 16px', borderRadius: '12px', borderLeft: '4px solid var(--accent)' }}>
                                        <div style={{ fontSize: '11px', fontWeight: 700, color: 'var(--accent)', textTransform: 'uppercase', marginBottom: '4px' }}>Strategic Recommendation</div>
                                        <p style={{ margin: 0, fontSize: '13px', color: 'var(--text-main)', fontStyle: 'italic' }}>
                                            "{data.ai_insights?.recommendation || 'Focus on resolving aged P1 tickets to stabilize the SLA breach trajectory.'}"
                                        </p>
                                    </div>
                                </div>

                                <div className="chart-card chart-card-animated">
                                    <h3 style={{ fontSize: '15px', marginBottom: '20px' }}>Service Pulse (Top Units)</h3>
                                    <div className="pulse-grid">
                                        {(chartData.services ?? []).slice(0, 6).map(s => {
                                            const status = s.value > (chartData.total_tickets / 4) ? 'danger' : s.value > (chartData.total_tickets / 8) ? 'warning' : 'success';
                                            return (
                                                <div key={s.name} className="pulse-card">
                                                    <div className="status-dot status-dot-pulse" style={{ color: `var(--${status})`, background: `var(--${status})` }} />
                                                    <div>
                                                        <div style={{ fontSize: '11px', color: 'var(--text-muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '100px' }}>{s.name}</div>
                                                        <div style={{ fontSize: '14px', fontWeight: 600 }}>{s.value} <span style={{ fontSize: '10px', color: 'var(--text-muted)', fontWeight: 400 }}>tks</span></div>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>
                            </div>

                            <div className="chart-card chart-card-animated">
                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                                    <h3 style={{ fontSize: '16px', margin: 0 }}>High-Level Workload Trend</h3>
                                    <button className="header-btn header-btn-ghost" onClick={() => setActiveTab('workload')}>View Details</button>
                                </div>
                                <div style={{ height: '300px', cursor: 'pointer' }}>
                                    <ResponsiveContainer width="100%" height="100%">
                                        <BarChart data={chartData.workload} margin={{ top: 24, right: 12, bottom: 8, left: 8 }} onClick={(e) => { const name = e?.activeLabel; if (name) { const row = chartData.workload.find((w) => w.name === name); if (row) setMonthDetailModal({ monthName: name, monthData: row, categories: chartData.categories }); } }}>
                                            {get3dDefs('overviewW')}
                                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                                            <XAxis dataKey="name" stroke="#64748b" tick={{ fontSize: 11 }} />
                                            <YAxis stroke="#64748b" tick={{ fontSize: 11 }} />
                                            <Tooltip contentStyle={PIE_TOOLTIP_STYLE} itemStyle={{ color: '#f8fafc' }} />
                                            <Bar
                                                dataKey="total"
                                                name="Total Tickets"
                                                fill={`url(#bar3dVertical_overviewW)`}
                                                radius={[6, 6, 0, 0]}
                                                maxBarSize={40}
                                            >
                                                <LabelList dataKey="total" position="top" fill="#f8fafc" fontSize={11} fontWeight={600} />
                                            </Bar>
                                        </BarChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>
                        </>
                    )}

                    {/* Workload Tab */}
                    {activeTab === 'workload' && (
                        <>
                            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '24px', marginBottom: '24px' }}>
                                <div className="chart-card chart-card-animated">
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px', marginBottom: '16px' }}>
                                        <h3 style={{ fontSize: '18px', margin: 0 }}>Monthly Workload Trend (Stacked)</h3>
                                        <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Click a bar to see month details</span>
                                    </div>
                                    <div style={{ height: '420px', cursor: 'pointer' }}>
                                        <ResponsiveContainer width="100%" height="100%">
                                            <BarChart data={chartData.workload} margin={{ top: 12, right: 12, bottom: 8, left: 8 }} onClick={(e) => { const name = e?.activeLabel; if (name) { const row = chartData.workload.find((w) => w.name === name); if (row) setMonthDetailModal({ monthName: name, monthData: row, categories: chartData.categories }); } }}>
                                                {get3dDefs('workloadStack')}
                                                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                                                <XAxis dataKey="name" stroke="#94a3b8" tick={{ fontSize: 12 }} />
                                                <YAxis stroke="#94a3b8" tick={{ fontSize: 12 }} />
                                                <Tooltip contentStyle={PIE_TOOLTIP_STYLE} itemStyle={{ color: '#f8fafc' }} />
                                                <Legend />
                                                {chartData.categories.map((cat, idx) => (
                                                    <Bar key={cat} dataKey={cat} name={cat} stackId="a" fill={`url(#bar3dV_workloadStack_${idx % BAR_3D_COLORS.length})`} radius={idx === chartData.categories.length - 1 ? [6, 6, 0, 0] : [0, 0, 0, 0]} />
                                                ))}
                                            </BarChart>
                                        </ResponsiveContainer>
                                    </div>
                                </div>

                                <div className="chart-card chart-card-animated">
                                    <h3 style={{ marginBottom: '24px', fontSize: '18px' }}>Priority Breakdown</h3>
                                    <div style={{ height: '350px' }}>
                                        <ResponsiveContainer width="100%" height="100%">
                                            <BarChart data={chartData.priority ?? []} margin={{ top: 24, right: 8, bottom: 8, left: 8 }}>
                                                {get3dDefs('workloadPri')}
                                                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                                                <XAxis dataKey="name" stroke="#94a3b8" />
                                                <YAxis stroke="#94a3b8" />
                                                <Tooltip contentStyle={PIE_TOOLTIP_STYLE} itemStyle={{ color: '#f8fafc' }} />
                                                <Bar dataKey="value" radius={[6, 6, 0, 0]} maxBarSize={36}>
                                                    {(chartData.priority ?? []).map((_, i) => <Cell key={i} fill={`url(#bar3dV_workloadPri_${i % BAR_3D_COLORS.length})`} />)}
                                                    <LabelList dataKey="value" position="top" fill="#f8fafc" fontSize={11} fontWeight={600} />
                                                </Bar>
                                            </BarChart>
                                        </ResponsiveContainer>
                                    </div>
                                </div>
                            </div>

                            {chartData.workload_table?.months?.length > 0 && (
                                <div className="chart-card chart-card-animated" style={{ marginBottom: '24px' }}>
                                    <h3 style={{ marginBottom: '16px', fontSize: '18px' }}>Detailed Service Workload</h3>
                                    <div style={{ overflowX: 'auto' }}>
                                        <table className="excel-table">
                                            <thead>
                                                <tr>
                                                    <th style={{ textAlign: 'left', padding: '10px 12px' }}>Service Name</th>
                                                    {chartData.workload_table.months.map(m => <th key={m} style={{ padding: '10px 12px' }}>{m}</th>)}
                                                    <th style={{ padding: '10px 12px' }}>Grand Total</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {chartData.workload_table.rows.slice(0, 15).map((row, i) => (
                                                    <tr key={i}>
                                                        <td style={{ padding: '10px 12px', fontWeight: 500 }}>{row.name}</td>
                                                        {chartData.workload_table.months.map((m) => (
                                                            <td
                                                                key={m}
                                                                role="button"
                                                                tabIndex={0}
                                                                onClick={() => setWorkloadTicketsModal?.({ category: row.name, month: m })}
                                                                onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setWorkloadTicketsModal?.({ category: row.name, month: m }); } }}
                                                                style={{ padding: '10px 12px', textAlign: 'right', cursor: setWorkloadTicketsModal ? 'pointer' : 'default', color: 'var(--accent)', textDecoration: 'underline', textUnderlineOffset: 2 }}
                                                                title="Click to view tickets"
                                                            >
                                                                {row[m] ?? 0}
                                                            </td>
                                                        ))}
                                                        <td
                                                            role="button"
                                                            tabIndex={0}
                                                            onClick={() => setWorkloadTicketsModal?.({ category: row.name, month: null })}
                                                            onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setWorkloadTicketsModal?.({ category: row.name, month: null }); } }}
                                                            style={{ padding: '10px 12px', textAlign: 'right', fontWeight: 'bold', cursor: setWorkloadTicketsModal ? 'pointer' : 'default', color: 'var(--accent)', textDecoration: 'underline', textUnderlineOffset: 2 }}
                                                            title="Click to view all tickets for this service"
                                                        >
                                                            {row.total ?? 0}
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            )}
                        </>
                    )}

                    {/* SLA Tab */}
                    {activeTab === 'sla' && (
                        <>
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px', marginBottom: '24px' }}>
                                <div className="chart-card chart-card-animated">
                                    <h3 style={{ marginBottom: '30px', fontSize: '18px' }}>SLA Distribution</h3>
                                    <div style={{ height: '350px' }}>
                                        <ResponsiveContainer width="100%" height="100%">
                                            <PieChart>
                                                {get3dDefs('slaDist')}
                                                <Pie data={chartData.sla} cx="50%" cy="50%" innerRadius={70} outerRadius={100} paddingAngle={8} dataKey="value">
                                                    <LabelList dataKey="value" position="inside" fill="#f8fafc" fontSize={14} fontWeight={600} />
                                                    {(chartData.sla ?? []).map((_, i) => <Cell key={i} fill={`url(#pie3d_slaDist_${i % COLORS.length})`} />)}
                                                </Pie>
                                                <Tooltip contentStyle={PIE_TOOLTIP_STYLE} itemStyle={{ color: '#f8fafc' }} wrapperStyle={PIE_TOOLTIP_WRAPPER_STYLE} formatter={(value, name) => [value, name ?? '']} />
                                                <Legend />
                                            </PieChart>
                                        </ResponsiveContainer>
                                    </div>
                                </div>

                                {/* Duplicated AI Card for SLA Context (simplified) */}
                                <div className="ai-insight-card ai-insight-card-animated" style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                            <div style={{ background: 'var(--accent-soft)', padding: '10px', borderRadius: '12px' }}>
                                                <BrainCircuit size={24} color="var(--accent)" />
                                            </div>
                                            <div>
                                                <h3 style={{ margin: 0, fontSize: '18px', fontWeight: 600 }}>SLA Risk Radar</h3>
                                                <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Compliance & Mitigation Analysis</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                                        <div style={{ padding: '16px', background: 'rgba(255,255,255,0.02)', borderRadius: '12px', border: '1px solid var(--border)' }}>
                                            <div style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: '12px', fontWeight: 600 }}>Compliance Gap</div>
                                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                                                <span style={{ fontSize: '13px' }}>Current Met %</span>
                                                <span style={{ fontSize: '14px', fontWeight: 700, color: (chartData?.sla_met_pct || 100) < 90 ? 'var(--danger)' : 'var(--success)' }}>
                                                    {chartData?.sla_met_pct ?? '0'}%
                                                </span>
                                            </div>
                                            <div style={{ height: '4px', background: 'var(--border)', borderRadius: '2px', overflow: 'hidden' }}>
                                                <div style={{ height: '100%', background: 'var(--success)', width: `${chartData?.sla_met_pct || 0}%` }}></div>
                                            </div>
                                        </div>

                                        <div style={{ padding: '16px', background: 'rgba(239, 68, 68, 0.05)', borderRadius: '12px', border: '1px solid rgba(239, 68, 68, 0.1)' }}>
                                            <div style={{ fontSize: '11px', color: 'var(--danger)', textTransform: 'uppercase', marginBottom: '12px', fontWeight: 600 }}>Critical Breaches</div>
                                            <div style={{ fontSize: '20px', fontWeight: 700, color: 'white' }}>
                                                {chartData?.breach_list?.length || 0}
                                            </div>
                                            <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Tickets requiring immediate action</div>
                                        </div>
                                    </div>

                                    <div style={{ background: 'rgba(245, 158, 11, 0.1)', padding: '12px 16px', borderRadius: '12px', borderLeft: '4px solid var(--warning)', marginTop: 'auto' }}>
                                        <div style={{ fontSize: '11px', fontWeight: 700, color: 'var(--warning)', textTransform: 'uppercase', marginBottom: '4px' }}>Risk Mitigation Strategy</div>
                                        <p style={{ margin: 0, fontSize: '13px', color: 'var(--text-main)', fontStyle: 'italic' }}>
                                            "{data.ai_insights?.recommendation || 'Initiate review of top breaching categories and optimize resource allocation for high-priority queues.'}"
                                        </p>
                                    </div>
                                </div>
                            </div>

                            {chartData.sla_by_category?.length > 0 && (
                                <div className="chart-card chart-card-animated" style={{ marginBottom: '24px' }}>
                                    <h3 style={{ marginBottom: '16px', fontSize: '18px' }}>SLA Performance by Category</h3>
                                    <div style={{ overflowX: 'auto' }}>
                                        <table className="excel-table">
                                            <thead>
                                                <tr>
                                                    <th style={{ textAlign: 'left', padding: '10px 12px' }}>Category</th>
                                                    <th style={{ padding: '10px 12px' }}>Breached</th>
                                                    <th style={{ padding: '10px 12px' }}>Met</th>
                                                    <th style={{ padding: '10px 12px' }}>Total</th>
                                                    <th style={{ padding: '10px 12px' }}>SLA %</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {chartData.sla_by_category.slice(0, 10).map((row, i) => (
                                                    <tr key={i}>
                                                        <td style={{ padding: '10px 12px', fontWeight: 500 }}>{row.category}</td>
                                                        <td style={{ padding: '10px 12px', textAlign: 'right', color: 'var(--danger)' }}>{row.breached}</td>
                                                        <td style={{ padding: '10px 12px', textAlign: 'right', color: 'var(--success)' }}>{row.met}</td>
                                                        <td style={{ padding: '10px 12px', textAlign: 'right' }}>{row.total}</td>
                                                        <td style={{ padding: '10px 12px', textAlign: 'right', fontWeight: 'bold' }}>{row.sla_pct}%</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            )}

                            {chartData.breach_list?.length > 0 && (
                                <div className="chart-card chart-card-animated">
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                                        <h3 style={{ fontSize: '18px', margin: 0 }}>SLA Breach Watchlist</h3>
                                        <button className="header-btn" onClick={exportBreachListCSV}><Download size={14} /> Export</button>
                                    </div>
                                    <div style={{ overflowX: 'auto', maxHeight: '300px' }}>
                                        <table className="excel-table">
                                            <thead>
                                                <tr>
                                                    <th style={{ textAlign: 'left', padding: '10px 12px' }}>ID</th>
                                                    <th style={{ textAlign: 'left', padding: '10px 12px' }}>Category</th>
                                                    <th style={{ textAlign: 'left', padding: '10px 12px' }}>Summary</th>
                                                    <th style={{ padding: '10px 12px' }}>Days</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {chartData.breach_list.slice(0, 20).map((row, i) => (
                                                    <tr key={i}>
                                                        <td style={{ padding: '10px 12px', color: 'var(--accent)' }}>{row.ticket_id}</td>
                                                        <td style={{ padding: '10px 12px' }}>{row.category}</td>
                                                        <td style={{ padding: '10px 12px', maxWidth: '300px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{row.summary}</td>
                                                        <td style={{ padding: '10px 12px', textAlign: 'right', color: 'var(--danger)' }}>{row.resolution_days}</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            )}
                            {/* Debug / Raw Data Inspector */}
                            <div className="chart-card chart-card-animated" style={{ marginTop: '24px' }}>
                                <h3 style={{ fontSize: '16px', marginBottom: '16px' }}>Data Inspector (Raw Sample)</h3>
                                <div style={{ overflowX: 'auto' }}>
                                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '12px' }}>
                                        <thead>
                                            <tr style={{ borderBottom: '1px solid var(--border)', textAlign: 'left' }}>
                                                <th style={{ padding: '8px' }}>ID</th>
                                                <th style={{ padding: '8px' }}>Category</th>
                                                <th style={{ padding: '8px' }}>Priority</th>
                                                <th style={{ padding: '8px' }}>Status</th>
                                                <th style={{ padding: '8px' }}>Summary</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {(chartData.raw_sample ?? []).map((row, i) => (
                                                <tr key={i} style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                                                    <td style={{ padding: '8px', color: 'var(--accent)' }}>{row.ticket_id}</td>
                                                    <td style={{ padding: '8px' }}>{row.category}</td>
                                                    <td style={{ padding: '8px' }}>{row.priority}</td>
                                                    <td style={{ padding: '8px' }}>{row.status}</td>
                                                    <td style={{ padding: '8px', maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{row.summary}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </>
                    )}
                </>
            )
            }
        </motion.div >
    );
}
