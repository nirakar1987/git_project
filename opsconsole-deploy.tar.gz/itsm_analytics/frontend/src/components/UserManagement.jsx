import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Users, Plus, Edit2, Trash2, Shield } from 'lucide-react';

export default function UserManagement({ currentUser }) {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [addUsername, setAddUsername] = useState('');
    const [addPassword, setAddPassword] = useState('');
    const [addAdmin, setAddAdmin] = useState(false);
    const [adding, setAdding] = useState(false);
    const [editing, setEditing] = useState(null);
    const [editPassword, setEditPassword] = useState('');
    const [editAdmin, setEditAdmin] = useState(false);

    const fetchUsers = async () => {
        setError('');
        setLoading(true);
        try {
            const res = await axios.get('/users');
            setUsers(res.data?.users ?? []);
        } catch (err) {
            setError(err.response?.data?.detail ?? 'Failed to load users');
            setUsers([]);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchUsers();
    }, []);

    const handleAddUser = async (e) => {
        e.preventDefault();
        if (!addUsername.trim()) return;
        setError('');
        setAdding(true);
        try {
            const form = new URLSearchParams();
            form.append('username', addUsername.trim());
            form.append('password', addPassword);
            form.append('is_admin', addAdmin);
            await axios.post('/users', form, {
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            });
            setAddUsername('');
            setAddPassword('');
            setAddAdmin(false);
            fetchUsers();
        } catch (err) {
            setError(err.response?.data?.detail ?? 'Failed to create user');
        } finally {
            setAdding(false);
        }
    };

    const handleUpdateUser = async (username) => {
        setError('');
        try {
            await axios.patch(`/users/${encodeURIComponent(username)}`, {
                ...(editPassword ? { password: editPassword } : {}),
                ...(currentUser?.is_admin ? { is_admin: editAdmin } : {}),
            });
            setEditing(null);
            setEditPassword('');
            fetchUsers();
        } catch (err) {
            setError(err.response?.data?.detail ?? 'Failed to update user');
        }
    };

    const handleDeleteUser = async (username) => {
        if (!window.confirm(`Delete user "${username}"?`)) return;
        setError('');
        try {
            await axios.delete(`/users/${encodeURIComponent(username)}`);
            fetchUsers();
        } catch (err) {
            setError(err.response?.data?.detail ?? 'Failed to delete user');
        }
    };

    const startEdit = (u) => {
        setEditing({ username: u.username, is_admin: u.is_admin });
        setEditPassword('');
        setEditAdmin(u.is_admin);
    };

    return (
        <div className="user-management" style={{ padding: '24px', maxWidth: '720px' }}>
            <h1 style={{ fontSize: '22px', marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Users size={24} /> User management
            </h1>
            <p style={{ color: 'var(--text-muted)', fontSize: '14px', marginBottom: '24px' }}>
                Create and manage users. Only admins can access this page.
            </p>

            {error && (
                <div style={{ background: 'rgba(248,113,113,0.15)', border: '1px solid var(--danger)', color: 'var(--danger)', padding: '12px', borderRadius: '10px', marginBottom: '16px' }}>
                    {error}
                </div>
            )}

            {/* Add user */}
            <form onSubmit={handleAddUser} style={{ marginBottom: '32px', display: 'flex', flexWrap: 'wrap', gap: '12px', alignItems: 'flex-end' }}>
                <label style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                    <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Username</span>
                    <input
                        type="text"
                        value={addUsername}
                        onChange={(e) => setAddUsername(e.target.value)}
                        placeholder="newuser"
                        style={{ padding: '8px 12px', borderRadius: '8px', border: '1px solid var(--border)', background: 'var(--card)', color: 'var(--text-main)', minWidth: '140px' }}
                    />
                </label>
                <label style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                    <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Password</span>
                    <input
                        type="password"
                        value={addPassword}
                        onChange={(e) => setAddPassword(e.target.value)}
                        placeholder="••••••••"
                        minLength={4}
                        style={{ padding: '8px 12px', borderRadius: '8px', border: '1px solid var(--border)', background: 'var(--card)', color: 'var(--text-main)', minWidth: '140px' }}
                    />
                </label>
                <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
                    <input type="checkbox" checked={addAdmin} onChange={(e) => setAddAdmin(e.target.checked)} />
                    <span style={{ fontSize: '13px' }}>Admin</span>
                </label>
                <button type="submit" disabled={adding || !addUsername.trim() || addPassword.length < 4} className="header-btn" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <Plus size={18} /> Add user
                </button>
            </form>

            {/* User list */}
            <h2 style={{ fontSize: '16px', marginBottom: '12px', color: 'var(--text-muted)' }}>Users</h2>
            {loading ? (
                <p style={{ color: 'var(--text-muted)' }}>Loading...</p>
            ) : (
                <div style={{ border: '1px solid var(--border)', borderRadius: '12px', overflow: 'hidden' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                        <thead>
                            <tr style={{ background: 'var(--card-hover)', borderBottom: '1px solid var(--border)' }}>
                                <th style={{ padding: '12px', textAlign: 'left', fontSize: '12px', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Username</th>
                                <th style={{ padding: '12px', textAlign: 'left', fontSize: '12px', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Role</th>
                                <th style={{ padding: '12px', textAlign: 'right', fontSize: '12px', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {users.map((u) => (
                                <tr key={u.username} style={{ borderBottom: '1px solid var(--border)' }}>
                                    <td style={{ padding: '12px' }}>
                                        {u.username}
                                        {u.username === currentUser?.username && (
                                            <span style={{ marginLeft: '8px', fontSize: '11px', color: 'var(--accent)' }}>(you)</span>
                                        )}
                                    </td>
                                    <td style={{ padding: '12px' }}>
                                        {u.is_admin ? (
                                            <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', color: 'var(--accent)' }}><Shield size={14} /> Admin</span>
                                        ) : (
                                            <span style={{ color: 'var(--text-muted)' }}>User</span>
                                        )}
                                    </td>
                                    <td style={{ padding: '12px', textAlign: 'right' }}>
                                        {editing?.username === u.username ? (
                                            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', justifyContent: 'flex-end', alignItems: 'center' }}>
                                                <input
                                                    type="password"
                                                    placeholder="New password (optional)"
                                                    value={editPassword}
                                                    onChange={(e) => setEditPassword(e.target.value)}
                                                    style={{ padding: '6px 10px', borderRadius: '6px', border: '1px solid var(--border)', background: 'var(--card)', color: 'var(--text-main)', width: '160px', fontSize: '12px' }}
                                                />
                                                {currentUser?.is_admin && (
                                                    <label style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '12px', cursor: 'pointer' }}>
                                                        <input type="checkbox" checked={editAdmin} onChange={(e) => setEditAdmin(e.target.checked)} />
                                                        Admin
                                                    </label>
                                                )}
                                                <button type="button" className="header-btn" style={{ padding: '6px 10px', fontSize: '12px' }} onClick={() => handleUpdateUser(u.username)}>Save</button>
                                                <button type="button" className="header-btn header-btn-ghost" style={{ padding: '6px 10px', fontSize: '12px' }} onClick={() => { setEditing(null); setEditPassword(''); }}>Cancel</button>
                                            </div>
                                        ) : (
                                            <>
                                                <button type="button" className="header-btn header-btn-ghost" style={{ padding: '6px 10px', marginRight: '6px', fontSize: '12px' }} onClick={() => startEdit(u)} title="Edit">
                                                    <Edit2 size={14} />
                                                </button>
                                                {u.username !== currentUser?.username && (
                                                    <button type="button" style={{ padding: '6px 10px', background: 'transparent', border: 'none', color: 'var(--danger)', cursor: 'pointer', borderRadius: '6px' }} onClick={() => handleDeleteUser(u.username)} title="Delete">
                                                        <Trash2 size={14} />
                                                    </button>
                                                )}
                                            </>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
}
