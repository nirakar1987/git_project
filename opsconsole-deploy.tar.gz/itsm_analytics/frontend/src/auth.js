/**
 * Simple auth helper: token and user in localStorage.
 * Use getToken() for axios; call setAuth(token, user) after login and clearAuth() on logout/401.
 */

const TOKEN_KEY = 'itsm_auth_token';
const USER_KEY = 'itsm_auth_user';

export function getToken() {
    try {
        return localStorage.getItem(TOKEN_KEY);
    } catch {
        return null;
    }
}

export function getUser() {
    try {
        const u = localStorage.getItem(USER_KEY);
        return u ? JSON.parse(u) : null;
    } catch {
        return null;
    }
}

export function setAuth(token, user) {
    try {
        localStorage.setItem(TOKEN_KEY, token);
        localStorage.setItem(USER_KEY, JSON.stringify(user || { username: user?.username }));
    } catch (_) {}
}

export function clearAuth() {
    try {
        localStorage.removeItem(TOKEN_KEY);
        localStorage.removeItem(USER_KEY);
    } catch (_) {}
}

export function isAuthenticated() {
    return !!getToken();
}
