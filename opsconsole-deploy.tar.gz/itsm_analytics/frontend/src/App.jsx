import React, { useState, useEffect, useMemo, useRef } from 'react';
import axios from 'axios';
import { BrainCircuit } from 'lucide-react';
import { motion } from 'framer-motion';

// Components
import Login from './components/Login';
import Sidebar from './components/Sidebar';
import DashboardHeader from './components/DashboardHeader';
import UploadView from './components/UploadView';
import AnalyticsDashboard from './components/AnalyticsDashboard';
import ChatPanel from './components/ChatPanel';
import MonthDetailModal from './components/MonthDetailModal';
import WorkloadTicketsModal from './components/WorkloadTicketsModal';
import UserManagement from './components/UserManagement';
import { getToken, clearAuth } from './auth';

// Paths are relative to axios baseURL (set in main.jsx) to avoid /api/api/...
const API_BASE = '';
// Full base for window.open (same as main.jsx baseURL: /api in Docker or http://localhost:8005 in dev)
const API_ORIGIN = import.meta.env.VITE_API_URL || 'http://localhost:8005';

function App() {
    const [authenticated, setAuthenticated] = useState(false);
    const [authChecking, setAuthChecking] = useState(true);
    const [currentUser, setCurrentUser] = useState(null);

    // --- State ---
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [uploadedFile, setUploadedFile] = useState(null);

    // UI State
    const [presentationMode, setPresentationMode] = useState(false);
    const [exporting, setExporting] = useState(false);
    const [activeTab, setActiveTab] = useState('dashboard');

    // Filters
    const [dateFrom, setDateFrom] = useState('');
    const [dateTo, setDateTo] = useState('');
    const [compareFrom, setCompareFrom] = useState('');
    const [compareTo, setCompareTo] = useState('');
    const [applyingFilter, setApplyingFilter] = useState(false);
    const [uploadDataType, setUploadDataType] = useState('Auto');
    const [recordTypeFilter, setRecordTypeFilter] = useState('All');
    // Dashboard slicers (reference-style grid)
    const [slicerMonth, setSlicerMonth] = useState('');
    const [slicerCategory, setSlicerCategory] = useState('');
    const [slicerPriority, setSlicerPriority] = useState('');
    const [filteredChartData, setFilteredChartData] = useState(null);
    const [slicersLoading, setSlicersLoading] = useState(false);

    // Chat & AI
    const [chatQuery, setChatQuery] = useState('');
    const [chatMessages, setChatMessages] = useState([]);
    const [chatLoading, setChatLoading] = useState(false);
    const [isChatMinimized, setIsChatMinimized] = useState(true);
    const chatBodyRef = useRef(null);
    const [sessionId, setSessionId] = useState(null);
    const [aiLoading, setAiLoading] = useState(false);

    // Month Detail Modal
    const [monthDetailModal, setMonthDetailModal] = useState(null);
    const [monthDetailTickets, setMonthDetailTickets] = useState({ columns: [], rows: [], loading: false });
    const [monthDetailMaximized, setMonthDetailMaximized] = useState(false);
    const [monthDetailSearch, setMonthDetailSearch] = useState('');
    const [monthDetailSort, setMonthDetailSort] = useState({ col: null, dir: 'asc' });

    // Workload Tickets Modal (Detailed Service Workload cell click)
    const [workloadTicketsModal, setWorkloadTicketsModal] = useState(null);
    const [workloadTicketsData, setWorkloadTicketsData] = useState({ columns: [], rows: [], loading: false });
    const [workloadTicketsMaximized, setWorkloadTicketsMaximized] = useState(false);

    // Comparison
    const [compareFiles, setCompareFiles] = useState({ file1: null, file2: null });
    const [compareResult, setCompareResult] = useState(null); // preserved but used via setData

    // Sessions
    const [savedSessions, setSavedSessions] = useState([]);

    // --- Effects ---

    // Auth: validate token on mount and listen for 401
    useEffect(() => {
        if (!getToken()) {
            setAuthChecking(false);
            return;
        }
        axios.get('/auth/me')
            .then((res) => {
                setAuthenticated(true);
                setCurrentUser(res.data || { username: res.data?.username, is_admin: res.data?.is_admin });
            })
            .catch(() => setAuthenticated(false))
            .finally(() => setAuthChecking(false));
    }, []);
    useEffect(() => {
        const onUnauthorized = () => setAuthenticated(false);
        window.addEventListener('itsm-unauthorized', onUnauthorized);
        return () => window.removeEventListener('itsm-unauthorized', onUnauthorized);
    }, []);
    // After login, fetch current user (username + is_admin)
    useEffect(() => {
        if (!authenticated) return;
        axios.get('/auth/me').then((res) => setCurrentUser(res.data || {})).catch(() => {});
    }, [authenticated]);
    // Refresh current user when tab becomes visible (e.g. after admin role changed elsewhere)
    useEffect(() => {
        if (!authenticated || !getToken()) return;
        const onFocus = () => {
            axios.get('/auth/me').then((res) => setCurrentUser(res.data || {})).catch(() => {});
        };
        window.addEventListener('focus', onFocus);
        return () => window.removeEventListener('focus', onFocus);
    }, [authenticated]);

    // Modal Escape Key
    useEffect(() => {
        const onEscape = (e) => {
            if (e.key !== 'Escape') return;
            if (workloadTicketsModal) setWorkloadTicketsModal(null);
            else if (monthDetailModal) setMonthDetailModal(null);
        };
        window.addEventListener('keydown', onEscape);
        return () => window.removeEventListener('keydown', onEscape);
    }, [monthDetailModal, workloadTicketsModal]);

    // Fetch Month Details
    useEffect(() => {
        if (!monthDetailModal?.monthName || !sessionId) {
            setMonthDetailTickets({ columns: [], rows: [], loading: false });
            return;
        }
        setMonthDetailSearch('');
        setMonthDetailSort({ col: null, dir: 'asc' });
        setMonthDetailTickets((prev) => ({ ...prev, loading: true }));
        axios.get('/tickets_for_month', { params: { session_id: sessionId, month: monthDetailModal.monthName } })
            .then((res) => setMonthDetailTickets({ columns: res.data.columns || [], rows: res.data.rows || [], loading: false }))
            .catch(() => setMonthDetailTickets({ columns: [], rows: [], loading: false }));
    }, [monthDetailModal?.monthName, sessionId]);

    // Fetch Workload Tickets (Detailed Service Workload cell click)
    useEffect(() => {
        if (!workloadTicketsModal?.category || !sessionId) {
            setWorkloadTicketsData({ columns: [], rows: [], loading: false });
            return;
        }
        setWorkloadTicketsData((prev) => ({ ...prev, loading: true }));
        axios.get('/workload-tickets', {
            params: { session_id: sessionId, category: workloadTicketsModal.category, month: workloadTicketsModal.month || undefined },
        })
            .then((res) => setWorkloadTicketsData({ columns: res.data.columns || [], rows: res.data.rows || [], loading: false }))
            .catch(() => setWorkloadTicketsData({ columns: [], rows: [], loading: false }));
    }, [workloadTicketsModal?.category, workloadTicketsModal?.month, sessionId]);

    // AI Insights Polling
    useEffect(() => {
        if (!data || data.ai_insights != null || !sessionId) return;
        setAiLoading(true);
        const poll = async () => {
            try {
                const res = await axios.get(`/ai-insights?session_id=${sessionId}`);
                if (res.data && res.data.summary && res.data.summary !== 'Loading...') {
                    setData((prev) => ({ ...prev, ai_insights: res.data }));
                    setAiLoading(false);
                    return true;
                }
            } catch (_) { }
            return false;
        };
        const id = setInterval(async () => {
            const done = await poll();
            if (done) clearInterval(id);
        }, 1500);
        return () => clearInterval(id);
    }, [sessionId, data?.ai_insights]);

    // Chat Scroll
    useEffect(() => {
        if (chatBodyRef.current) chatBodyRef.current.scrollTop = chatBodyRef.current.scrollHeight;
    }, [chatMessages, chatLoading]);

    // Session Restoration
    const fetchSavedSessions = async () => {
        try {
            const res = await axios.get('/sessions');
            setSavedSessions(res.data?.sessions ?? []);
        } catch (_) {
            setSavedSessions([]);
        }
    };

    const loadSession = async (sid) => {
        setError(null);
        try {
            const res = await axios.get(`/session?session_id=${encodeURIComponent(sid)}`);
            const d = res.data;
            if (d && d.chart_data) {
                setData({ chart_data: d.chart_data, filename: d.filename, ai_insights: d.ai_insights, session_id: d.session_id });
                setSessionId(d.session_id || sid);
                try { localStorage.setItem('itsm_session_id', sid); } catch (_) { }
            }
        } catch (err) {
            setError(err.response?.data?.detail || 'Failed to load session.');
        }
    };

    // Restore on mount
    useEffect(() => {
        let cancelled = false;
        fetchSavedSessions();
        const sid = typeof localStorage !== 'undefined' ? localStorage.getItem('itsm_session_id') : null;
        if (!sid) return;
        axios.get(`/session?session_id=${encodeURIComponent(sid)}`)
            .then((res) => {
                if (cancelled) return;
                const d = res.data;
                if (d && d.chart_data) {
                    setData({ chart_data: d.chart_data, filename: d.filename, ai_insights: d.ai_insights, session_id: d.session_id });
                    setSessionId(d.session_id || sid);
                }
            })
            .catch(() => {
                if (!cancelled) try { localStorage.removeItem('itsm_session_id'); } catch (_) { }
            });
        return () => { cancelled = true; };
    }, []);

    // --- Actions ---

    const uploadWithOptions = async (file, from, to, compareFrom, compareTo, dataType) => {
        const formData = new FormData();
        formData.append('file', file);
        if (from) formData.append('date_from', from);
        if (to) formData.append('date_to', to);
        if (compareFrom) formData.append('compare_from', compareFrom);
        if (compareTo) formData.append('compare_to', compareTo);
        if (dataType && dataType !== 'Auto') formData.append('data_type', dataType);
        const response = await axios.post('/upload', formData);
        const res = response.data;
        if (!res || typeof res !== 'object' || !res.chart_data) {
            setError(res?.detail || res?.message || 'Server returned invalid data. Try CSV or Excel.');
            return;
        }
        setData(res);
        setSessionId(res.session_id || null);
        setCompareResult(res.comparison ? res : null);
        setRecordTypeFilter('All');
        setSlicerMonth('');
        setSlicerCategory('');
        setSlicerPriority('');
        setFilteredChartData(null);
        if (res.session_id) {
            try { localStorage.setItem('itsm_session_id', res.session_id); } catch (_) { }
        }
        fetchSavedSessions();
    };

    const handleFileUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        setLoading(true);
        setError(null);
        setUploadedFile(file);
        try {
            await uploadWithOptions(file, '', '', undefined, undefined, uploadDataType);
            setDateFrom('');
            setDateTo('');
            setCompareFrom('');
            setCompareTo('');
        } catch (err) {
            const msg = err.response?.data?.detail ?? err.response?.data?.message ?? err.message;
            setError(typeof msg === 'string' ? msg : "Failed to process file. Ensure it's a valid CSV or Excel.");
        } finally {
            setLoading(false);
        }
    };

    const handleApplyDateFilter = async () => {
        if (!uploadedFile) return;
        setApplyingFilter(true);
        setError(null);
        try {
            await uploadWithOptions(uploadedFile, dateFrom || undefined, dateTo || undefined, compareFrom || undefined, compareTo || undefined, uploadDataType);
        } catch (err) {
            setError('Date filter failed. Try again.');
        } finally {
            setApplyingFilter(false);
        }
    };

    const handleCompareFiles = async () => {
        if (!compareFiles.file1 || !compareFiles.file2) { setError('Select both files to compare.'); return; }
        setLoading(true);
        setError(null);
        try {
            const formData = new FormData();
            formData.append('file1', compareFiles.file1);
            formData.append('file2', compareFiles.file2);
            const res = await axios.post('/compare', formData);
            setCompareResult(res.data);
            setData({ chart_data: res.data.chart_data_2, filename: res.data.filename_2, comparison: res.data.comparison, session_id: null });
        } catch (err) {
            setError('Compare failed. Ensure both files are valid.');
        } finally {
            setLoading(false);
        }
    };

    const deleteSession = async (sid) => {
        try {
            await axios.delete(`/session?session_id=${sid}`);
            setSavedSessions(prev => prev.filter(x => x.session_id !== sid));
            if (sessionId === sid) {
                setData(null);
                localStorage.removeItem('itsm_session_id');
            }
        } catch (e) { alert('Failed to delete session'); }
    };

    const clearAllSessions = async () => {
        try {
            await axios.delete('/sessions');
            setSavedSessions([]);
            setData(null);
            localStorage.removeItem('itsm_session_id');
        } catch (e) { alert('Failed to clear sessions'); }
    };

    // Exports
    const handleExport = async (format) => {
        if (!uploadedFile) return;
        setExporting(true);
        try {
            const formData = new FormData();
            formData.append('file', uploadedFile);
            const res = await axios.post(`/export?format=${format}`, formData, { responseType: 'blob' });
            const url = URL.createObjectURL(new Blob([res.data]));
            const a = document.createElement('a');
            a.href = url;
            a.download = (uploadedFile.name.replace(/\.[^.]+$/, '') || 'export') + '_processed.' + (format === 'csv' ? 'csv' : 'xlsx');
            a.click();
            URL.revokeObjectURL(url);
        } catch (err) {
            setError('Export failed. Try again.');
        } finally {
            setExporting(false);
        }
    };

    const handleExportCurrentView = async (format) => {
        setExporting(true);
        try {
            const formData = new FormData();
            if (sessionId) formData.append('session_id', sessionId);
            if (dateFrom) formData.append('date_from', dateFrom);
            if (dateTo) formData.append('date_to', dateTo);
            const res = await axios.post(`/export-current?format=${format}`, formData, { responseType: 'blob' });
            const url = URL.createObjectURL(new Blob([res.data]));
            const a = document.createElement('a');
            a.href = url;
            a.download = (data?.filename || 'current_view').replace(/\.[^.]+$/, '') + '_current.' + (format === 'csv' ? 'csv' : 'xlsx');
            a.click();
            URL.revokeObjectURL(url);
        } catch (err) {
            setError('Export current view failed.');
        } finally {
            setExporting(false);
        }
    };

    const handleMonthlyReport = async (format) => {
        if (!sessionId) { setError('Upload data first.'); return; }
        setExporting(true);
        try {
            const url = `/report/monthly?session_id=${encodeURIComponent(sessionId)}&format=${format}`;
            if (format === 'html') {
                window.open(API_ORIGIN + url, '_blank');
            } else {
                const res = await axios.get(url, { responseType: 'blob' });
                const blob = new Blob([res.data], { type: res.headers['content-type'] });
                const link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = (res.headers['content-disposition'] || '').match(/filename="?([^";]+)"?/)?.[1] || `Monthly_Report.${format}`;
                link.click();
                URL.revokeObjectURL(link.href);
            }
        } catch (err) {
            setError(err.response?.data?.detail || 'Monthly report failed.');
        } finally {
            setExporting(false);
        }
    };

    const handleSlides = async (format) => {
        if (!sessionId) { setError('Upload data first.'); return; }
        setExporting(true);
        try {
            const url = `/report/slides?session_id=${encodeURIComponent(sessionId)}&format=${format}`;
            if (format === 'html') {
                window.open(url, '_blank');
            } else {
                const res = await axios.get(url, { responseType: 'blob' });
                const blob = new Blob([res.data], { type: res.headers['content-type'] });
                const link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = (res.headers['content-disposition'] || '').match(/filename="?([^";]+)"?/)?.[1] || 'Presentation.pptx';
                link.click();
                URL.revokeObjectURL(link.href);
            }
        } catch (err) {
            setError(err.response?.data?.detail || 'Presentation export failed.');
        } finally {
            setExporting(false);
        }
    };

    const handlePivotReport = async () => {
        if (!sessionId) { setError('Upload data first.'); return; }
        setExporting(true);
        try {
            const url = `/report/pivot-pdf?session_id=${encodeURIComponent(sessionId)}`;
            const res = await axios.get(url, { responseType: 'blob' });
            const blob = new Blob([res.data], { type: res.headers['content-type'] });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = (res.headers['content-disposition'] || '').match(/filename="?([^";]+)"?/)?.[1] || 'Pivot_Report.pdf';
            link.click();
            URL.revokeObjectURL(link.href);
        } catch (err) {
            setError(err.response?.data?.detail || 'Pivot PDF failed.');
        } finally {
            setExporting(false);
        }
    };

    const handleFullReport = async () => {
        if (!sessionId) { setError('Upload data first.'); return; }
        setExporting(true);
        try {
            const url = `/report/full-pdf?session_id=${encodeURIComponent(sessionId)}`;
            const res = await axios.get(url, { responseType: 'blob' });
            const blob = new Blob([res.data], { type: res.headers['content-type'] });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = (res.headers['content-disposition'] || '').match(/filename="?([^";]+)"?/)?.[1] || 'Consolidated_Report.pdf';
            link.click();
            URL.revokeObjectURL(link.href);
        } catch (err) {
            setError(err.response?.data?.detail || 'Full PDF Report failed.');
        } finally {
            setExporting(false);
        }
    };

    // Chat
    const handleChatSubmit = async (e) => {
        e?.preventDefault?.();
        const q = chatQuery.trim();
        if (!q) return;
        setChatQuery('');
        setChatMessages((prev) => [...prev, { role: 'user', content: q }]);
        setChatLoading(true);
        try {
            const formData = new FormData();
            formData.append('query', q);
            if (sessionId) formData.append('session_id', sessionId);
            const res = await axios.post('/chat', formData);
            setChatMessages((prev) => [...prev, { role: 'assistant', result: res.data }]);
        } catch (err) {
            setChatMessages((prev) => [...prev, { role: 'assistant', result: { type: 'text', data: 'Chat query failed. Make sure data is uploaded and the session is valid.' } }]);
        } finally {
            setChatLoading(false);
        }
    };

    // Derived Data
    const chartData = useMemo(() => {
        if (filteredChartData) return filteredChartData;
        if (!data?.chart_data) return null;
        if (recordTypeFilter === 'All') return data.chart_data;
        return data.chart_data.chart_data_by_type?.[recordTypeFilter] ?? data.chart_data;
    }, [data?.chart_data, recordTypeFilter, filteredChartData]);

    // Fetch filtered chart data when dashboard slicers change
    const fetchFilteredChartData = async () => {
        if (!sessionId) return;
        setSlicersLoading(true);
        try {
            const params = new URLSearchParams({ session_id: sessionId });
            if (slicerMonth) params.set('month', slicerMonth);
            if (slicerCategory) params.set('category', slicerCategory);
            if (slicerPriority) params.set('priority', slicerPriority);
            const res = await axios.get(`/filtered-chart-data?${params.toString()}`);
            setFilteredChartData(res.data?.chart_data ?? null);
        } catch (_) {
            setFilteredChartData(null);
        } finally {
            setSlicersLoading(false);
        }
    };

    const clearSlicers = () => {
        setSlicerMonth('');
        setSlicerCategory('');
        setSlicerPriority('');
        setFilteredChartData(null);
    };

    useEffect(() => {
        if (!sessionId || (!slicerMonth && !slicerCategory && !slicerPriority)) {
            setFilteredChartData(null);
            return;
        }
        fetchFilteredChartData();
    }, [sessionId, slicerMonth, slicerCategory, slicerPriority]);

    const exportBreachListCSV = () => {
        const list = chartData?.breach_list ?? [];
        if (list.length === 0) return;
        const headers = ['ticket_id', 'category', 'priority', 'summary', 'sla_status', 'resolution_days'];
        const rows = list.map((r) => headers.map((h) => (r[h] ?? '').toString().replace(/"/g, '""')).join(','));
        const csv = [headers.join(','), ...rows].join('\n');
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = (data?.filename || 'breach_list').replace(/\.[^.]+$/, '') + '_sla_breaches.csv';
        a.click();
        URL.revokeObjectURL(url);
    };

    const openReport = () => {
        const url = sessionId ? `/report?session_id=${sessionId}` : '/report';
        window.open(API_ORIGIN + url, '_blank');
    };

    if (authChecking) {
        return (
            <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--background)' }}>
                <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}>
                    <BrainCircuit size={48} color="var(--accent)" />
                </motion.div>
            </div>
        );
    }
    if (!authenticated) {
        return <Login onLogin={() => setAuthenticated(true)} />;
    }

    return (
        <div className={`dashboard-container ${presentationMode ? 'presentation-mode' : ''}`}>
            {/* Sidebar */}
            {!presentationMode && (
                <Sidebar
                    activeTab={activeTab}
                    setActiveTab={setActiveTab}
                    savedSessions={savedSessions}
                    currentSessionId={sessionId}
                    onLoadSession={loadSession}
                    onDeleteSession={deleteSession}
                    onClearAllSessions={clearAllSessions}
                    onLogout={() => {
                        clearAuth();
                        setAuthenticated(false);
                        setCurrentUser(null);
                    }}
                    currentUser={currentUser}
                />
            )}

            {/* Main View */}
            <div className="main-view">
                <DashboardHeader
                    data={data}
                    uploadedFile={uploadedFile}
                    dateFrom={dateFrom} setDateFrom={setDateFrom}
                    dateTo={dateTo} setDateTo={setDateTo}
                    compareFrom={compareFrom} setCompareFrom={setCompareFrom}
                    compareTo={compareTo} setCompareTo={setCompareTo}
                    applyingFilter={applyingFilter}
                    onApplyDateFilter={handleApplyDateFilter}
                    presentationMode={presentationMode}
                    setPresentationMode={setPresentationMode}
                    exporting={exporting}
                    onExportFile={handleExport}
                    onExportCurrentView={handleExportCurrentView}
                    onOpenReport={openReport}
                    onMonthlyReport={handleMonthlyReport}
                    onPivotReport={handlePivotReport}
                    onFullReport={handleFullReport}
                    onGenerateSlides={handleSlides}
                    uploadDataType={uploadDataType}
                    setUploadDataType={setUploadDataType}
                    onFileUpload={handleFileUpload}
                />

                {activeTab === 'users' ? (
                    <UserManagement currentUser={currentUser} />
                ) : loading ? (
                    <div style={{ textAlign: 'center', padding: '80px 24px' }}>
                        <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}>
                            <BrainCircuit size={64} color="var(--accent)" />
                        </motion.div>
                        <h2 style={{ marginTop: '24px' }}>Processing your file...</h2>
                        <p style={{ color: 'var(--text-muted)' }}>AI is analyzing your ticket data</p>
                    </div>
                ) : !data ? (
                    <UploadView
                        error={error}
                        uploadDataType={uploadDataType}
                        setUploadDataType={setUploadDataType}
                        onFileUpload={handleFileUpload}
                        compareFiles={compareFiles}
                        setCompareFiles={setCompareFiles}
                        onCompareFiles={handleCompareFiles}
                    />
                ) : (
                    <AnalyticsDashboard
                        data={data}
                        chartData={chartData}
                        activeTab={activeTab}
                        setActiveTab={setActiveTab}
                        recordTypeFilter={recordTypeFilter}
                        setRecordTypeFilter={setRecordTypeFilter}
                        setMonthDetailModal={setMonthDetailModal}
                        setWorkloadTicketsModal={setWorkloadTicketsModal}
                        exportBreachListCSV={exportBreachListCSV}
                        aiLoading={aiLoading}
                        sessionId={sessionId}
                        slicerMonth={slicerMonth}
                        setSlicerMonth={setSlicerMonth}
                        slicerCategory={slicerCategory}
                        setSlicerCategory={setSlicerCategory}
                        slicerPriority={slicerPriority}
                        setSlicerPriority={setSlicerPriority}
                        clearSlicers={clearSlicers}
                        slicersLoading={slicersLoading}
                        baseChartData={data?.chart_data}
                    />
                )}
            </div>

            <ChatPanel
                data={data}
                isChatMinimized={isChatMinimized}
                setIsChatMinimized={setIsChatMinimized}
                chatMessages={chatMessages}
                setChatMessages={setChatMessages}
                chatQuery={chatQuery}
                setChatQuery={setChatQuery}
                chatLoading={chatLoading}
                onChatSubmit={handleChatSubmit}
                chatBodyRef={chatBodyRef}
            />

            <MonthDetailModal
                monthDetailModal={monthDetailModal}
                setMonthDetailModal={setMonthDetailModal}
                monthDetailTickets={monthDetailTickets}
                monthDetailMaximized={monthDetailMaximized}
                setMonthDetailMaximized={setMonthDetailMaximized}
                monthDetailSearch={monthDetailSearch}
                setMonthDetailSearch={setMonthDetailSearch}
                monthDetailSort={monthDetailSort}
                setMonthDetailSort={setMonthDetailSort}
            />

            <WorkloadTicketsModal
                workloadTicketsModal={workloadTicketsModal}
                setWorkloadTicketsModal={setWorkloadTicketsModal}
                workloadTicketsData={workloadTicketsData}
                workloadTicketsMaximized={workloadTicketsMaximized}
                setWorkloadTicketsMaximized={setWorkloadTicketsMaximized}
            />
        </div>
    );
}

export default App;
