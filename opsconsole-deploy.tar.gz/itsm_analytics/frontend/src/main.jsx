import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import axios from 'axios'
import { getToken, clearAuth } from './auth'
import './index.css'
import App from './App.jsx'

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8005'
axios.defaults.baseURL = API_BASE
axios.interceptors.request.use((config) => {
  const token = getToken()
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})
axios.interceptors.response.use(
  (r) => r,
  (err) => {
    if (err.response?.status === 401) {
      clearAuth()
      window.dispatchEvent(new Event('itsm-unauthorized'))
    }
    return Promise.reject(err)
  }
)

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
