# OpsConsole – Deploy on a New Server

This package contains the OpsConsole app (frontend, backend, Docker config) ready to run on another server.

---

## What's in the package

- **frontend/** – React app (Vite), logo, components
- **backend/** – FastAPI app, auth, processor, reporting, database
- **docker-compose.yml** – Postgres, Redis, backend, frontend
- **.env.example** – Template for environment variables
- **DEPLOY_LINUX.md** – Full Linux deployment guide
- **This file** – Quick steps for this package

Excluded from the package (recreated on deploy): `node_modules`, `__pycache__`, `.git`, `frontend/dist`, `.env`.

---

## Quick deploy on the new server (Linux)

1. **Copy the package** to the server (e.g. `opsconsole-deploy.tar.gz`).

2. **Extract**
   ```bash
   tar -xzf opsconsole-deploy.tar.gz
   cd itsm_analytics   # or the folder name inside the archive
   ```

3. **Configure environment**
   ```bash
   cp .env.example .env
   nano .env   # set GEMINI_API_KEY if you use AI; JWT_SECRET for production
   ```

4. **Build and run with Docker**
   ```bash
   docker compose build --no-cache
   docker compose up -d
   ```

5. **Create admin user** (first time only)
   ```bash
   docker compose exec backend python create_user.py admin YOUR_PASSWORD --force --admin
   ```

6. **Access**
   - App: **http://SERVER_IP:3000**
   - API: **http://SERVER_IP:8005**

---

## Optional: use a different folder name

If the archive extracts to a different folder name, `cd` into that folder and run the same commands above.

For more detail (Docker install, firewall, HTTPS), see **DEPLOY_LINUX.md**.
